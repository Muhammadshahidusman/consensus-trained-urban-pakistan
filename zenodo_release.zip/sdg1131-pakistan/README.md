# Consensus-trained foundation embeddings for SDG 11.3.1 in five major Pakistani cities

Code, built-up maps and result tables for the paper "Consensus-Trained Foundation Embeddings for
Data-Source-Robust Monitoring of Urban Land-Use Efficiency in Pakistan" by Shahid Usman,
Asif Nauman and Waqar Mehmood (Riphah International University).

The study maps built-up land in Karachi, Lahore, Faisalabad, Peshawar and Rawalpindi-Islamabad for
2017 and 2023 with a random forest trained on AlphaEarth Foundations embeddings, using labels only
where ESA WorldCover, Dynamic World and GHSL agree. It then computes SDG indicator 11.3.1 (LCRPGR)
for each data source and tests how it changes with reasonable method choices.

**These maps have no accuracy estimate.** No independent reference sample was interpreted, so all
scores here are agreement between maps. Sensitivity ranges show method choices and are not
confidence intervals.

## Contents

| Folder | What it holds |
|---|---|
| `maps/` | `builtup_{city}_{year}.tif`: 0 non-built, 1 built, 255 NoData (10 m, UTM) |
| | `change_{city}_2017_2023.tif`: 0 non-built both years, 1 stable built, 2 new built, 3 reversal, 255 NoData |
| | `extent_{city}_union.gpkg`: study extent; `extent_degurba_{city}.gpkg`: Degree of Urbanisation extent |
| `tables/` | All result tables (CSV) |
| `population/` | Population of each extent, from census totals |
| `provenance/` | Dataset identifiers, thresholds and Earth Engine task identifiers of every run |
| `gee/` | Earth Engine scripts, numbered in run order |
| `src/` | Local scripts for statistics, maps, charts and tables |
| `tests/` | Unit tests (`pytest`) |

Cities are named `karachi`, `lahore`, `faisalabad`, `peshawar` and `rawalpindi`. The last one is
the Rawalpindi-Islamabad agglomeration.

Comments in the code refer to project notes (`CLAUDE.md`, `PRD.md`, `PCD.md`) that are not part of
this archive. Scripts for the unused manual validation (`src/07*`, `src/08*`, `src/10_*`) are kept
for reference.

## Reproducing the results

1. Install Python 3.11 or later and run `pip install -r requirements.txt`.
2. Sign in to Earth Engine yourself and set your own project in `GEE_PROJECT` in `gee/ee_utils.py`.
3. Put the scripts back in a project layout: results are written to `data/` and `outputs/`.
4. Run the `gee/` scripts in number order, then the `src/` scripts in number order. Each script
   lists its inputs, outputs and command line in its docstring. Run `gee/` scripts with
   `--cities faisalabad` first to check the set-up.

All sampling and training use random seed 42. Earth Engine costs depend on your quota.

The national boundary file is not included, because it is not ours to redistribute. Scripts that
draw maps of Pakistan expect it at `data/Pakistan/Pakistan.shp`. Raw census tables are available
from the Pakistan Bureau of Statistics (https://www.pbs.gov.pk).

## Attribution

The AlphaEarth Foundations Satellite Embedding dataset is produced by Google and Google DeepMind.
Contains modified Copernicus Sentinel data [2017, 2020, 2023]. The maps also derive from ESA
WorldCover, Google Dynamic World, GHSL, Open Buildings 2.5D Temporal and WorldPop. Please cite these
sources as well. Dataset identifiers are in `docs/data_register.md`.

## Licence

Code: MIT (`LICENSE`). Maps, tables and other data: CC BY 4.0 (`LICENSE-data.txt`).
