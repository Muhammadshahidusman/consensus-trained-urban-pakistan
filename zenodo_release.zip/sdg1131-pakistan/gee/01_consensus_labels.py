"""Phase 4: 2020 consensus built-up labels and AlphaEarth embedding samples.

For each city (working AOI circle):
  1. Consensus label L(x), equation (2): built if WorldCover 2020 = 50 AND Dynamic World 2020
     annual mode = 6 AND GHSL 2020 built fraction >= GHSL_BUILT_MIN; non-built if all three
     are negative AND GHSL fraction <= GHSL_NONBUILT_MAX; otherwise excluded.
  2. Erode both classes by one 10 m pixel on the city's UTM grid, dropping boundary pixels
     where mixed pixels and co-registration errors concentrate.
  3. Stratified-sample the 2020 AlphaEarth embeddings (A00 to A63) at consensus pixels,
     POINTS_PER_CLASS per class, seed 42. Within non-built, water (WorldCover class 80) is
     capped at WATER_SHARE of the samples (authors' decision, 27 Oct 2026: sea made up 54 % of
     Karachi's non-built samples). The label rule, equation (2), is unchanged; only the
     sampling allocation is. Each sample carries a ~2 km spatial block ID (BLOCK_SIZE_M on the
     UTM grid) for spatial cross-validation.
  4. Export samples and eligible label areas to project assets (batch), then download them as
     CSV (gee/ee_utils.py). Product agreement statistics are in gee/03_agreement_maps.py.

If a class falls short of POINTS_PER_CLASS, PCD Step 4.2 says re-run that city with
``--ghsl-built-min 0.40``; the value used is recorded per city in provenance.

Outputs:
    data/interim/samples/samples_{city}_2020.csv
    data/interim/samples/label_area_{city}_2020.csv
    outputs/provenance/consensus_labels.json

Run:  python gee/01_consensus_labels.py --cities faisalabad
      python gee/01_consensus_labels.py
"""

from __future__ import annotations

import argparse
import json
import logging
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path

import ee
import pandas as pd

LOG = logging.getLogger("consensus_labels")

# --- Configuration -----------------------------------------------------------
YEAR = 2020
SEED = 42
SCALE_M = 10
POINTS_PER_CLASS = 2500
WATER_SHARE = 0.10  # max share of non-built samples drawn on water
BLOCK_SIZE_M = 2000  # spatial CV blocks on the UTM grid
GHSL_BUILT_MIN = 0.50  # tau_b: built fraction of a 100 m GHSL cell to call it built
GHSL_NONBUILT_MAX = 0.05  # tau_n: max built fraction to call it non-built
EROSION_RADIUS_PX = 1
TILE_SCALE = 4
MAX_PIXELS = 1e10
N_EMBED_BANDS = 64

ROOT = Path(__file__).resolve().parents[1]
SAMPLE_DIR = ROOT / "data" / "interim" / "samples"
PROVENANCE = ROOT / "outputs" / "provenance" / "consensus_labels.json"

# --- Catalog assets ----------------------------------------------------------
WORLDCOVER_ID = "ESA/WorldCover/v100"  # 2020 map
WORLDCOVER_BUILT_CLASS = 50
WORLDCOVER_WATER_CLASS = 80  # permanent water bodies
DYNAMICWORLD_ID = "GOOGLE/DYNAMICWORLD/V1"
DW_BUILT_CLASS = 6
GHSL_ID = "JRC/GHSL/P2023A/GHS_BUILT_S"  # images per epoch: .../2020
GHSL_CELL_AREA_M2 = 10_000  # 100 m x 100 m
EMBEDDING_ID = "GOOGLE/SATELLITE_EMBEDDING/V1/ANNUAL"
EMBED_BANDS = [f"A{i:02d}" for i in range(N_EMBED_BANDS)]
# stratum: 0 non-built land, 1 built, 2 non-built water; label = 1 if built else 0
STRATA = {"nonbuilt_land": 0, "built": 1, "nonbuilt_water": 2}
SAMPLE_COLUMNS = ["point_id", "city", "year", "label", "stratum", "block_x", "block_y",
                  "lon", "lat",
                  *EMBED_BANDS]


@dataclass(frozen=True)
class City:
    """Study city: centre, working AOI radius and UTM EPSG code (CLAUDE.md section 4).

    The buffer is a working AOI only; the SDG 11.3.1 urban extent is gee/02_urban_extent.py.
    """

    name: str
    lon: float
    lat: float
    radius_km: float
    epsg: int


CITIES: tuple[City, ...] = (
    City("karachi", 67.01, 24.86, 35, 32642),
    City("lahore", 74.34, 31.52, 30, 32643),
    City("faisalabad", 73.08, 31.42, 20, 32643),
    City("peshawar", 71.55, 34.01, 20, 32642),
    City("rawalpindi", 73.07, 33.65, 25, 32643),  # Rawalpindi-Islamabad agglomeration
)


def validate_config(cities: tuple[City, ...], ghsl_built_min: float = GHSL_BUILT_MIN) -> None:
    """Fail fast on impossible configuration values.

    Raises:
        ValueError: If any threshold or city definition is invalid.
    """
    if not 0 <= GHSL_NONBUILT_MAX < ghsl_built_min <= 1:
        raise ValueError("Need 0 <= GHSL_NONBUILT_MAX < GHSL_BUILT_MIN <= 1.")
    names = [c.name for c in cities]
    if len(names) != len(set(names)):
        raise ValueError("City names must be unique.")
    for c in cities:
        if c.radius_km <= 0:
            raise ValueError(f"{c.name}: radius_km must be positive.")
        if not (-180 <= c.lon <= 180 and -90 <= c.lat <= 90):
            raise ValueError(f"{c.name}: coordinates out of range.")


def city_aoi(city: City) -> ee.Geometry:
    """Return a circular AOI around the city centre."""
    return ee.Geometry.Point([city.lon, city.lat]).buffer(city.radius_km * 1000)


def product_layers(aoi: ee.Geometry) -> dict[str, ee.Image]:
    """Load the three built-up products as binary or fraction layers."""
    start, end = f"{YEAR}-01-01", f"{YEAR + 1}-01-01"

    wc_built = (
        ee.ImageCollection(WORLDCOVER_ID).first().select("Map")
        .eq(WORLDCOVER_BUILT_CLASS).rename("wc_built")
    )
    dw_built = (
        ee.ImageCollection(DYNAMICWORLD_ID)
        .filterBounds(aoi).filterDate(start, end)
        .select("label").mode()
        .eq(DW_BUILT_CLASS).rename("dw_built")
    )
    ghsl_frac = (
        ee.Image(f"{GHSL_ID}/{YEAR}").select("built_surface")
        .divide(GHSL_CELL_AREA_M2).rename("ghsl_frac")
    )
    wc_water = (
        ee.ImageCollection(WORLDCOVER_ID).first().select("Map")
        .eq(WORLDCOVER_WATER_CLASS).rename("wc_water")
    )
    return {"wc_built": wc_built, "dw_built": dw_built, "ghsl_frac": ghsl_frac,
            "wc_water": wc_water}


def consensus_label(layers: dict[str, ee.Image], crs: str,
                    ghsl_built_min: float = GHSL_BUILT_MIN,
                    erosion_px: int = EROSION_RADIUS_PX) -> ee.Image:
    """Return label image: 1 = all agree built, 0 = all agree non-built (equation 2).

    Pixels where products disagree are masked. Both classes are eroded by ``erosion_px``
    pixels on the 10 m UTM grid ``crs`` so boundary pixels are excluded (0 = no erosion,
    Phase 10 sensitivity).
    """
    wc, dw, gh = layers["wc_built"], layers["dw_built"], layers["ghsl_frac"]
    built = wc.And(dw).And(gh.gte(ghsl_built_min))
    nonbuilt = wc.Not().And(dw.Not()).And(gh.lte(GHSL_NONBUILT_MAX))

    def erode(mask: ee.Image) -> ee.Image:
        # Fix the grid at 10 m UTM so the focal kernel means one 10 m pixel.
        grid = mask.unmask(0).reproject(crs=crs, scale=SCALE_M)
        return grid.focalMin(radius=erosion_px, units="pixels") if erosion_px else grid

    label = (
        ee.Image.constant(-1)
        .where(erode(nonbuilt), 0)
        .where(erode(built), 1)
    )
    return label.updateMask(label.gte(0)).toInt().rename("label")


def sampling_stratum(label: ee.Image, wc_water: ee.Image) -> ee.Image:
    """Split consensus non-built into land (0) and water (2); built stays 1."""
    water = label.eq(0).And(wc_water.unmask(0))
    return label.where(water, STRATA["nonbuilt_water"]).rename("stratum")


def class_points(points_per_class: int = POINTS_PER_CLASS,
                 water_share: float = WATER_SHARE) -> dict[int, int]:
    """Sample allocation per stratum: water takes at most ``water_share`` of non-built."""
    n_water = round(points_per_class * water_share)
    return {STRATA["nonbuilt_land"]: points_per_class - n_water,
            STRATA["built"]: points_per_class,
            STRATA["nonbuilt_water"]: n_water}


def block_ids(crs: str) -> ee.Image:
    """Spatial block indices (BLOCK_SIZE_M on the UTM grid) for spatial CV."""
    xy = ee.Image.pixelCoordinates(ee.Projection(crs))
    bx = xy.select("x").divide(BLOCK_SIZE_M).floor().toInt()
    by = xy.select("y").divide(BLOCK_SIZE_M).floor().toInt()
    return bx.rename("block_x").addBands(by.rename("block_y"))


def embeddings(aoi: ee.Geometry) -> ee.Image:
    """AlphaEarth 64-band embedding mosaic for YEAR over the AOI."""
    return (
        ee.ImageCollection(EMBEDDING_ID)
        .filterBounds(aoi)
        .filterDate(f"{YEAR}-01-01", f"{YEAR + 1}-01-01")
        .mosaic()
        .select(EMBED_BANDS)
    )


def city_collections(city: City, ghsl_built_min: float, erosion_px: int = EROSION_RADIUS_PX
                     ) -> tuple[ee.FeatureCollection, ee.FeatureCollection]:
    """Samples and eligible label areas for one city."""
    crs = f"EPSG:{city.epsg}"
    aoi = city_aoi(city)
    layers = product_layers(aoi)
    label = consensus_label(layers, crs, ghsl_built_min, erosion_px)
    stratum = sampling_stratum(label, layers["wc_water"])

    alloc = class_points()
    stack = embeddings(aoi).addBands(stratum).addBands(block_ids(crs))
    samples = stack.stratifiedSample(
        numPoints=POINTS_PER_CLASS, classBand="stratum", region=aoi, scale=SCALE_M,
        projection=crs, seed=SEED, classValues=list(alloc), classPoints=list(alloc.values()),
        geometries=True, tileScale=TILE_SCALE,
    )

    def tag(f: ee.Feature) -> ee.Feature:
        lonlat = f.geometry().transform("EPSG:4326", 1).coordinates()
        return f.set({
            "city": city.name, "year": YEAR,
            "point_id": ee.String(city.name).cat("_").cat(f.get("system:index")),
            "lon": lonlat.get(0), "lat": lonlat.get(1),
            "label": ee.Number(f.get("stratum")).eq(STRATA["built"]),
        })

    areas = (
        ee.Image.pixelArea().addBands(stratum)
        .reduceRegion(
            reducer=ee.Reducer.sum().group(groupField=1, groupName="stratum"),
            geometry=aoi, crs=crs, scale=SCALE_M, maxPixels=MAX_PIXELS, tileScale=TILE_SCALE,
        )
    )
    area_fc = ee.FeatureCollection(
        ee.List(areas.get("groups")).map(
            lambda g: ee.Feature(ee.Geometry.Point([city.lon, city.lat]), {  # asset needs geometry
                "city": city.name, "year": YEAR,
                "stratum": ee.Dictionary(g).get("stratum"),
                "area_km2": ee.Number(ee.Dictionary(g).get("sum")).divide(1e6),
            })
        )
    )
    return samples.map(tag), area_fc


def check_counts(path: Path) -> dict[str, int]:
    """Per-stratum sample counts of a downloaded sample CSV; warns on a shortfall.

    A built shortfall calls for ``--ghsl-built-min 0.40`` (PCD Step 4.2); a water shortfall
    only means the city has little consensus water, which is reported, not fixed.
    """
    counts = pd.read_csv(path, encoding="utf-8", usecols=["stratum"])["stratum"].value_counts()
    alloc = class_points()
    result = {name: int(counts.get(code, 0)) for name, code in STRATA.items()}
    for name, code in STRATA.items():
        if result[name] < alloc[code]:
            hint = ("PCD 4.2: re-run with --ghsl-built-min 0.40" if name == "built"
                    else "reported in provenance")
            LOG.warning("%s: only %d %s samples (< %d); %s", path.stem, result[name], name,
                        alloc[code], hint)
    return result


def main() -> None:
    """Validate config, export samples and label areas, download, and write provenance."""
    import ee_utils

    names = [c.name for c in CITIES]
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=names, choices=names)
    parser.add_argument("--ghsl-built-min", type=float, default=GHSL_BUILT_MIN)
    parser.add_argument("--erosion-px", type=int, default=EROSION_RADIUS_PX)
    parser.add_argument("--variant", default="",
                        help='suffix for Phase 10 runs, e.g. "_tau040"; "" = baseline')
    parser.add_argument("--skip-area", action="store_true",
                        help="do not export eligible label areas (saves EECU in Phase 10)")
    args = parser.parse_args()
    v = args.variant
    provenance = PROVENANCE.with_name(f"{PROVENANCE.stem}{v}.json")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    cities = [c for c in CITIES if c.name in args.cities]
    validate_config(tuple(cities), args.ghsl_built_min)

    try:
        ee_utils.initialise()
    except ee.EEException as e:
        raise RuntimeError("Earth Engine init failed. Ask the user to run "
                           "`earthengine authenticate`.") from e

    tasks: dict[str, list[ee.batch.Task]] = {}
    for city in cities:
        samples, areas = city_collections(city, args.ghsl_built_min, args.erosion_px)
        tasks[city.name] = [
            ee_utils.export_table_to_asset(samples, f"samples_{city.name}_{YEAR}{v}")]
        if not args.skip_area:
            tasks[city.name].append(
                ee_utils.export_table_to_asset(areas, f"label_area_{city.name}_{YEAR}{v}"))
    ee_utils.wait_for_tasks([t for ts in tasks.values() for t in ts])

    per_city = {}
    for city in cities:
        sample_csv = SAMPLE_DIR / f"samples_{city.name}_{YEAR}{v}.csv"
        ee_utils.download_table_csv(f"samples_{city.name}_{YEAR}{v}", sample_csv,
                                    SAMPLE_COLUMNS)
        if not args.skip_area:
            ee_utils.download_table_csv(f"label_area_{city.name}_{YEAR}{v}",
                                        SAMPLE_DIR / f"label_area_{city.name}_{YEAR}{v}.csv",
                                        ["city", "year", "stratum", "area_km2"])
        per_city[city.name] = {
            "ghsl_built_min": args.ghsl_built_min,
            "erosion_px": args.erosion_px,
            "task_ids": [t.id for t in tasks[city.name]],
            "sample_counts": check_counts(sample_csv),
            "run_utc": datetime.now(UTC).isoformat(),
        }

    old = {}
    if provenance.exists():  # keep records of cities not re-run
        old = json.loads(provenance.read_text(encoding="utf-8")).get("per_city", {})
    record = {
        "script": "gee/01_consensus_labels.py",
        "gee_project": ee_utils.GEE_PROJECT,
        "ee_api_version": ee.__version__,
        "year": YEAR,
        "assets": {
            "worldcover": WORLDCOVER_ID,
            "dynamic_world": DYNAMICWORLD_ID,
            "ghsl": f"{GHSL_ID}/{YEAR}",
            "embeddings": EMBEDDING_ID,
        },
        "rules": {
            "built": f"WC=={WORLDCOVER_BUILT_CLASS} & DW mode=={DW_BUILT_CLASS} "
                     "& GHSL frac>=ghsl_built_min (per city)",
            "nonbuilt": f"WC!={WORLDCOVER_BUILT_CLASS} & DW mode!={DW_BUILT_CLASS} "
                        f"& GHSL frac<={GHSL_NONBUILT_MAX}",
            "erosion_px": "per city (baseline 1)",
            "erosion_grid": "10 m, city UTM",
        },
        "sampling": {
            "points_per_class": POINTS_PER_CLASS,
            "strata": STRATA,
            "class_points": {str(k): v for k, v in class_points().items()},
            "water_definition": f"consensus non-built AND WorldCover == {WORLDCOVER_WATER_CLASS}",
            "scale_m": SCALE_M,
            "seed": SEED,
            "block_size_m": BLOCK_SIZE_M,
            "tile_scale": TILE_SCALE,
            "region": "working AOI circle",
        },
        "cities": [asdict(c) for c in CITIES],
        "per_city": {**old, **per_city},
    }
    record["variant"] = v
    provenance.parent.mkdir(parents=True, exist_ok=True)
    provenance.write_text(json.dumps(record, indent=2), encoding="utf-8")
    LOG.info("Provenance written to %s", provenance)


if __name__ == "__main__":
    main()
