"""Phase 2: urban extents for 2017 and 2023 (UN-Habitat built-up density method).

Stage 1 (Earth Engine): for each city and year, take the Dynamic World annual mode of
``label`` (built = class 6, water = class 0), aggregate to a 30 m grid in the city's UTM zone,
and compute for every 30 m cell the built-up share of land within a circular neighbourhood of
1 km² (radius 564 m). Water is excluded from the denominator so coastal cells (Karachi) are not
diluted by sea. The density grid (< 20 MB) is batch-exported to a project asset, then
downloaded (gee/ee_utils.py).

Stage 2 (local): classify urban (> 50 %), suburban (25 to 50 %), rural (< 25 %); take urban +
suburban cells; keep the connected patch containing the city centre plus patches within
LINK_DISTANCE_M of it; fill holes; vectorise. The study extent is the union of 2017 and 2023.

Rawalpindi: Islamabad's built-up area is contiguous with Rawalpindi, so the study unit is the
Rawalpindi-Islamabad agglomeration (authors' decision, 27 Oct 2026). Its working AOI is centred
between the two cities with a 25 km radius so that north-west Islamabad is not cut off. The city
key stays ``rawalpindi``.

Extents are capped at the working AOI radius (EXTENT_LIMIT = "aoi", authors' decision): without
the cap, chains of villages that Dynamic World labels built link up and the extent runs to the
search-area edge.

Built-up source (``--built-source``): ``model`` gives the study extent (PCD Phase 6: own 2017
and 2023 maps, asset maps_{city} from gee/06_classify_years.py); ``dw`` gives the provisional
Dynamic World extent of Phase 2, kept for comparison. The own maps cover the working AOI only,
so with ``model`` cells outside the AOI are left out of the denominator, as water is. The
extent is capped at the AOI in both cases.

Outputs ({tag} = "" for model, "dw_" for Dynamic World):
    data/interim/density/density_{tag}{city}_{year}.tif   built-up share x 10000 (uint16)
    data/interim/density/urbanness_{tag}{city}_{year}.tif 0 rural, 1 suburban, 2 urban
    data/processed/extent_{tag}{city}_{year}.gpkg, extent_{tag}{city}_union.gpkg (UTM)
    outputs/tables/extent_areas.csv (model), extent_areas_dw.csv
    outputs/provenance/urban_extent.json (model), urban_extent_dw.json; task IDs kept per city

Run:  python gee/02_urban_extent.py --built-source model --cities faisalabad
      python gee/02_urban_extent.py --built-source model
      python gee/02_urban_extent.py --built-source dw --skip-download   (stage 2 only)
"""

from __future__ import annotations

import argparse
import json
import logging
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from pyproj import Transformer
from rasterio import features
from scipy import ndimage
from shapely.geometry import shape
from shapely.ops import unary_union

LOG = logging.getLogger("urban_extent")

# --- Configuration -----------------------------------------------------------
GEE_PROJECT = "earthengine-512818"  # also set in gee/ee_utils.py
YEARS = (2017, 2023)
DW_ID = "GOOGLE/DYNAMICWORLD/V1"
DW_BUILT_CLASS = 6
DW_WATER_CLASS = 0
MAP_NODATA = 255  # no-data value of the gee/06 map stacks
BUILT_SOURCES = ("model", "dw")
DW_SCALE_M = 10
WORK_SCALE_M = 30
NEIGHBOURHOOD_RADIUS_M = 564  # circle of ~1 km² (pi * 564² = 0.999 km²)
URBAN_MIN = 0.50
SUBURBAN_MIN = 0.25
LINK_DISTANCE_M = 100
SEARCH_BUFFER_KM = 10  # extent search area = working AOI radius + this
# "search": extent may grow to the search-area edge; "aoi": capped at the working AOI radius.
EXTENT_LIMIT = "aoi"
DENSITY_FACTOR = 10_000  # density stored as uint16 share x 10000
DENSITY_NODATA = 65_535
CLASS_NODATA = 255

ROOT = Path(__file__).resolve().parents[1]
DENSITY_DIR = ROOT / "data" / "interim" / "density"
PROCESSED_DIR = ROOT / "data" / "processed"
AREA_TABLE = ROOT / "outputs" / "tables" / "extent_areas.csv"
PROVENANCE = ROOT / "outputs" / "provenance" / "urban_extent.json"


@dataclass(frozen=True)
class City:
    """Study city: centre, working AOI radius and map CRS (CLAUDE.md section 4)."""

    name: str
    lon: float
    lat: float
    radius_km: float
    epsg: int


CITIES: dict[str, City] = {c.name: c for c in (
    City("karachi", 67.01, 24.86, 35, 32642),
    City("lahore", 74.34, 31.52, 30, 32643),
    City("faisalabad", 73.08, 31.42, 20, 32643),
    City("peshawar", 71.55, 34.01, 20, 32642),
    City("rawalpindi", 73.07, 33.65, 25, 32643),  # Rawalpindi-Islamabad agglomeration
)}


# --- Stage 1: Earth Engine ---------------------------------------------------
def tag(source: str) -> str:
    """File-name tag of a built-up source ("" for the study extent from the own model)."""
    if source not in BUILT_SOURCES:
        raise ValueError(f"Unknown built source {source!r}")
    return "" if source == "model" else f"{source}_"


def density_image(city: City, year: int, source: str):  # -> ee.Image
    """Built-up share of land within the 1 km² neighbourhood, 30 m grid, city UTM."""
    import ee
    import ee_utils

    crs = f"EPSG:{city.epsg}"
    region = search_region(city)
    label = (
        ee.ImageCollection(DW_ID).filterBounds(region)
        .filterDate(f"{year}-01-01", f"{year + 1}-01-01")
        .select("label").mode()
        .reproject(crs=crs, scale=DW_SCALE_M)
    )
    land = label.neq(DW_WATER_CLASS).unmask(0)
    if source == "dw":
        built = label.eq(DW_BUILT_CLASS).unmask(0)
    else:
        own = ee.Image(ee_utils.asset_id(f"maps_{city.name}")).select(f"built_{year}")
        inside = own.neq(MAP_NODATA).unmask(0)
        built = own.eq(1).And(inside).unmask(0)
        land = land.And(inside)

    def to_work_grid(img):  # ee.Image -> ee.Image
        return (
            img.reduceResolution(reducer=ee.Reducer.mean(), maxPixels=64)
            .reproject(crs=crs, scale=WORK_SCALE_M)
        )

    kernel = ee.Kernel.circle(radius=NEIGHBOURHOOD_RADIUS_M, units="meters", normalize=False)
    built_sum = to_work_grid(built).convolve(kernel).reproject(crs=crs, scale=WORK_SCALE_M)
    land_sum = to_work_grid(land).convolve(kernel).reproject(crs=crs, scale=WORK_SCALE_M)
    density = built_sum.divide(land_sum).updateMask(land_sum.gt(0))
    return (
        density.multiply(DENSITY_FACTOR).round().toUint16()
        .unmask(DENSITY_NODATA).clip(region).rename("density")
    )


def search_region(city: City):  # -> ee.Geometry
    """Circle of AOI radius + SEARCH_BUFFER_KM around the centre."""
    import ee

    radius_m = (city.radius_km + SEARCH_BUFFER_KM) * 1000
    return ee.Geometry.Point([city.lon, city.lat]).buffer(radius_m)


def export_and_download(cities: list[City], source: str) -> dict[str, list[str]]:
    """Batch-export every density grid to project assets, wait, then download them.

    Returns:
        Earth Engine task IDs per city, for provenance.
    """
    import ee_utils

    ee_utils.initialise()
    tasks: dict[str, list] = {city.name: [] for city in cities}
    for city in cities:
        for year in YEARS:
            tasks[city.name].append(ee_utils.export_image_to_asset(
                density_image(city, year, source), f"density_{tag(source)}{city.name}_{year}",
                search_region(city).bounds(), f"EPSG:{city.epsg}", WORK_SCALE_M,
            ))
    ee_utils.wait_for_tasks([t for city_tasks in tasks.values() for t in city_tasks])
    for city in cities:
        for year in YEARS:
            name = f"density_{tag(source)}{city.name}_{year}"
            ee_utils.download_asset(name, DENSITY_DIR / f"{name}.tif",
                                    f"EPSG:{city.epsg}", WORK_SCALE_M)
    return {name: [t.id for t in city_tasks] for name, city_tasks in tasks.items()}


# --- Stage 2: local morphology -----------------------------------------------
def classify(density: np.ndarray) -> np.ndarray:
    """Return 0 rural, 1 suburban, 2 urban; CLASS_NODATA where density is NaN."""
    out = np.full(density.shape, CLASS_NODATA, dtype=np.uint8)
    valid = ~np.isnan(density)
    out[valid] = 0
    out[valid & (density >= SUBURBAN_MIN)] = 1
    out[valid & (density > URBAN_MIN)] = 2
    return out


def disk(radius_px: float) -> np.ndarray:
    """Boolean disk structuring element of the given pixel radius."""
    r = int(np.ceil(radius_px))
    yy, xx = np.mgrid[-r:r + 1, -r:r + 1]
    return (xx**2 + yy**2) <= radius_px**2


def core_extent(mask: np.ndarray, centre_rc: tuple[int, int], link_px: float) -> np.ndarray:
    """Patch containing the centre plus patches within link_px of it, holes filled.

    The centre cell must itself be urban or suburban; no nearby patch is guessed, so a
    ValueError points at a centre coordinate that needs checking.

    Args:
        mask: Boolean urban + suburban cells.
        centre_rc: (row, col) of the city centre.
        link_px: Linking distance in pixels.

    Returns:
        Boolean extent mask.

    Raises:
        ValueError: If the centre cell is outside the mask.
    """
    labels, _ = ndimage.label(mask, structure=np.ones((3, 3), dtype=bool))
    centre_label = labels[centre_rc]
    if centre_label == 0:
        raise ValueError(f"City centre {centre_rc} is not an urban or suburban cell")
    main = labels == centre_label
    near = ndimage.binary_dilation(main, structure=disk(link_px))
    keep_ids = np.unique(labels[near & mask])
    extent = np.isin(labels, keep_ids[keep_ids > 0])
    return ndimage.binary_fill_holes(extent)


def vectorise(mask: np.ndarray, transform, crs) -> gpd.GeoDataFrame:
    """Dissolve a boolean mask into one (multi)polygon."""
    polys = [shape(g) for g, v in features.shapes(mask.astype(np.uint8), mask=mask,
                                                  transform=transform) if v == 1]
    return gpd.GeoDataFrame(geometry=[unary_union(polys)], crs=crs)


def read_density(path: Path, city: City) -> tuple[np.ndarray, dict]:
    """Read a density GeoTIFF as float share, NaN for nodata and outside the search circle.

    The download covers the circle's bounding box; cells outside the circle come back as 0,
    so they are masked here from the cell-centre distance to the city centre.
    """
    with rasterio.open(path) as src:
        raw = src.read(1)
        profile = src.profile
    density = raw.astype(np.float32) / DENSITY_FACTOR
    density[raw == DENSITY_NODATA] = np.nan
    density[centre_distance(profile, city) > (city.radius_km + SEARCH_BUFFER_KM) * 1000] = np.nan
    return density, profile


def centre_distance(profile: dict, city: City) -> np.ndarray:
    """Distance (m) from each cell centre to the city centre, in the grid's UTM CRS."""
    to_utm = Transformer.from_crs("EPSG:4326", f"EPSG:{city.epsg}", always_xy=True)
    cx, cy = to_utm.transform(city.lon, city.lat)
    shape_rc = (profile["height"], profile["width"])
    rows, cols = np.indices(shape_rc)
    xs, ys = rasterio.transform.xy(profile["transform"], rows.ravel(), cols.ravel())
    return np.hypot(np.asarray(xs) - cx, np.asarray(ys) - cy).reshape(shape_rc)


def touches_edge(extent: np.ndarray, valid: np.ndarray) -> bool:
    """True if the extent reaches the edge of the ``valid`` limit area (AOI or search circle)."""
    edge = valid & ~ndimage.binary_erosion(valid, structure=np.ones((3, 3), dtype=bool))
    return bool((extent & edge).any())


def build_extent(city: City, year: int, source: str) -> tuple[gpd.GeoDataFrame, dict]:
    """Classify one density grid and derive its extent polygon and statistics."""
    t = tag(source)
    density, profile = read_density(DENSITY_DIR / f"density_{t}{city.name}_{year}.tif", city)
    classes = classify(density)
    with rasterio.open(DENSITY_DIR / f"urbanness_{t}{city.name}_{year}.tif", "w",
                       **{**profile, "dtype": "uint8", "nodata": CLASS_NODATA}) as dst:
        dst.write(classes, 1)

    mask = (classes == 1) | (classes == 2)
    limit_km = city.radius_km if EXTENT_LIMIT == "aoi" else city.radius_km + SEARCH_BUFFER_KM
    # Circle, not ~isnan(density): masked water would otherwise count as an edge.
    limit = centre_distance(profile, city) <= limit_km * 1000
    mask &= limit
    to_utm = Transformer.from_crs("EPSG:4326", f"EPSG:{city.epsg}", always_xy=True)
    x, y = to_utm.transform(city.lon, city.lat)
    row, col = rasterio.transform.rowcol(profile["transform"], x, y)
    extent = core_extent(mask, (row, col), LINK_DISTANCE_M / WORK_SCALE_M)

    cell_km2 = (WORK_SCALE_M**2) / 1e6
    stats = {
        "extent_km2": round(float(extent.sum() * cell_km2), 1),
        "urban_km2_in_extent": round(float(((classes == 2) & extent).sum() * cell_km2), 1),
        "suburban_km2_in_extent": round(float(((classes == 1) & extent).sum() * cell_km2), 1),
        "touches_limit_edge": touches_edge(extent, limit),
    }
    return vectorise(extent, profile["transform"], profile["crs"]), stats


def write_city_extents(city: City, source: str) -> list[dict]:
    """Build both years and their union for one city."""
    t = tag(source)
    rows, polys = [], []
    for year in YEARS:
        gdf, stats = build_extent(city, year, source)
        gdf.to_file(PROCESSED_DIR / f"extent_{t}{city.name}_{year}.gpkg", driver="GPKG")
        polys.append(gdf.geometry.iloc[0])
        rows.append({"city": city.name, "year": year, **stats})
        if stats["touches_limit_edge"]:
            LOG.warning("%s %d extent reaches the %s limit circle", city.name, year,
                        EXTENT_LIMIT)
    union = gpd.GeoDataFrame(geometry=[unary_union(polys)], crs=gdf.crs)
    union.to_file(PROCESSED_DIR / f"extent_{t}{city.name}_union.gpkg", driver="GPKG")
    rows.append({"city": city.name, "year": "union",
                 "extent_km2": round(float(union.area.iloc[0]) / 1e6, 1)})
    return rows


def main() -> None:
    """Download density grids (stage 1) and derive extents (stage 2)."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=list(CITIES), choices=list(CITIES))
    parser.add_argument("--skip-download", action="store_true")
    parser.add_argument("--built-source", choices=BUILT_SOURCES, required=True)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    cities = [CITIES[c] for c in args.cities]
    source = args.built_source
    suffix = "" if source == "model" else f"_{source}"
    area_table = AREA_TABLE.with_name(f"{AREA_TABLE.stem}{suffix}.csv")
    provenance = PROVENANCE.with_name(f"{PROVENANCE.stem}{suffix}.json")

    task_ids = {} if args.skip_download else export_and_download(cities, source)

    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    for city in cities:
        rows += write_city_extents(city, source)
    table = pd.DataFrame(rows)
    LOG.info("Extent areas:\n%s", table.to_string(index=False))

    AREA_TABLE.parent.mkdir(parents=True, exist_ok=True)
    if area_table.exists():  # keep rows for cities not re-run (same columns only)
        old = pd.read_csv(area_table, encoding="utf-8")
        old = old[old.columns.intersection(table.columns)]
        table = pd.concat([old[~old["city"].isin(args.cities)], table], ignore_index=True)
    table.to_csv(area_table, index=False, encoding="utf-8")

    old_ids = {}
    if provenance.exists():  # keep task IDs of cities not re-exported in this run
        old_ids = json.loads(provenance.read_text(encoding="utf-8")).get("task_ids", {})
        if not isinstance(old_ids, dict):
            old_ids = {}
    record = {
        "run_utc": datetime.now(UTC).isoformat(),
        "script": "gee/02_urban_extent.py",
        "gee_project": GEE_PROJECT,
        "built_source": source,
        "built_layer": (f"{DW_ID} annual mode of label, built == {DW_BUILT_CLASS}"
                        if source == "dw" else
                        "own model, asset maps_{city} band built_{year} (gee/06)"),
        "denominator": f"land cells (DW label != {DW_WATER_CLASS})"
                       + ("" if source == "dw" else ", inside the working AOI"),
        "dw_scale_m": DW_SCALE_M, "work_scale_m": WORK_SCALE_M,
        "neighbourhood_radius_m": NEIGHBOURHOOD_RADIUS_M,
        "thresholds": {"urban_gt": URBAN_MIN, "suburban_ge": SUBURBAN_MIN},
        "link_distance_m": LINK_DISTANCE_M, "search_buffer_km": SEARCH_BUFFER_KM,
        "extent_limit": EXTENT_LIMIT,
        "years": list(YEARS), "cities": [asdict(c) for c in CITIES.values()],
        "download": "Export.image.toAsset then getDownloadURL (gee/ee_utils.py)",
        "task_ids": {**old_ids, **task_ids},
    }
    provenance.parent.mkdir(parents=True, exist_ok=True)
    provenance.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
