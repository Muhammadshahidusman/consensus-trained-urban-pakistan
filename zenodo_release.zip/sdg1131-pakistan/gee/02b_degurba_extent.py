"""Phase 2, Step 2.3: Degree of Urbanisation sensitivity extents (GHSL SMOD urban centres).

For each city, take the GHSL settlement model grid (GHS-SMOD R2023A V2-0, epoch 2020), vectorise
the 4-connected urban-centre cells (SMOD class 30) on the native 1 km Mollweide grid inside Earth
Engine, and keep the polygon that contains the city centre. SMOD class 30 applies the Degree of
Urbanisation stage-1 "urban centre" rule, the same definition that the GHSL Urban Centre
Database is built on. Epoch 2020 is used because the 2025 epoch is a model projection, not an
observation. Vectorising in Earth Engine keeps the exact 1 km cell edges (GeoTIFF export does
not support the Mollweide grid). All cities are fetched in a single request.

These extents are a sensitivity test for Phase 10 only; the main extent is gee/02_urban_extent.py.
Like the main extent, they are capped at the working AOI (the built-up maps cover only the AOI,
so an uncapped extent would count population without its built-up land); the uncapped area is
also reported.

Outputs:
    data/processed/extent_degurba_{city}.gpkg (UTM)
    outputs/tables/extent_areas_degurba.csv
    outputs/provenance/degurba_extent.json

Run:  python gee/02b_degurba_extent.py --cities faisalabad
      python gee/02b_degurba_extent.py
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import pandas as pd
from shapely.geometry import Point

LOG = logging.getLogger("degurba_extent")

# --- Configuration -----------------------------------------------------------
SMOD_ID = "JRC/GHSL/P2023A/GHS_SMOD_V2-0"
SMOD_EPOCH = "2020"
SMOD_BAND = "smod_code"
URBAN_CENTRE_CODE = 30
SMOD_SCALE_M = 1000
SEARCH_RADIUS_KM = 60  # wide enough that no urban centre is cut by the search box
MAX_PIXELS = 1e8
AOI_QUAD_SEGS = 256  # segments per quarter circle for the AOI cap (area error < 0.01%)

ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = ROOT / "data" / "processed"
AREA_TABLE = ROOT / "outputs" / "tables" / "extent_areas_degurba.csv"
PROVENANCE = ROOT / "outputs" / "provenance" / "degurba_extent.json"


def _load_cities() -> dict:
    """Reuse the city definitions of gee/02_urban_extent.py (one source of truth)."""
    path = Path(__file__).with_name("02_urban_extent.py")
    spec = importlib.util.spec_from_file_location("urban_extent", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.CITIES


CITIES = _load_cities()


def urban_centre_polygons(cities: list) -> dict:
    """Urban-centre polygon containing each city centre, as GeoJSON (EPSG:4326).

    Returns:
        FeatureCollection GeoJSON with a ``city`` property and a ``touches_box`` flag.
    """
    import ee

    smod = (ee.ImageCollection(SMOD_ID).filter(ee.Filter.eq("system:index", SMOD_EPOCH))
            .first().select(SMOD_BAND))
    centres = smod.eq(URBAN_CENTRE_CODE).selfMask()

    def one_city(city) -> ee.Feature:
        point = ee.Geometry.Point([city.lon, city.lat])
        box = point.buffer(SEARCH_RADIUS_KM * 1000).bounds()
        vectors = centres.reduceToVectors(
            geometry=box, crs=smod.projection(), scale=SMOD_SCALE_M, geometryType="polygon",
            eightConnected=False, maxPixels=MAX_PIXELS,
        )
        hit = vectors.filterBounds(point)
        geom = ee.Feature(hit.first()).geometry()
        inner = box.buffer(-SMOD_SCALE_M * 2)  # touches the box if any part lies outside this
        return ee.Feature(geom, {"city": city.name, "n_hits": hit.size(),
                                 "touches_box": geom.difference(inner, 1).area(1).gt(0)})

    return ee.FeatureCollection([one_city(c) for c in cities]).getInfo()


def main() -> None:
    """Fetch urban-centre polygons and write extents, areas and provenance."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=list(CITIES), choices=list(CITIES))
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    cities = [CITIES[c] for c in args.cities]

    import ee_utils

    ee_utils.initialise()
    fc = urban_centre_polygons(cities)

    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for city, feat in zip(cities, fc["features"], strict=True):
        props = feat["properties"]
        if props["n_hits"] != 1:
            raise ValueError(f"{city.name}: centre is not inside an urban-centre cell "
                             f"({props['n_hits']} polygons hit)")
        gdf = gpd.GeoDataFrame.from_features([feat], crs="EPSG:4326")[["geometry"]]
        gdf = gdf.to_crs(f"EPSG:{city.epsg}")
        centre = gpd.GeoSeries([Point(city.lon, city.lat)], crs="EPSG:4326").to_crs(gdf.crs)
        aoi = centre.buffer(city.radius_km * 1000, quad_segs=AOI_QUAD_SEGS).iloc[0]
        geom = gdf.geometry.iloc[0]
        capped = gpd.GeoDataFrame(geometry=[geom.intersection(aoi)], crs=gdf.crs)
        capped.to_file(PROCESSED_DIR / f"extent_degurba_{city.name}.gpkg", driver="GPKG")
        rows.append({
            "city": city.name, "smod_epoch": SMOD_EPOCH,
            "extent_km2": round(geom.area / 1e6, 1),
            "inside_aoi_km2": round(geom.intersection(aoi).area / 1e6, 1),
            "touches_search_box": bool(props["touches_box"]),
        })
        if props["touches_box"]:
            LOG.warning("%s urban centre touches the search box: enlarge SEARCH_RADIUS_KM",
                        city.name)
    table = pd.DataFrame(rows)
    LOG.info("Degree of Urbanisation extents:\n%s", table.to_string(index=False))
    AREA_TABLE.parent.mkdir(parents=True, exist_ok=True)
    if AREA_TABLE.exists():  # keep rows for cities not re-run
        old = pd.read_csv(AREA_TABLE, encoding="utf-8")
        table = pd.concat([old[~old["city"].isin(args.cities)], table], ignore_index=True)
    table.to_csv(AREA_TABLE, index=False, encoding="utf-8")

    record = {
        "run_utc": datetime.now(UTC).isoformat(),
        "script": "gee/02b_degurba_extent.py",
        "gee_project": ee_utils.GEE_PROJECT,
        "dataset": SMOD_ID, "epoch": SMOD_EPOCH, "band": SMOD_BAND,
        "urban_centre_code": URBAN_CENTRE_CODE, "connectivity": 4,
        "grid": "native SMOD projection (World Mollweide, ESRI:54009), 1000 m",
        "search_radius_km": SEARCH_RADIUS_KM,
        "cities": args.cities,
        "note": "2025 epoch not used: it is a projection. Written extent is capped at the "
                "working AOI (same rule as the main extent); extent_km2 is the uncapped area.",
    }
    PROVENANCE.parent.mkdir(parents=True, exist_ok=True)
    PROVENANCE.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
