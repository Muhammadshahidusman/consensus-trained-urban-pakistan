"""Phase 3 (RQ1): agreement of WorldCover, Dynamic World and GHSL built-up maps in 2020.

Stage 1 (Earth Engine): on each city's 10 m UTM grid, encode which products call a pixel built
as a bit pattern, WorldCover class 50 = 1, Dynamic World annual mode class 6 = 2, GHSL built
fraction >= TAU_B = 4 (0 to 7; 255 outside the working AOI). The product count A(x) of
equation (1) is the number of set bits. GHSL (100 m) is resampled to 10 m by nearest
neighbour; WorldCover and Dynamic World are on 10 m grids already. The pattern image is
batch-exported to a project asset and downloaded in tiles (gee/ee_utils.py).

Stage 2 (local): area of each pattern and of each A(x) class inside two frames, the urban
extent (union of 2017 and 2023, gee/02_urban_extent.py) and the full working AOI, plus pairwise
agreement between products (overall agreement and Jaccard index of built).

The extent is the own-model study extent (gee/02_urban_extent.py --built-source model); stage 2
is re-run with ``--skip-download`` whenever that extent changes.

Outputs:
    data/interim/agreement/pattern_{city}_2020.tif        bit pattern, working AOI
    data/processed/agreement_{city}_2020.tif               band 1 A(x), band 2 pattern; extent
    outputs/tables/agreement_patterns.csv
    outputs/tables/agreement_pairwise.csv
    outputs/tables/Table3_consensus_summary.csv            area by A(x) class (partial)
    outputs/provenance/agreement_maps.json

Run:  python gee/03_agreement_maps.py --cities faisalabad
      python gee/03_agreement_maps.py
      python gee/03_agreement_maps.py --skip-download
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import sys
from datetime import UTC, datetime
from itertools import combinations
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from pyproj import Transformer
from rasterio import features

LOG = logging.getLogger("agreement_maps")

# --- Configuration -----------------------------------------------------------
YEAR = 2020
SCALE_M = 10
TAU_B = 0.50  # GHSL built fraction for "built" (equation 1)
PATTERN_NODATA = 255
PRODUCT_BITS = {"wc": 1, "dw": 2, "ghsl": 4}
FRAMES = ("extent", "aoi")
M2_PER_KM2 = 1e6

ROOT = Path(__file__).resolve().parents[1]
PATTERN_DIR = ROOT / "data" / "interim" / "agreement"
PROCESSED_DIR = ROOT / "data" / "processed"
TABLE_DIR = ROOT / "outputs" / "tables"
PATTERN_TABLE = TABLE_DIR / "agreement_patterns.csv"
PAIRWISE_TABLE = TABLE_DIR / "agreement_pairwise.csv"
SUMMARY_TABLE = TABLE_DIR / "Table3_consensus_summary.csv"
PROVENANCE = ROOT / "outputs" / "provenance" / "agreement_maps.json"


def _load(script: str, name: str):
    """Import a numbered script from gee/ as a module."""
    path = Path(__file__).with_name(script)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


URBAN_EXTENT = _load("02_urban_extent.py", "urban_extent")
CITIES = URBAN_EXTENT.CITIES
CONSENSUS = _load("01_consensus_labels.py", "consensus_labels")  # product definitions


# --- Stage 1: Earth Engine ---------------------------------------------------
def pattern_image(city):  # -> tuple[ee.Image, ee.Geometry]
    """Bit pattern of products calling each pixel built, clipped to the working AOI."""
    import ee

    if CONSENSUS.GHSL_BUILT_MIN != TAU_B or CONSENSUS.YEAR != YEAR:
        raise ValueError("TAU_B / YEAR must match gee/01_consensus_labels.py")
    aoi = ee.Geometry.Point([city.lon, city.lat]).buffer(city.radius_km * 1000)
    layers = CONSENSUS.product_layers(aoi)
    pattern = (
        layers["wc_built"].unmask(0).multiply(PRODUCT_BITS["wc"])
        .add(layers["dw_built"].unmask(0).multiply(PRODUCT_BITS["dw"]))
        .add(layers["ghsl_frac"].gte(TAU_B).unmask(0).multiply(PRODUCT_BITS["ghsl"]))
    )
    return pattern.toUint8().clip(aoi).unmask(PATTERN_NODATA).rename("pattern"), aoi


def aoi_bounds_utm(city) -> tuple[float, float, float, float]:
    """Bounding box of the working AOI circle in the city's UTM CRS."""
    to_utm = Transformer.from_crs("EPSG:4326", f"EPSG:{city.epsg}", always_xy=True)
    cx, cy = to_utm.transform(city.lon, city.lat)
    r = city.radius_km * 1000
    return cx - r, cy - r, cx + r, cy + r


def export_and_download(cities: list) -> dict[str, str]:
    """Export pattern images to assets, wait, and download them in tiles.

    Returns:
        Earth Engine task ID per city.
    """
    import ee_utils

    ee_utils.initialise()
    tasks = {}
    for city in cities:
        image, aoi = pattern_image(city)
        tasks[city.name] = ee_utils.export_image_to_asset(
            image, f"pattern_{city.name}_{YEAR}", aoi.bounds(), f"EPSG:{city.epsg}", SCALE_M)
    ee_utils.wait_for_tasks(list(tasks.values()))
    for city in cities:
        ee_utils.download_asset_tiled(
            f"pattern_{city.name}_{YEAR}", PATTERN_DIR / f"pattern_{city.name}_{YEAR}.tif",
            f"EPSG:{city.epsg}", SCALE_M, aoi_bounds_utm(city))
    return {name: t.id for name, t in tasks.items()}


# --- Stage 2: local statistics -----------------------------------------------
def n_built(pattern: np.ndarray) -> np.ndarray:
    """A(x): number of products calling the pixel built (popcount of the 3-bit pattern)."""
    return sum(((pattern & bit) > 0).astype(np.uint8) for bit in PRODUCT_BITS.values())


def pattern_areas(pattern: np.ndarray, frame: np.ndarray, pixel_km2: float) -> pd.DataFrame:
    """Area (km²) and share of each of the 8 patterns inside a boolean frame."""
    counts = np.bincount(pattern[frame].ravel(), minlength=8)[:8]
    rows = []
    for code in range(8):
        flags = {k: int(bool(code & bit)) for k, bit in PRODUCT_BITS.items()}
        rows.append({"pattern": code, **flags, "n_built": sum(flags.values()),
                     "km2": counts[code] * pixel_km2})
    out = pd.DataFrame(rows)
    out["pct"] = 100 * out["km2"] / out["km2"].sum()
    return out


def pairwise(pattern: np.ndarray, frame: np.ndarray) -> pd.DataFrame:
    """Overall agreement and Jaccard index of built for each pair of products."""
    p = pattern[frame]
    rows = []
    for (a, bit_a), (b, bit_b) in combinations(PRODUCT_BITS.items(), 2):
        built_a, built_b = (p & bit_a) > 0, (p & bit_b) > 0
        union = (built_a | built_b).sum()
        rows.append({
            "pair": f"{a}-{b}",
            "overall_agreement": float((built_a == built_b).mean()),
            "jaccard_built": float((built_a & built_b).sum() / union) if union else np.nan,
            "built_pct_first": float(100 * built_a.mean()),
            "built_pct_second": float(100 * built_b.mean()),
        })
    return pd.DataFrame(rows)


def summarise_city(city) -> tuple[list[pd.DataFrame], list[pd.DataFrame]]:
    """Pattern and pairwise tables for both frames; writes the extent agreement raster."""
    with rasterio.open(PATTERN_DIR / f"pattern_{city.name}_{YEAR}.tif") as src:
        pattern = src.read(1)
        profile = src.profile
    pixel_km2 = abs(profile["transform"].a * profile["transform"].e) / M2_PER_KM2
    # The asset holds only the AOI circle; the download fills the rest of the box with 0,
    # so the AOI frame is the circle itself (cell centres within the radius).
    aoi = URBAN_EXTENT.centre_distance(profile, city) <= city.radius_km * 1000
    pattern = np.where(aoi, pattern, PATTERN_NODATA).astype(np.uint8)
    union = gpd.read_file(PROCESSED_DIR / f"extent_{city.name}_union.gpkg").to_crs(profile["crs"])
    extent = features.geometry_mask(union.geometry, out_shape=pattern.shape,
                                    transform=profile["transform"], invert=True) & aoi
    frames = {"extent": extent, "aoi": aoi}

    counts = np.where(aoi, n_built(pattern), PATTERN_NODATA).astype(np.uint8)
    out = np.stack([np.where(extent, counts, PATTERN_NODATA),
                    np.where(extent, pattern, PATTERN_NODATA)]).astype(np.uint8)
    cog = {**profile, "count": 2, "dtype": "uint8", "nodata": PATTERN_NODATA,
           "compress": "deflate", "tiled": True, "blockxsize": 512, "blockysize": 512}
    with rasterio.open(PROCESSED_DIR / f"agreement_{city.name}_{YEAR}.tif", "w", **cog) as dst:
        dst.write(out)
        dst.set_band_description(1, "A(x) number of products built")
        dst.set_band_description(2, "pattern WC=1 DW=2 GHSL=4")
        dst.build_overviews([2, 4, 8, 16], rasterio.enums.Resampling.nearest)

    pat_tables, pair_tables = [], []
    for name, mask in frames.items():
        pat_tables.append(pattern_areas(pattern, mask, pixel_km2)
                          .assign(city=city.name, frame=name))
        pair_tables.append(pairwise(pattern, mask).assign(city=city.name, frame=name))
    return pat_tables, pair_tables


def summary_table(patterns: pd.DataFrame) -> pd.DataFrame:
    """Area (km²) and share (%) by A(x) class per city inside the urban extent (Table 3)."""
    ext = patterns[patterns["frame"] == "extent"]
    grouped = ext.groupby(["city", "n_built"])["km2"].sum().unstack(fill_value=0.0)
    out = pd.DataFrame(index=grouped.index)
    total = grouped.sum(axis=1)
    for k in range(4):
        out[f"A{k}_km2"] = grouped.get(k, 0.0).round(2)
        out[f"A{k}_pct"] = (100 * grouped.get(k, 0.0) / total).round(2)
    out["extent_km2"] = total.round(2)
    return out.reset_index()


def merge_rows(path: Path, new: pd.DataFrame, cities: list[str]) -> pd.DataFrame:
    """Replace rows of the re-run cities in an existing table."""
    if path.exists():
        old = pd.read_csv(path, encoding="utf-8")
        new = pd.concat([old[~old["city"].isin(cities)], new], ignore_index=True)
    return new


def main() -> None:
    """Export and download pattern images (stage 1) and summarise them (stage 2)."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=list(CITIES), choices=list(CITIES))
    parser.add_argument("--skip-download", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    cities = [CITIES[c] for c in args.cities]

    task_ids = {} if args.skip_download else export_and_download(cities)

    pat_tables, pair_tables = [], []
    for city in cities:
        p, q = summarise_city(city)
        pat_tables += p
        pair_tables += q
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    patterns = merge_rows(PATTERN_TABLE, pd.concat(pat_tables, ignore_index=True), args.cities)
    patterns.to_csv(PATTERN_TABLE, index=False, encoding="utf-8")
    pairs = merge_rows(PAIRWISE_TABLE, pd.concat(pair_tables, ignore_index=True), args.cities)
    pairs.to_csv(PAIRWISE_TABLE, index=False, encoding="utf-8")
    summary = summary_table(patterns)
    summary.to_csv(SUMMARY_TABLE, index=False, encoding="utf-8")
    LOG.info("Area by A(x) inside the urban extent:\n%s", summary.to_string(index=False))
    LOG.info("Pairwise agreement:\n%s", pairs.round(3).to_string(index=False))

    old_ids = {}
    if PROVENANCE.exists():
        old_ids = json.loads(PROVENANCE.read_text(encoding="utf-8")).get("task_ids", {})
    record = {
        "run_utc": datetime.now(UTC).isoformat(),
        "script": "gee/03_agreement_maps.py",
        "year": YEAR, "scale_m": SCALE_M, "tau_b": TAU_B,
        "products": {"wc": "ESA/WorldCover/v100 Map == 50",
                     "dw": "GOOGLE/DYNAMICWORLD/V1 annual mode of label == 6",
                     "ghsl": f"JRC/GHSL/P2023A/GHS_BUILT_S/{YEAR} built_surface / 10000 >= "
                             f"{TAU_B}, nearest-neighbour to 10 m"},
        "bits": PRODUCT_BITS, "frames": list(FRAMES),
        "extent_source": "data/processed/extent_{city}_union.gpkg (own model)",
        "cities": [c.name for c in CITIES.values()],
        "task_ids": {**old_ids, **task_ids},
    }
    PROVENANCE.parent.mkdir(parents=True, exist_ok=True)
    PROVENANCE.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
