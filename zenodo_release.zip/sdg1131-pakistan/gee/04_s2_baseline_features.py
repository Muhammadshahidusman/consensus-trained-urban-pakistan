"""Phase 4, Step 4.3: Sentinel-2 TOA baseline features at the consensus sample points.

For each city, build a dry-season median composite of Sentinel-2 L1C harmonized (TOA) with
Cloud Score+ masking (cs >= CS_MIN), using the January to March and October to December months
of the label year, so the composite stays within the same calendar year as the 2020 labels and
annual embeddings. Bands B2, B3, B4, B8, B11, B12 (reflectance, scaled by 1/10000) plus NDVI,
NDBI, MNDWI (equation 3) are sampled at the points of samples_{city}_2020 (asset written by
gee/01_consensus_labels.py) on the city's 10 m UTM grid; 20 m bands are taken from the pixel
that contains the point (nearest neighbour).

Outputs:
    data/interim/samples/s2_{city}_2020.csv   point_id + 9 features + n_obs (clear observations)
    outputs/provenance/s2_baseline_features.json

Run:  python gee/04_s2_baseline_features.py --cities faisalabad
      python gee/04_s2_baseline_features.py
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

import ee
import pandas as pd

LOG = logging.getLogger("s2_baseline")

# --- Configuration -----------------------------------------------------------
YEAR = 2020
S2_ID = "COPERNICUS/S2_HARMONIZED"
CS_ID = "GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED"
CS_BAND = "cs"
CS_MIN = 0.6
DRY_MONTHS = ((1, 3), (10, 12))  # inclusive month ranges within YEAR
S2_BANDS = ["B2", "B3", "B4", "B8", "B11", "B12"]
INDICES = ["NDVI", "NDBI", "MNDWI"]
REFLECTANCE_SCALE = 10_000
SCALE_M = 10
TILE_SCALE = 4

ROOT = Path(__file__).resolve().parents[1]
SAMPLE_DIR = ROOT / "data" / "interim" / "samples"
PROVENANCE = ROOT / "outputs" / "provenance" / "s2_baseline_features.json"
COLUMNS = ["point_id", *S2_BANDS, *INDICES, "n_obs"]


def _city_epsg() -> dict[str, int]:
    """City -> UTM EPSG from gee/01_consensus_labels.py (one source of truth)."""
    path = Path(__file__).with_name("01_consensus_labels.py")
    spec = importlib.util.spec_from_file_location("consensus_labels", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return {c.name: c.epsg for c in module.CITIES}


CITY_EPSG = _city_epsg()


def dry_season_filter(year: int) -> ee.Filter:
    """Date filter for the dry-season months of one calendar year."""
    parts = [
        ee.Filter.date(f"{year}-{m0:02d}-01", ee.Date.fromYMD(year, m1, 1).advance(1, "month"))
        for m0, m1 in DRY_MONTHS
    ]
    return ee.Filter.Or(*parts)


def s2_composite(region: ee.Geometry, year: int) -> ee.Image:
    """Cloud-masked dry-season TOA median with indices (equation 3) and clear-obs count."""
    collection = (
        ee.ImageCollection(S2_ID).filterBounds(region).filter(dry_season_filter(year))
        .linkCollection(ee.ImageCollection(CS_ID), [CS_BAND])
        .map(lambda img: img.updateMask(img.select(CS_BAND).gte(CS_MIN))
             .select(S2_BANDS).divide(REFLECTANCE_SCALE))
    )
    median = collection.median()
    ndvi = median.normalizedDifference(["B8", "B4"]).rename("NDVI")
    ndbi = median.normalizedDifference(["B11", "B8"]).rename("NDBI")
    mndwi = median.normalizedDifference(["B3", "B11"]).rename("MNDWI")
    n_obs = collection.select("B4").count().rename("n_obs")
    return median.addBands([ndvi, ndbi, mndwi, n_obs])


def city_features(city: str) -> ee.FeatureCollection:
    """S2 features sampled at the city's consensus sample points."""
    import ee_utils

    points = ee.FeatureCollection(ee_utils.asset_id(f"samples_{city}_{YEAR}")).select(["point_id"])
    image = s2_composite(points.geometry().bounds(), YEAR)
    return image.sampleRegions(collection=points, properties=["point_id"], scale=SCALE_M,
                               projection=f"EPSG:{CITY_EPSG[city]}", tileScale=TILE_SCALE,
                               geometries=True)  # asset tables need geometry


def check_join(city: str) -> int:
    """Rows of the sample file without S2 features (must be 0 for the done check)."""
    samples = pd.read_csv(SAMPLE_DIR / f"samples_{city}_{YEAR}.csv", encoding="utf-8",
                          usecols=["point_id"])
    s2 = pd.read_csv(SAMPLE_DIR / f"s2_{city}_{YEAR}.csv", encoding="utf-8")
    joined = samples.merge(s2, on="point_id", how="left")
    missing = int(joined[S2_BANDS + INDICES].isna().any(axis=1).sum())
    if missing:
        LOG.warning("%s: %d sample points lack S2 features", city, missing)
    return missing


def main() -> None:
    """Export S2 features for each city, download, and check the join."""
    import ee_utils

    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=list(CITY_EPSG), choices=list(CITY_EPSG))
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ee_utils.initialise()

    tasks = {c: ee_utils.export_table_to_asset(city_features(c), f"s2_{c}_{YEAR}")
             for c in args.cities}
    ee_utils.wait_for_tasks(list(tasks.values()))
    per_city = {}
    for c in args.cities:
        ee_utils.download_table_csv(f"s2_{c}_{YEAR}", SAMPLE_DIR / f"s2_{c}_{YEAR}.csv", COLUMNS)
        per_city[c] = {"task_id": tasks[c].id, "missing_rows": check_join(c),
                       "run_utc": datetime.now(UTC).isoformat()}

    old = {}
    if PROVENANCE.exists():
        old = json.loads(PROVENANCE.read_text(encoding="utf-8")).get("per_city", {})
    record = {
        "script": "gee/04_s2_baseline_features.py",
        "gee_project": ee_utils.GEE_PROJECT,
        "collection": S2_ID, "cloud_mask": f"{CS_ID} {CS_BAND} >= {CS_MIN}",
        "year": YEAR, "months": [list(m) for m in DRY_MONTHS], "reducer": "median",
        "bands": S2_BANDS, "indices": INDICES, "reflectance_scale": REFLECTANCE_SCALE,
        "scale_m": SCALE_M, "per_city": {**old, **per_city},
    }
    PROVENANCE.parent.mkdir(parents=True, exist_ok=True)
    PROVENANCE.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
