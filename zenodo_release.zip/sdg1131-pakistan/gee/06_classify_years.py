"""Phase 6: built-up maps 2017 and 2023 from the 2020 embedding model, plus comparison products.

Step 6.1: train an Earth Engine random forest (smileRandomForest, N_TREES trees, seed 42) once
and store it as the classifier asset rf_embed_2020. Training data: the pooled consensus samples
of all cities (assets samples_{city}_2020 from gee/01_consensus_labels.py), with the leaf size
chosen in Phase 5 (outputs/provenance/models.json, RF-Embed modal best params).

Step 6.2: classify the AlphaEarth embedding mosaics of 2017 and 2023 over each city's
working AOI (the whole AOI, so that Phase 2 extents can be re-derived from this model).

Step 6.4: comparison layers on the same 10 m UTM grid: Dynamic World annual mode built
(class 6) for 2017 and 2023, and GHSL built fraction for 2017 and 2023 by linear interpolation
between epochs (equation 15; 2023 uses the 2025 epoch, which is a GHSL projection).

One multi-band uint8 image per city is batch-exported to a project asset and downloaded in
tiles:
    built_2017, built_2023               own model, 1 built / 0 non-built
    dw_2017, dw_2023                     Dynamic World built
    ghsl_2017, ghsl_2023                 GHSL built fraction x 100 (100 m cells on 10 m grid)
255 = no data (outside AOI or no input).

Change map (Step 6.3) and per-class pixel counts are done locally in src/06_change_maps.py.

Outputs:
    data/interim/maps/maps_{city}.tif
    outputs/provenance/classify_years.json

Run:  python gee/06_classify_years.py --cities faisalabad
      python gee/06_classify_years.py
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

import ee
import geopandas as gpd

LOG = logging.getLogger("classify_years")

# --- Configuration -----------------------------------------------------------
SEED = 42
TRAIN_YEAR = 2020
MAP_YEARS = (2017, 2023)  # 2020 map dropped: unused downstream, saves EECU quota
COMPARE_YEARS = (2017, 2023)
N_TREES = 100  # 500 used ~14 EECU-h for one city; 100 vs 500 trees differ on 0.04% of
# spatial-CV test points (same OA 99.9%): src/05b_tree_count_check.py, docs/decisions.md
BAG_FRACTION = 0.632  # ~ share of distinct rows in a bootstrap sample (scikit-learn RF)
SCALE_M = 10
NODATA = 255
FRACTION_FACTOR = 100
DW_ID = "GOOGLE/DYNAMICWORLD/V1"
DW_BUILT_CLASS = 6
GHSL_ID = "JRC/GHSL/P2023A/GHS_BUILT_S"
GHSL_CELL_AREA_M2 = 10_000
GHSL_EPOCHS = {2017: (2015, 2020), 2023: (2020, 2025)}  # equation (15) bracketing epochs
EPOCH_STEP_Y = 5
CLASSIFIER_ASSET = "rf_embed_2020"

ROOT = Path(__file__).resolve().parents[1]
MAP_DIR = ROOT / "data" / "interim" / "maps"
PROCESSED_DIR = ROOT / "data" / "processed"
MODELS_JSON = ROOT / "outputs" / "provenance" / "models.json"
PROVENANCE = ROOT / "outputs" / "provenance" / "classify_years.json"


def _load(script: str, name: str):
    """Import a numbered script from gee/ as a module."""
    path = Path(__file__).with_name(script)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


CONSENSUS = _load("01_consensus_labels.py", "consensus_labels")
CITIES = {c.name: c for c in CONSENSUS.CITIES}
EMBED_BANDS = CONSENSUS.EMBED_BANDS


def rf_min_leaf() -> int:
    """Leaf size for the EE forest from the Phase 5 RF-Embed modal best parameters."""
    record = json.loads(MODELS_JSON.read_text(encoding="utf-8"))
    return int(record["models"]["RF-Embed"]["modal_best_params"]["min_samples_leaf"])


def ghsl_weight(year: int) -> float:
    """Interpolation weight of the later epoch (equation 15)."""
    early, _ = GHSL_EPOCHS[year]
    return (year - early) / EPOCH_STEP_Y


def train_classifier(min_leaf: int, variant: str = "") -> ee.Classifier:
    """Random forest on the pooled consensus samples of all cities (class = majority vote).

    Earth Engine cannot store a random forest in PROBABILITY mode, and a stored classifier
    cannot change its mode on load, so the deployed forest outputs classes only.
    """
    import ee_utils

    samples = ee.FeatureCollection([
        ee.FeatureCollection(ee_utils.asset_id(f"samples_{c}_{TRAIN_YEAR}{variant}"))
        for c in CITIES
    ]).flatten()
    return (
        ee.Classifier.smileRandomForest(
            numberOfTrees=N_TREES, minLeafPopulation=min_leaf, bagFraction=BAG_FRACTION,
            seed=SEED,
        )
        .train(features=samples, classProperty="label", inputProperties=EMBED_BANDS)
    )


def stored_classifier(min_leaf: int, retrain: bool, variant: str = ""
                      ) -> tuple[ee.Classifier, str | None]:
    """Train once and save the forest as an asset, then load it.

    An inline classifier is re-trained on every tile, which made a single city take hours;
    a stored classifier is trained once.

    Returns:
        The loaded classifier and the training task ID (None if an existing asset was used).
    """
    import ee_utils

    name = f"{CLASSIFIER_ASSET}{variant}"
    asset = ee_utils.asset_id(name)
    exists = True
    try:
        ee.data.getAsset(asset)
    except ee.EEException:
        exists = False
    task_id = None
    if retrain or not exists:
        if exists:
            ee.data.deleteAsset(asset)
        task = ee.batch.Export.classifier.toAsset(
            classifier=train_classifier(min_leaf, variant), description=name, assetId=asset)
        task.start()
        LOG.info("Training classifier asset %s (task %s)", name, task.id)
        ee_utils.wait_for_tasks([task])
        task_id = task.id
    return ee.Classifier.load(asset), task_id


def embedding_mosaic(aoi: ee.Geometry, year: int) -> ee.Image:
    """AlphaEarth annual embedding mosaic for one year."""
    return (
        ee.ImageCollection(CONSENSUS.EMBEDDING_ID).filterBounds(aoi)
        .filterDate(f"{year}-01-01", f"{year + 1}-01-01").mosaic().select(EMBED_BANDS)
    )


def ghsl_fraction(year: int) -> ee.Image:
    """GHSL built fraction interpolated to ``year`` (equation 15)."""
    early, late = GHSL_EPOCHS[year]
    w = ghsl_weight(year)
    f0 = ee.Image(f"{GHSL_ID}/{early}").select("built_surface").divide(GHSL_CELL_AREA_M2)
    f1 = ee.Image(f"{GHSL_ID}/{late}").select("built_surface").divide(GHSL_CELL_AREA_M2)
    return f0.add(f1.subtract(f0).multiply(w))


def extent_geometry(city) -> ee.Geometry:
    """Study extent (union, own model) as an Earth Engine geometry (EPSG:4326)."""
    ext = gpd.read_file(PROCESSED_DIR / f"extent_{city.name}_union.gpkg").to_crs("EPSG:4326")
    return ee.Geometry(ext.geometry.union_all().__geo_interface__)


def city_image(city, classifier: ee.Classifier, region: ee.Geometry | None = None,
               built_only: bool = False) -> tuple[ee.Image, ee.Geometry]:
    """Map (and comparison) bands for one city, uint8, clipped to ``region`` (default AOI)."""
    aoi = region if region is not None else CONSENSUS.city_aoi(city)
    bands = []
    for year in MAP_YEARS:
        bands.append(embedding_mosaic(aoi, year).classify(classifier).rename(f"built_{year}"))
    for year in ([] if built_only else COMPARE_YEARS):
        dw = (ee.ImageCollection(DW_ID).filterBounds(aoi)
              .filterDate(f"{year}-01-01", f"{year + 1}-01-01").select("label").mode())
        bands.append(dw.eq(DW_BUILT_CLASS).rename(f"dw_{year}"))
        bands.append(ghsl_fraction(year).multiply(FRACTION_FACTOR).round().rename(f"ghsl_{year}"))
    image = ee.Image.cat(bands).unmask(NODATA).toUint8().clip(aoi)
    return image.unmask(NODATA), aoi


def main() -> None:
    """Train, classify, export and download per-city map stacks; write provenance."""
    import ee_utils

    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=list(CITIES), choices=list(CITIES))
    parser.add_argument("--retrain", action="store_true", help="re-train the stored forest")
    parser.add_argument("--variant", default="",
                        help='Phase 10 suffix of the sample assets, e.g. "_tau040"')
    parser.add_argument("--download-only", action="store_true",
                        help="download existing maps assets without re-exporting")
    parser.add_argument("--extent-only", action="store_true",
                        help="Phase 10 variants: own-model bands only, inside the study extent")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ee_utils.initialise()
    agreement = _load("03_agreement_maps.py", "agreement_maps")

    min_leaf = rf_min_leaf()
    v = args.variant
    provenance = PROVENANCE.with_name(f"{PROVENANCE.stem}{v}.json")
    tasks = {}
    train_task = None
    if args.download_only:
        LOG.info("Download only: using existing maps assets")
    else:
        classifier, train_task = stored_classifier(min_leaf, args.retrain, v)
    for name in ([] if args.download_only else args.cities):
        city = CITIES[name]
        region = extent_geometry(city) if args.extent_only else None
        image, aoi = city_image(city, classifier, region, built_only=args.extent_only)
        tasks[name] = ee_utils.export_image_to_asset(
            image, f"maps_{name}{v}", aoi.bounds(), f"EPSG:{city.epsg}", SCALE_M)
    ee_utils.wait_for_tasks(list(tasks.values()))
    for name in args.cities:
        city = CITIES[name]
        if args.extent_only:
            bounds = tuple(gpd.read_file(PROCESSED_DIR / f"extent_{name}_union.gpkg")
                           .to_crs(f"EPSG:{city.epsg}").total_bounds)
        else:
            bounds = agreement.aoi_bounds_utm(city)
        ee_utils.download_asset_tiled(f"maps_{name}{v}", MAP_DIR / f"maps_{name}{v}.tif",
                                      f"EPSG:{city.epsg}", SCALE_M, bounds)

    old = {}
    if provenance.exists():
        old = json.loads(provenance.read_text(encoding="utf-8")).get("task_ids", {})
    record = {
        "run_utc": datetime.now(UTC).isoformat(),
        "script": "gee/06_classify_years.py",
        "gee_project": ee_utils.GEE_PROJECT,
        "classifier": {"type": "ee.Classifier.smileRandomForest", "numberOfTrees": N_TREES,
                       "minLeafPopulation": min_leaf, "bagFraction": BAG_FRACTION,
                       "seed": SEED, "output": "CLASSIFICATION (majority vote)",
                       "training": f"pooled samples_*_{TRAIN_YEAR} assets, all cities",
                       "asset": ee_utils.asset_id(f"{CLASSIFIER_ASSET}{v}"),
                       "features": "AlphaEarth A00-A63"},
        "embeddings": CONSENSUS.EMBEDDING_ID, "map_years": list(MAP_YEARS),
        "dynamic_world": f"{DW_ID} annual mode of label == {DW_BUILT_CLASS}",
        "ghsl": {"id": GHSL_ID, "epochs": {str(k): v for k, v in GHSL_EPOCHS.items()},
                 "weights": {str(y): ghsl_weight(y) for y in COMPARE_YEARS},
                 "note": "2025 epoch is a GHSL projection; stated as a limitation"},
        "grid": "city UTM, 10 m, working AOI", "nodata": NODATA,
        "task_ids": {**old, **{k: t.id for k, t in tasks.items()},
                     **({"classifier": train_task} if train_task else {})},
    }
    record["variant"] = v
    provenance.parent.mkdir(parents=True, exist_ok=True)
    provenance.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
