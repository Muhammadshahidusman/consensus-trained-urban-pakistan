"""Phase 9, Step 9.1: census population inside each study extent (dasymetric, equation 14).

Pop_ext = sum_u Census_u * GP(ext ∩ u) / GP(u), where u is a census unit polygon
(data/interim/census_units.gpkg, src/00_boundaries.py) and GP the gridded population. The
Rawalpindi study unit includes Islamabad, so the Islamabad Tehsil unit is added to Rawalpindi's
units. Units that do not touch the extent contribute zero.

Gridded population (``--pop-source``):
    ghspop   (baseline) GHS-POP R2023A, interpolated between epochs like equation (15):
             2017 = 2015 + 2/5 (2020 - 2015); 2023 = 2020 + 3/5 (2025 - 2020). The 2025 epoch is
             a GHSL projection; stated as a limitation.
    worldpop (Phase 10 sensitivity) WorldPop 100 m; the Earth Engine collection ends in 2020,
             so 2017 uses 2017 and 2023 uses 2020 (nearest available year).

Sums are taken on the population grid's native projection and scale. All units and
intersections of all cities are reduced in one request.

Outputs:
    data/processed/population_extent{_tag}.csv   city, year, pop_extent, census_units_total
    outputs/provenance/population{_tag}.json

Run:  python gee/09_population.py
      python gee/09_population.py --extent-tag dw_      (Dynamic World extents)
      python gee/09_population.py --pop-source worldpop
"""

from __future__ import annotations

import argparse
import json
import logging
from datetime import UTC, datetime
from pathlib import Path

import ee
import geopandas as gpd
import pandas as pd

LOG = logging.getLogger("population")

CITIES = ("karachi", "lahore", "faisalabad", "peshawar", "rawalpindi")
YEARS = (2017, 2023)
EXTRA_UNITS = {"rawalpindi": ["islamabad"]}  # Rawalpindi-Islamabad agglomeration
GHSPOP_ID = "JRC/GHSL/P2023A/GHS_POP"
GHSPOP_EPOCHS = {2017: (2015, 2020), 2023: (2020, 2025)}
EPOCH_STEP_Y = 5
WORLDPOP_ID = "WorldPop/GP/100m/pop"
WORLDPOP_YEARS = {2017: 2017, 2023: 2020}
WORLDPOP_COUNTRY = "PAK"
POP_SCALE_M = 100
MAX_PIXELS = 1e9

ROOT = Path(__file__).resolve().parents[1]
UNITS_GPKG = ROOT / "data" / "interim" / "census_units.gpkg"
PROCESSED_DIR = ROOT / "data" / "processed"
PROV_DIR = ROOT / "outputs" / "provenance"


def interpolation_weight(year: int) -> float:
    """Weight of the later GHS-POP epoch (as equation 15)."""
    early, _ = GHSPOP_EPOCHS[year]
    return (year - early) / EPOCH_STEP_Y


def pop_image(source: str, year: int) -> ee.Image:
    """Gridded population for a year, on its native grid."""
    if source == "ghspop":
        early, late = GHSPOP_EPOCHS[year]
        p0 = ee.Image(f"{GHSPOP_ID}/{early}").select("population_count")
        p1 = ee.Image(f"{GHSPOP_ID}/{late}").select("population_count")
        return p0.add(p1.subtract(p0).multiply(interpolation_weight(year))).rename("pop")
    col = (ee.ImageCollection(WORLDPOP_ID)
           .filter(ee.Filter.eq("country", WORLDPOP_COUNTRY))
           .filter(ee.Filter.eq("year", WORLDPOP_YEARS[year])))
    return col.mosaic().select("population").rename("pop").setDefaultProjection(
        col.first().projection())


def dasymetric(census: pd.Series, gp_unit: pd.Series, gp_inside: pd.Series) -> float:
    """Equation (14): sum_u Census_u * GP(ext ∩ u) / GP(u), over units with GP(u) > 0."""
    df = pd.DataFrame({"c": census, "u": gp_unit, "i": gp_inside})
    if (df["i"] > df["u"] * (1 + 1e-9)).any():
        raise ValueError("Population inside the extent exceeds the unit total")
    df = df[df["u"] > 0]
    return float((df["c"] * df["i"] / df["u"]).sum())


def build_features(units: gpd.GeoDataFrame, extent_tag: str) -> tuple[list, list[dict]]:
    """One feature per unit and per (unit ∩ extent), with keys for re-joining."""
    feats, keys = [], []
    for city in CITIES:
        members = units[units["city"].isin([city, *EXTRA_UNITS.get(city, [])])]
        path = PROCESSED_DIR / f"extent_{extent_tag}{city}_union.gpkg"
        if not path.exists():  # single-epoch extents (GHSL Degree of Urbanisation)
            path = PROCESSED_DIR / f"extent_{extent_tag}{city}.gpkg"
        ext = gpd.read_file(path)
        ext_geom = ext.to_crs("EPSG:4326").geometry.union_all()
        for _, u in members.iterrows():
            ugeom = gpd.GeoSeries([u.geometry], crs=units.crs).to_crs("EPSG:4326").iloc[0]
            inter = ugeom.intersection(ext_geom)
            for part, geom in (("unit", ugeom), ("inside", inter)):
                if geom.is_empty:
                    continue
                feats.append(ee.Feature(ee.Geometry(geom.__geo_interface__),
                                        {"key": len(keys)}))
                keys.append({"city": city, "group_id": u["group_id"], "part": part})
    return feats, keys


def main() -> None:
    """Reduce gridded population per unit and intersection; apply equation (14)."""
    import ee_utils

    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--pop-source", choices=["ghspop", "worldpop"], default="ghspop")
    parser.add_argument("--extent-tag", default="", help='"" (own model), "dw_", "degurba_"')
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ee_utils.initialise()

    units = gpd.read_file(UNITS_GPKG)
    feats, keys = build_features(units, args.extent_tag)
    fc = ee.FeatureCollection(feats)
    reduced = {}
    for year in YEARS:
        img = pop_image(args.pop_source, year)
        reduced[year] = img.reduceRegions(collection=fc, reducer=ee.Reducer.sum(),
                                          scale=POP_SCALE_M, crs=img.projection())
    sums = ee.Dictionary({str(y): r.aggregate_array("sum") for y, r in reduced.items()})
    order = ee.Dictionary({str(y): r.aggregate_array("key") for y, r in reduced.items()})
    result = ee.Dictionary({"sums": sums, "keys": order}).getInfo()  # one request

    rows = []
    for year in YEARS:
        gp = dict(zip(result["keys"][str(year)], result["sums"][str(year)], strict=True))
        table = pd.DataFrame(keys).assign(gp=[gp.get(i, 0.0) or 0.0 for i in range(len(keys))])
        wide = table.pivot_table(index=["city", "group_id"], columns="part", values="gp",
                                 aggfunc="sum", fill_value=0.0).reset_index()
        if "inside" not in wide:
            wide["inside"] = 0.0
        wide = wide.merge(units[["group_id", f"pop_{year}"]], on="group_id")
        for city, g in wide.groupby("city"):
            rows.append({
                "city": city, "year": year,
                "pop_extent": dasymetric(g[f"pop_{year}"], g["unit"], g["inside"]),
                "census_units_total": int(g[f"pop_{year}"].sum()),
                "gp_inside": float(g["inside"].sum()),
            })
    out = pd.DataFrame(rows)
    tag = "" if (args.pop_source, args.extent_tag) == ("ghspop", "") else \
        f"_{args.pop_source}_{args.extent_tag or 'model_'}".rstrip("_")
    path = PROCESSED_DIR / f"population_extent{tag}.csv"
    out.to_csv(path, index=False, encoding="utf-8")
    LOG.info("Population in extents:\n%s", out.to_string(index=False))

    record = {
        "run_utc": datetime.now(UTC).isoformat(), "script": "gee/09_population.py",
        "gee_project": ee_utils.GEE_PROJECT, "pop_source": args.pop_source,
        "dataset": GHSPOP_ID if args.pop_source == "ghspop" else WORLDPOP_ID,
        "interpolation": ({str(y): {"epochs": GHSPOP_EPOCHS[y],
                                    "weight": interpolation_weight(y)} for y in YEARS}
                          if args.pop_source == "ghspop" else
                          {str(y): f"WorldPop year {WORLDPOP_YEARS[y]}" for y in YEARS}),
        "extent": f"data/processed/extent_{args.extent_tag}{{city}}_union.gpkg",
        "units": str(UNITS_GPKG.relative_to(ROOT)), "extra_units": EXTRA_UNITS,
        "scale_m": POP_SCALE_M, "output": str(path.relative_to(ROOT)),
    }
    PROV_DIR.mkdir(parents=True, exist_ok=True)
    (PROV_DIR / f"population{tag}.json").write_text(json.dumps(record, indent=2),
                                                    encoding="utf-8")


if __name__ == "__main__":
    main()
