"""Phase 11: Sentinel-2 true-colour backgrounds for Fig 1 (city panels) and Fig 8 (zoom sites).

Composites: dry-season median of Sentinel-2 L1C TOA with Cloud Score+ masking, the same recipe
as the baseline features (gee/04_s2_baseline_features.py, s2_composite). True colour B4, B3,
B2 with a fixed linear stretch (reflectance 0 to RGB_MAX -> 0 to 255) for every city and year,
so panels are comparable.

    Fig 1: each working AOI, 2023, at OVERVIEW_SCALE_M (small, interactive download)
    Fig 8: three sites x 2017, 2023 at 10 m; a site is the SITE_KM window inside the study
           extent with the largest own-model new built-up share, in SITE_CITIES (rule fixed in
           advance, not picked by eye). Sites are written to data/interim/s2/sites.csv.

Never Google Earth or Esri imagery (CLAUDE.md). Attribution: "Contains modified Copernicus
Sentinel data [year]".

Outputs:
    data/interim/s2/rgb_{city}_2023.tif
    data/interim/s2/site_{n}_{year}.tif, data/interim/s2/sites.csv
    outputs/provenance/s2_rgb.json

Run:  python gee/12_s2_rgb.py
"""

from __future__ import annotations

import importlib.util
import json
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

import ee
import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from rasterio import features

LOG = logging.getLogger("s2_rgb")

OVERVIEW_YEAR = 2023
SITE_YEARS = (2017, 2023)
OVERVIEW_SCALE_M = 60
SITE_SCALE_M = 10
SITE_KM = 3
SITE_CITIES = ("lahore", "karachi", "peshawar")
RGB_BANDS = ["B4", "B3", "B2"]
RGB_MAX = 0.3  # reflectance mapped to 255
NEW_BUILT = 2  # change-map class
NODATA = 255

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "interim" / "s2"
PROCESSED = ROOT / "data" / "processed"
PROVENANCE = ROOT / "outputs" / "provenance" / "s2_rgb.json"


def _load(script: str, name: str):
    path = Path(__file__).with_name(script)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


S2 = _load("04_s2_baseline_features.py", "s2_baseline")
CITIES = {c.name: c for c in _load("01_consensus_labels.py", "consensus_labels").CITIES}


def rgb_image(region: ee.Geometry, year: int) -> ee.Image:
    """Stretched uint8 true-colour composite."""
    comp = S2.s2_composite(region, year).select(RGB_BANDS)
    return comp.divide(RGB_MAX).multiply(255).clamp(0, 255).toUint8()


def best_window(change: np.ndarray, inside: np.ndarray, win_px: int) -> tuple[int, int, float]:
    """Top-left (row, col) of the window with the largest new built-up share inside the extent.

    Windows are stepped by half their size; only windows fully inside the extent count.
    """
    best = (0, 0, -1.0)
    step = win_px // 2
    for r in range(0, change.shape[0] - win_px + 1, step):
        for c in range(0, change.shape[1] - win_px + 1, step):
            w_in = inside[r:r + win_px, c:c + win_px]
            if not w_in.all():
                continue
            share = float((change[r:r + win_px, c:c + win_px] == NEW_BUILT).mean())
            if share > best[2]:
                best = (r, c, share)
    return best


def choose_sites() -> pd.DataFrame:
    """One site per SITE_CITIES city by the fixed rule; centre in lon/lat and UTM."""
    rows = []
    for n, city in enumerate(SITE_CITIES, start=1):
        with rasterio.open(PROCESSED / f"change_{city}_2017_2023.tif") as src:
            change, transform, crs = src.read(1), src.transform, src.crs
        ext = gpd.read_file(PROCESSED / f"extent_{city}_union.gpkg").to_crs(crs)
        inside = features.geometry_mask(ext.geometry, out_shape=change.shape,
                                        transform=transform, invert=True)
        win = int(SITE_KM * 1000 / abs(transform.a))
        r, c, share = best_window(change, inside, win)
        x, y = rasterio.transform.xy(transform, r + win // 2, c + win // 2)
        centre = gpd.GeoSeries.from_xy([x], [y], crs=crs).to_crs("EPSG:4326").iloc[0]
        lon, lat = centre.x, centre.y
        rows.append({"site": n, "city": city, "x": x, "y": y, "lon": lon, "lat": lat,
                     "epsg": crs.to_epsg(), "new_built_share": share})
    return pd.DataFrame(rows)


def main() -> None:
    """Download overview and site composites; write site table and provenance."""
    import ee_utils

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ee_utils.initialise()
    # Interactive requests exceed EE user memory (median over many scenes), so every composite
    # is batch-exported to a project asset and then downloaded.
    jobs = []  # (asset name, image, region, crs, scale, out path)
    for name, city in CITIES.items():
        aoi = ee.Geometry.Point([city.lon, city.lat]).buffer(city.radius_km * 1000)
        stem = f"rgb_{name}_{OVERVIEW_YEAR}"
        jobs.append((stem, rgb_image(aoi, OVERVIEW_YEAR), aoi.bounds(), f"EPSG:{city.epsg}",
                     OVERVIEW_SCALE_M, OUT / f"{stem}.tif"))
    sites = choose_sites()
    OUT.mkdir(parents=True, exist_ok=True)
    sites.to_csv(OUT / "sites.csv", index=False, encoding="utf-8")
    half = SITE_KM * 1000 / 2
    for s in sites.itertuples():
        box = ee.Geometry.Rectangle([s.x - half, s.y - half, s.x + half, s.y + half],
                                    proj=f"EPSG:{s.epsg}", geodesic=False)
        for year in SITE_YEARS:
            jobs.append((f"site_{s.site}_{year}", rgb_image(box, year), box, f"EPSG:{s.epsg}",
                         SITE_SCALE_M, OUT / f"site_{s.site}_{year}.tif"))
    tasks = [ee_utils.export_image_to_asset(img, name, region, crs, scale)
             for name, img, region, crs, scale, _ in jobs]
    ee_utils.wait_for_tasks(tasks)
    for name, _, _, crs, scale, out in jobs:
        ee_utils.download_asset(name, out, crs, scale)
    record = {
        "run_utc": datetime.now(UTC).isoformat(), "script": "gee/12_s2_rgb.py",
        "gee_project": ee_utils.GEE_PROJECT, "task_ids": [t.id for t in tasks],
        "composite": f"gee/04 s2_composite (dry season, Cloud Score+ >= {S2.CS_MIN})",
        "bands": RGB_BANDS, "stretch_max": RGB_MAX,
        "overview": {"year": OVERVIEW_YEAR, "scale_m": OVERVIEW_SCALE_M},
        "sites": {"rule": f"{SITE_KM} km window fully inside the study extent with the largest "
                          "own-model new built-up share", "cities": SITE_CITIES,
                  "years": SITE_YEARS, "scale_m": SITE_SCALE_M},
    }
    PROVENANCE.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
