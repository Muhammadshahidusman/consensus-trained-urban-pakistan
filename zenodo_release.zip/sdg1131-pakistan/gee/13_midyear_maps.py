"""Review response: own-model maps for the years between 2017 and 2023, inside the study extent.

The 2017 and 2023 maps were classified independently, and reversals reach 30 to 50% of the new
built-up area. Classifying the years between them shows how stable the maps are from year to
year and allows the temporal consistency rule of src/10b_lcrpgr_mapped.py. The stored 2020 forest
is reused unchanged, so nothing is re-trained. The year 2020 is the training year and is left out.

Outputs:
    data/interim/maps/maps_{city}_midyears.tif   bands built_2018, 2019, 2021, 2022 (uint8)
    outputs/provenance/midyear_maps.json

Run:  python gee/13_midyear_maps.py --cities faisalabad
      python gee/13_midyear_maps.py
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

import ee
import geopandas as gpd

LOG = logging.getLogger("midyear_maps")

MID_YEARS = (2018, 2019, 2021, 2022)
SUFFIX = "_midyears"
ROOT = Path(__file__).resolve().parents[1]
PROVENANCE = ROOT / "outputs" / "provenance" / "midyear_maps.json"


def _load(script: str, name: str):
    """Import a numbered script from gee/ as a module."""
    path = Path(__file__).with_name(script)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


CLASSIFY = _load("06_classify_years.py", "classify_years")


def main() -> None:
    """Classify the middle years, export to assets, download and write provenance."""
    import ee_utils

    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=list(CLASSIFY.CITIES),
                        choices=list(CLASSIFY.CITIES))
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ee_utils.initialise()
    classifier = ee.Classifier.load(ee_utils.asset_id(CLASSIFY.CLASSIFIER_ASSET))
    tasks = {}
    for name in args.cities:
        city = CLASSIFY.CITIES[name]
        region = CLASSIFY.extent_geometry(city)
        bands = [CLASSIFY.embedding_mosaic(region, y).classify(classifier).rename(f"built_{y}")
                 for y in MID_YEARS]
        image = ee.Image.cat(bands).unmask(CLASSIFY.NODATA).toUint8().clip(region)
        tasks[name] = ee_utils.export_image_to_asset(
            image.unmask(CLASSIFY.NODATA), f"maps_{name}{SUFFIX}", region.bounds(),
            f"EPSG:{city.epsg}", CLASSIFY.SCALE_M)
    ee_utils.wait_for_tasks(list(tasks.values()))
    for name in args.cities:
        city = CLASSIFY.CITIES[name]
        bounds = tuple(gpd.read_file(CLASSIFY.PROCESSED_DIR / f"extent_{name}_union.gpkg")
                       .to_crs(f"EPSG:{city.epsg}").total_bounds)
        ee_utils.download_asset_tiled(f"maps_{name}{SUFFIX}",
                                      CLASSIFY.MAP_DIR / f"maps_{name}{SUFFIX}.tif",
                                      f"EPSG:{city.epsg}", CLASSIFY.SCALE_M, bounds)
    old = json.loads(PROVENANCE.read_text(encoding="utf-8")) if PROVENANCE.exists() else {}
    record = {
        "run_utc": datetime.now(UTC).isoformat(), "script": "gee/13_midyear_maps.py",
        "gee_project": ee_utils.GEE_PROJECT, "years": list(MID_YEARS),
        "classifier_asset": ee_utils.asset_id(CLASSIFY.CLASSIFIER_ASSET),
        "embeddings": CLASSIFY.CONSENSUS.EMBEDDING_ID, "scale_m": CLASSIFY.SCALE_M,
        "region": "study extent (union, own model)",
        "task_ids": {**old.get("task_ids", {}), **{k: t.id for k, t in tasks.items()}},
    }
    PROVENANCE.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
