"""Review response: Open Buildings 2.5D Temporal as an independent comparison (PRD FR-16).

Open Buildings was not used for labels or training, so it can be compared with all three sources,
including on the disputed pixels that consensus labels leave out. It is itself a model output,
so results from it are agreement with another map, never accuracy. It is not used anywhere near
the validation sample: those points are for human interpretation only.

For each city and year, take building_presence >= PRESENCE_MIN, resample to the dataset's effective
4 m resolution, and store the building share of each 10 m cell of the city's UTM grid.

Outputs:
    data/processed/ob_{city}.tif   bands ob_2017, ob_2023: % building area of the cell (255 NoData)
    outputs/provenance/open_buildings.json

Run:  python gee/14_open_buildings.py --cities faisalabad
      python gee/14_open_buildings.py
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

import ee

LOG = logging.getLogger("open_buildings")

OB_ID = "GOOGLE/Research/open-buildings-temporal/v1"
OB_BAND = "building_presence"
PRESENCE_MIN = 0.5
EFFECTIVE_SCALE_M = 4
MAX_PIXELS_PER_CELL = 16
YEARS = (2017, 2023)
PERCENT = 100
ROOT = Path(__file__).resolve().parents[1]
PROVENANCE = ROOT / "outputs" / "provenance" / "open_buildings.json"


def _load(script: str, name: str):
    """Import a numbered script from gee/ as a module."""
    path = Path(__file__).with_name(script)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


CLASSIFY = _load("06_classify_years.py", "classify_years")
AGREEMENT = _load("03_agreement_maps.py", "agreement_maps")


def building_share(aoi: ee.Geometry, year: int, crs: str) -> ee.Image:
    """Building share (%) of each 10 m cell for one year."""
    presence = (ee.ImageCollection(OB_ID).filterBounds(aoi)
                .filterDate(f"{year}-01-01", f"{year + 1}-01-01").select(OB_BAND).mosaic())
    fine = presence.gte(PRESENCE_MIN).reproject(crs=crs, scale=EFFECTIVE_SCALE_M)
    share = fine.reduceResolution(ee.Reducer.mean(), maxPixels=MAX_PIXELS_PER_CELL).reproject(
        crs=crs, scale=CLASSIFY.SCALE_M)
    return share.multiply(PERCENT).round().rename(f"ob_{year}")


def main() -> None:
    """Export, download and write provenance."""
    import ee_utils

    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=list(CLASSIFY.CITIES),
                        choices=list(CLASSIFY.CITIES))
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ee_utils.initialise()
    tasks = {}
    for name in args.cities:
        city = CLASSIFY.CITIES[name]
        aoi = CLASSIFY.CONSENSUS.city_aoi(city)
        crs = f"EPSG:{city.epsg}"
        image = ee.Image.cat([building_share(aoi, y, crs) for y in YEARS])
        image = image.unmask(CLASSIFY.NODATA).toUint8().clip(aoi).unmask(CLASSIFY.NODATA)
        tasks[name] = ee_utils.export_image_to_asset(image, f"ob_{name}", aoi.bounds(), crs,
                                                     CLASSIFY.SCALE_M)
    ee_utils.wait_for_tasks(list(tasks.values()))
    for name in args.cities:
        city = CLASSIFY.CITIES[name]
        ee_utils.download_asset_tiled(f"ob_{name}", CLASSIFY.PROCESSED_DIR / f"ob_{name}.tif",
                                      f"EPSG:{city.epsg}", CLASSIFY.SCALE_M,
                                      AGREEMENT.aoi_bounds_utm(city))
    old = json.loads(PROVENANCE.read_text(encoding="utf-8")) if PROVENANCE.exists() else {}
    record = {
        "run_utc": datetime.now(UTC).isoformat(), "script": "gee/14_open_buildings.py",
        "gee_project": ee_utils.GEE_PROJECT, "dataset": OB_ID, "band": OB_BAND,
        "presence_min": PRESENCE_MIN, "effective_scale_m": EFFECTIVE_SCALE_M,
        "scale_m": CLASSIFY.SCALE_M, "years": list(YEARS),
        "note": "Independent comparison only. Never used to label the validation sample.",
        "task_ids": {**old.get("task_ids", {}), **{k: t.id for k, t in tasks.items()}},
    }
    PROVENANCE.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
