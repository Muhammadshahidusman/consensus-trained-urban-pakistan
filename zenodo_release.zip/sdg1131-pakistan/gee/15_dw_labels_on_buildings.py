"""Review response: what does Dynamic World call the densest building cells?

Inside the study extent Dynamic World shows almost no correlation with the Open Buildings share,
and its non-built pixels hold many buildings. This script counts the Dynamic World 2023 mode label
over cells where at least DENSE_MIN_PCT of the 10 m cell is building, and over all cells, to show
which class takes those pixels. It describes the disagreement; it says nothing on accuracy.

Outputs:
    outputs/tables/dw_labels_on_buildings.csv   city, scope, class, pixels, share_pct
    outputs/provenance/dw_labels_on_buildings.json

Run:  python gee/15_dw_labels_on_buildings.py --cities faisalabad
      python gee/15_dw_labels_on_buildings.py
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

import ee
import pandas as pd

LOG = logging.getLogger("dw_labels")

DENSE_MIN_PCT = 50
YEAR = 2023
MAX_PIXELS = 1e9
CENTROID_ERROR_M = 1000
PERCENT = 100
TABLE_ASSET = "dw_labels_on_buildings"
DW_CLASSES = {0: "water", 1: "trees", 2: "grass", 3: "flooded vegetation", 4: "crops",
              5: "shrub and scrub", 6: "built", 7: "bare", 8: "snow and ice"}
ROOT = Path(__file__).resolve().parents[1]
OUT_CSV = ROOT / "outputs" / "tables" / "dw_labels_on_buildings.csv"
PROVENANCE = ROOT / "outputs" / "provenance" / "dw_labels_on_buildings.json"


def _load(script: str, name: str):
    """Import a numbered script from gee/ as a module."""
    path = Path(__file__).with_name(script)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


CLASSIFY = _load("06_classify_years.py", "classify_years")


def city_feature(name: str, asset_id: str) -> ee.Feature:
    """Label histograms for one city: dense building cells and all cells of the study extent."""
    city = CLASSIFY.CITIES[name]
    region = CLASSIFY.extent_geometry(city)
    label = (ee.ImageCollection(CLASSIFY.DW_ID).filterBounds(region)
             .filterDate(f"{YEAR}-01-01", f"{YEAR + 1}-01-01").select("label").mode())
    ob = ee.Image(asset_id).select(f"ob_{YEAR}")
    dense = ob.gte(DENSE_MIN_PCT).And(ob.neq(CLASSIFY.NODATA))

    def histogram(image: ee.Image, scope: str) -> ee.Dictionary:
        counts = ee.Dictionary(image.reduceRegion(
            ee.Reducer.frequencyHistogram(), region, scale=CLASSIFY.SCALE_M,
            crs=f"EPSG:{city.epsg}", maxPixels=MAX_PIXELS).get("label"))
        keys = counts.keys()
        return counts.rename(keys, keys.map(lambda k: ee.String(f"{scope}_").cat(k)))

    return (ee.Feature(region.centroid(CENTROID_ERROR_M), {"city": name})
            .set(histogram(label.updateMask(dense), "dense")).set(histogram(label, "all")))


def rows(features: list[dict]) -> pd.DataFrame:
    """Long table of pixel counts and shares from the exported features."""
    out = []
    for feature in features:
        props = feature["properties"]
        for scope in ("dense", "all"):
            hist = {int(float(k.split("_")[1])): v for k, v in props.items()
                    if k.startswith(f"{scope}_") and v is not None}
            total = sum(hist.values())
            out += [{"city": props["city"], "scope": scope, "class": DW_CLASSES[k], "pixels": v,
                     "share_pct": PERCENT * v / total} for k, v in sorted(hist.items())]
    return pd.DataFrame(out)


def main() -> None:
    """Count labels in one batch task, then read the result table once."""
    import ee_utils

    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=list(CLASSIFY.CITIES),
                        choices=list(CLASSIFY.CITIES))
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ee_utils.initialise()
    table = ee.FeatureCollection([city_feature(n, ee_utils.asset_id(f"ob_{n}"))
                                  for n in args.cities])
    tag = f"{TABLE_ASSET}_{'_'.join(args.cities)}" if len(args.cities) < len(CLASSIFY.CITIES) \
        else TABLE_ASSET
    asset = ee_utils.asset_id(tag)
    try:
        ee.data.deleteAsset(asset)
    except ee.EEException:
        LOG.info("No earlier result table")
    task = ee.batch.Export.table.toAsset(collection=table, description=tag, assetId=asset)
    task.start()
    ee_utils.wait_for_tasks([task])
    result = rows(ee.FeatureCollection(asset).getInfo()["features"])
    result.to_csv(OUT_CSV, index=False, encoding="utf-8")
    LOG.info("Labels:\n%s", result.round(2).to_string(index=False))
    PROVENANCE.write_text(json.dumps({
        "run_utc": datetime.now(UTC).isoformat(), "script": "gee/15_dw_labels_on_buildings.py",
        "gee_project": ee_utils.GEE_PROJECT, "dataset": CLASSIFY.DW_ID, "year": YEAR,
        "dense_min_pct": DENSE_MIN_PCT, "scale_m": CLASSIFY.SCALE_M, "cities": args.cities,
        "task_id": task.id}, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
