"""Shared Earth Engine helpers: batch export to project assets, wait, download.

Interactive requests time out on year-long 10 m composites, so heavy images are exported with
``Export.image.toAsset`` (batch, no time limit). Once stored, an asset downloads quickly with
``getDownloadURL`` because nothing is recomputed. This replaces manual copying from Drive for
rasters under the download size limit.

Imported by the numbered scripts in gee/ (they run with gee/ on sys.path).
"""

from __future__ import annotations

import logging
import time
from pathlib import Path

import ee
import numpy as np
import rasterio
import requests
from rasterio.merge import merge

LOG = logging.getLogger("ee_utils")

GEE_PROJECT = "earthengine-512818"
ASSET_ROOT = f"projects/{GEE_PROJECT}/assets/sdg1131"
MAX_PIXELS = 1e10
POLL_INTERVAL_S = 30
TASK_TIMEOUT_S = 6 * 3600
DOWNLOAD_TIMEOUT_S = 600
DOWNLOAD_RETRIES = 4
RETRY_WAIT_S = 20
MAX_REQUEST_BYTES = 40_000_000  # per download request; EE caps a request at 48 MiB
BYTES_PER_BAND_PIXEL = 2  # conservative (EE may count uint8 bands as wider)
DONE_STATES = {"COMPLETED", "FAILED", "CANCELLED"}


def _get(url: str) -> requests.Response:
    """GET with retries on dropped connections and 5xx responses (transient network errors)."""
    for attempt in range(1, DOWNLOAD_RETRIES + 1):
        try:
            response = requests.get(url, timeout=DOWNLOAD_TIMEOUT_S)
            if response.status_code < 500:
                response.raise_for_status()
                return response
            LOG.warning("HTTP %d (attempt %d/%d)", response.status_code, attempt,
                        DOWNLOAD_RETRIES)
        except (requests.ConnectionError, requests.Timeout) as e:
            LOG.warning("Download failed (attempt %d/%d): %s", attempt, DOWNLOAD_RETRIES, e)
        time.sleep(RETRY_WAIT_S * attempt)
    raise RuntimeError(f"Download failed after {DOWNLOAD_RETRIES} attempts")


def initialise() -> None:
    """Initialise Earth Engine and make sure the project asset folder exists."""
    ee.Initialize(project=GEE_PROJECT)
    try:
        ee.data.getAsset(ASSET_ROOT)
    except ee.EEException:
        ee.data.createAsset({"type": "FOLDER"}, ASSET_ROOT)
        LOG.info("Created asset folder %s", ASSET_ROOT)


def asset_id(name: str) -> str:
    """Full asset ID for a short name inside the project folder."""
    return f"{ASSET_ROOT}/{name}"


def export_image_to_asset(image: ee.Image, name: str, region: ee.Geometry, crs: str,
                          scale: float) -> ee.batch.Task:
    """Start a batch export of ``image`` to ``ASSET_ROOT/name`` (overwrites).

    Returns:
        The started task.
    """
    task = ee.batch.Export.image.toAsset(
        image=image, description=name, assetId=asset_id(name), region=region,
        crs=crs, scale=scale, maxPixels=MAX_PIXELS, overwrite=True,
    )
    task.start()
    LOG.info("Started export %s (task %s)", name, task.id)
    return task


def wait_for_tasks(tasks: list[ee.batch.Task]) -> dict[str, str]:
    """Poll task status until all tasks finish.

    Returns:
        Mapping task description -> final state.

    Raises:
        RuntimeError: If any task fails or the timeout is reached.
    """
    start = time.monotonic()
    pending = {t.id: t for t in tasks}
    states: dict[str, str] = {}
    while pending:
        statuses = ee.data.getTaskStatus(list(pending))
        for status in statuses:
            if status["state"] in DONE_STATES:
                task = pending.pop(status["id"])
                states[task.config.get("description", task.id)] = status["state"]
                LOG.info("Task %s: %s %s", status.get("description"), status["state"],
                         status.get("error_message", ""))
        if pending:
            if time.monotonic() - start > TASK_TIMEOUT_S:
                raise RuntimeError(f"Tasks still running after {TASK_TIMEOUT_S} s")
            time.sleep(POLL_INTERVAL_S)
    failed = {k: v for k, v in states.items() if v != "COMPLETED"}
    if failed:
        raise RuntimeError(f"Export tasks did not complete: {failed}")
    return states


def download_asset(name: str, out_path: Path, crs: str, scale: float) -> None:
    """Download a stored image asset as GeoTIFF on its own grid."""
    image = ee.Image(asset_id(name))
    url = image.getDownloadURL({
        "region": image.geometry(), "crs": crs, "scale": scale, "format": "GEO_TIFF",
    })
    response = _get(url)
    response.raise_for_status()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(response.content)
    LOG.info("Downloaded %s (%.1f MB)", out_path.name, len(response.content) / 1e6)


def download_asset_tiled(name: str, out_path: Path, crs: str, scale: float,
                         bounds_xy: tuple[float, float, float, float]) -> None:
    """Download a large stored image asset in tiles on a fixed grid and merge them.

    Tiles share the grid origin (xmin, ymax) and pixel size, so they mosaic without
    resampling.

    Args:
        name: Asset short name.
        out_path: Merged GeoTIFF path.
        crs: Projected CRS of the grid, e.g. "EPSG:32643".
        scale: Pixel size in CRS units.
        bounds_xy: (xmin, ymin, xmax, ymax) in ``crs``; snapped outwards to the pixel grid.
    """
    image = ee.Image(asset_id(name))
    band_names = image.bandNames().getInfo()  # one request; written as band descriptions
    xmin, ymin, xmax, ymax = bounds_xy
    xmin, ymin = np.floor(xmin / scale) * scale, np.floor(ymin / scale) * scale
    xmax, ymax = np.ceil(xmax / scale) * scale, np.ceil(ymax / scale) * scale
    width, height = int(round((xmax - xmin) / scale)), int(round((ymax - ymin) / scale))
    request_bytes = width * height * len(band_names) * BYTES_PER_BAND_PIXEL
    n_side = int(np.ceil(np.sqrt(request_bytes / MAX_REQUEST_BYTES)))
    col_edges = np.linspace(0, width, n_side + 1).astype(int)
    row_edges = np.linspace(0, height, n_side + 1).astype(int)
    tmp_dir = out_path.parent / f"_{out_path.stem}_tiles"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tiles = []
    for i in range(n_side):
        for j in range(n_side):
            x0 = xmin + col_edges[j] * scale
            y0 = ymax - row_edges[i] * scale
            dims = f"{col_edges[j + 1] - col_edges[j]}x{row_edges[i + 1] - row_edges[i]}"
            url = image.getDownloadURL({
                "crs": crs, "crs_transform": [scale, 0, x0, 0, -scale, y0],
                "dimensions": dims, "format": "GEO_TIFF",
            })
            response = _get(url)
            response.raise_for_status()
            tile = tmp_dir / f"tile_{i}_{j}.tif"
            tile.write_bytes(response.content)
            tiles.append(tile)
    sources = [rasterio.open(t) for t in tiles]
    try:
        mosaic, transform = merge(sources)
        profile = sources[0].profile
    finally:
        for src in sources:
            src.close()
    profile.update(width=mosaic.shape[2], height=mosaic.shape[1], transform=transform,
                   compress="deflate", tiled=True, blockxsize=512, blockysize=512)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(mosaic)
        for i, band in enumerate(band_names, start=1):
            dst.set_band_description(i, band)
    for t in tiles:
        t.unlink()
    tmp_dir.rmdir()
    LOG.info("Downloaded %s in %d tiles (%dx%d px)", out_path.name, len(tiles), width, height)


def export_table_to_asset(collection: ee.FeatureCollection, name: str) -> ee.batch.Task:
    """Start a batch export of a FeatureCollection to ``ASSET_ROOT/name``.

    An existing asset of that name is deleted first (table exports cannot overwrite).

    Returns:
        The started task.
    """
    try:
        ee.data.deleteAsset(asset_id(name))
        LOG.info("Deleted existing asset %s", name)
    except ee.EEException:
        pass  # asset did not exist
    task = ee.batch.Export.table.toAsset(collection=collection, description=name,
                                         assetId=asset_id(name))
    task.start()
    LOG.info("Started table export %s (task %s)", name, task.id)
    return task


def download_table_csv(name: str, out_path: Path, columns: list[str]) -> None:
    """Download a stored table asset as CSV with the given columns."""
    url = ee.FeatureCollection(asset_id(name)).getDownloadURL(
        filetype="csv", selectors=columns, filename=out_path.stem)
    response = _get(url)
    response.raise_for_status()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(response.content)
    LOG.info("Downloaded %s (%.1f MB)", out_path.name, len(response.content) / 1e6)
