"""Export admin boundaries and link census units to polygons (PCD.md Step 1.2).

The HDX COD-AB boundaries (valid_on 2022-09-09) predate several 2023 census sub-district units.
Each city therefore uses the finest level at which census units and polygons describe the same
area:

    rawalpindi, islamabad              tehsil   (1:1, spelling aliases below)
    lahore, peshawar                   district (2023 tehsils differ from the polygons)
    faisalabad                         district (names match, but tehsil areas differ by
                                                 up to 21 %, so the polygons are not the
                                                 census tehsils)
    karachi                            division (7 census districts vs 6 older polygons)

Equation (14) only needs population totals for areas with known polygons, so coarser units
are valid; they just give GHS-POP more area to distribute.

Outputs:
    data/raw/boundaries/pak_adm2.gpkg, pak_adm3.gpkg       (unchanged copies of HDX layers)
    data/interim/census_boundary_lookup.csv                 (one row per census group)
    data/interim/census_units.gpkg                          (dissolved polygons + pop 2017/2023)

Run:  python src/00_boundaries.py
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import pandas as pd

LOG = logging.getLogger("boundaries")

ROOT = Path(__file__).resolve().parents[1]
GDB = ROOT / "data" / "raw" / "boundaries" / "_download" / "gdb" / "pak_admin_boundaries.gdb"
BOUNDARY_DIR = ROOT / "data" / "raw" / "boundaries"
CENSUS_DIR = ROOT / "data" / "raw" / "census"
INTERIM_DIR = ROOT / "data" / "interim"
PROVENANCE = ROOT / "outputs" / "provenance" / "boundaries.json"
HDX_URL = "https://data.humdata.org/dataset/cod-ab-pak"

AREA_CRS = "ESRI:102028"  # Asia South Albers Equal Area Conic (PRD.md 6.2)
M2_PER_KM2 = 1e6
AREA_TOLERANCE_PCT = 10.0  # flag groups whose census and polygon areas differ by more

# Census (2023 spelling) -> HDX adm3 spelling, after clean_name().
TEHSIL_ALIASES: dict[str, str] = {
    "SAMMUNDRI": "SUMMUNDRI",
    "KAR SAYADDAN": "KALLAR SAYADDAN",
}


@dataclass(frozen=True)
class CityLink:
    """How one city's census units are matched to HDX polygons."""

    city: str
    level: str  # "tehsil", "district" or "division"
    census_districts: tuple[str, ...]
    hdx_adm2_pcodes: tuple[str, ...]


CITY_LINKS: tuple[CityLink, ...] = (
    CityLink("karachi", "division",
             ("KARACHI CENTRAL DISTRICT", "KARACHI EAST DISTRICT", "KARACHI SOUTH DISTRICT",
              "KARACHI WEST DISTRICT", "KEAMARI DISTRICT", "KORANGI DISTRICT", "MALIR DISTRICT"),
             ("PK702", "PK704", "PK712", "PK714", "PK721", "PK729")),
    CityLink("lahore", "district", ("LAHORE DISTRICT",), ("PK617",)),
    # Faisalabad tehsil polygons differ from census tehsil areas by up to 21 %, so district.
    CityLink("faisalabad", "district", ("FAISALABAD DISTRICT",), ("PK608",)),
    CityLink("peshawar", "district", ("PESHAWAR DISTRICT",), ("PK528",)),
    CityLink("rawalpindi", "tehsil", ("RAWALPINDI DISTRICT",), ("PK630",)),
    CityLink("islamabad", "tehsil", ("ISLAMABAD DISTRICT",), ("PK401",)),
)


def clean_name(value: str) -> str:
    """Upper-case, drop unit suffixes and punctuation so names can be compared."""
    name = re.sub(r"\b(TEHSIL|TALUKA|SUB-DIVISION|DISTRICT)\b", "", str(value).upper())
    return re.sub(r"[^A-Z ]", " ", re.sub(r"\s+", " ", name)).strip()


def load_census() -> pd.DataFrame:
    """Join 2017 and 2023 census tables on unit_code."""
    c17 = pd.read_csv(CENSUS_DIR / "census_2017.csv", encoding="utf-8")
    c23 = pd.read_csv(CENSUS_DIR / "census_2023.csv", encoding="utf-8")
    keep = ["unit_code", "unit_name", "unit_level", "district", "province", "area_km2"]
    return c23[keep + ["pop_total"]].rename(columns={"pop_total": "pop_2023"}).merge(
        c17[["unit_code", "pop_total"]].rename(columns={"pop_total": "pop_2017"}),
        on="unit_code", validate="one_to_one",
    )


def build_groups(link: CityLink, census: pd.DataFrame, adm3: gpd.GeoDataFrame
                 ) -> list[dict[str, object]]:
    """Return census groups (one polygon set + population totals) for one city.

    Raises:
        ValueError: If a tehsil-level census unit has no polygon or vice versa.
    """
    polys = adm3[adm3["adm2_pcode"].isin(link.hdx_adm2_pcodes)]
    units = census[census["district"].isin(link.census_districts)]
    if link.level != "tehsil":
        units = units[units["unit_level"] == "district"]
        return [{
            "city": link.city, "group_id": f"{link.city}_{link.level}",
            "match_level": link.level, "census_units": units["unit_name"].tolist(),
            "census_unit_codes": units["unit_code"].tolist(),
            "hdx_pcodes": sorted(polys["adm3_pcode"]),
            "census_area_km2": units["area_km2"].sum(),
            "pop_2017": int(units["pop_2017"].sum()), "pop_2023": int(units["pop_2023"].sum()),
        }]
    tehsils = units[units["unit_level"] == "tehsil"].copy()
    tehsils["key"] = tehsils["unit_name"].map(clean_name).replace(TEHSIL_ALIASES)
    poly_keys = dict(zip(polys["adm3_name"].map(clean_name), polys["adm3_pcode"], strict=True))
    missing = set(tehsils["key"]) ^ set(poly_keys)
    if missing:
        raise ValueError(f"{link.city}: unmatched tehsil names {sorted(missing)}")
    return [{
        "city": link.city, "group_id": f"{link.city}_{row.key.lower().replace(' ', '_')}",
        "match_level": "tehsil", "census_units": [row.unit_name],
        "census_unit_codes": [row.unit_code], "hdx_pcodes": [poly_keys[row.key]],
        "census_area_km2": row.area_km2,
        "pop_2017": int(row.pop_2017), "pop_2023": int(row.pop_2023),
    } for row in tehsils.itertuples()]


def main() -> None:
    """Export layers, build the lookup, check areas, write outputs and provenance."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    adm2 = gpd.read_file(GDB, layer="pak_admin2")
    adm3 = gpd.read_file(GDB, layer="pak_admin3")
    adm2.to_file(BOUNDARY_DIR / "pak_adm2.gpkg", driver="GPKG")
    adm3.to_file(BOUNDARY_DIR / "pak_adm3.gpkg", driver="GPKG")
    LOG.info("Exported pak_adm2.gpkg (%d) and pak_adm3.gpkg (%d)", len(adm2), len(adm3))

    census = load_census()
    groups = pd.DataFrame([g for link in CITY_LINKS for g in build_groups(link, census, adm3)])

    adm3_area = adm3.to_crs(AREA_CRS).set_index("adm3_pcode")
    shapes = []
    for g in groups.itertuples():
        geom = adm3_area.loc[list(g.hdx_pcodes)].geometry.union_all()
        shapes.append(geom)
    gdf = gpd.GeoDataFrame(groups, geometry=shapes, crs=AREA_CRS)
    gdf["boundary_area_km2"] = (gdf.geometry.area / M2_PER_KM2).round(1)
    gdf["area_diff_pct"] = (
        100 * (gdf["boundary_area_km2"] - gdf["census_area_km2"]) / gdf["census_area_km2"]
    ).round(1)
    flagged = gdf[gdf["area_diff_pct"].abs() > AREA_TOLERANCE_PCT]
    if not flagged.empty:
        LOG.warning("Area differs by > %.0f%%:\n%s", AREA_TOLERANCE_PCT,
                    flagged[["group_id", "census_area_km2", "boundary_area_km2",
                             "area_diff_pct"]].to_string(index=False))

    lookup = gdf.drop(columns="geometry").copy()
    for col in ("census_units", "census_unit_codes", "hdx_pcodes"):
        lookup[col] = lookup[col].map(";".join)
    lookup.to_csv(INTERIM_DIR / "census_boundary_lookup.csv", index=False, encoding="utf-8")
    out = gdf.assign(**{c: lookup[c] for c in ("census_units", "census_unit_codes", "hdx_pcodes")})
    out.to_crs("EPSG:4326").to_file(INTERIM_DIR / "census_units.gpkg", driver="GPKG")
    LOG.info("Lookup:\n%s", lookup[["group_id", "match_level", "pop_2017", "pop_2023",
                                    "census_area_km2", "boundary_area_km2",
                                    "area_diff_pct"]].to_string(index=False))

    PROVENANCE.write_text(json.dumps({
        "run_utc": datetime.now(UTC).isoformat(),
        "script": "src/00_boundaries.py",
        "source": HDX_URL, "hdx_valid_on": str(adm3["valid_on"].iloc[0]),
        "area_crs": AREA_CRS, "tehsil_aliases": TEHSIL_ALIASES,
        "city_levels": {c.city: c.level for c in CITY_LINKS},
        "groups_flagged_area": flagged["group_id"].tolist(),
    }, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
