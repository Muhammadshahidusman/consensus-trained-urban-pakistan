"""Build tidy census CSVs (2017 and 2023) from PBS 2023 Table 1, district and tehsil level.

PBS Table 1 of the 7th Population and Housing Census (2023) reports, for every district and
sub-district unit (tehsil, taluka, sub-division), the 2023 population split into rural and urban,
plus the 2017 population of the same unit. Both years therefore share 2023 unit boundaries,
which removes most of the 2017 to 2023 boundary mismatch (e.g. Karachi's re-districting).

Outputs (PCD.md Step 1.1):
    data/raw/census/census_2017.csv
    data/raw/census/census_2023.csv
Columns: unit_code, unit_name, unit_level, district, province, area_km2, pop_total,
urban_pop, rural_pop, source.

``unit_code`` is not a PBS code (Table 1 has none). It is a stable key built from table order:
``{PROVINCE}-{district index:03d}-{unit index:02d}``, with unit index 00 for the district row.

Checks run on every build:
    1. rural + urban == total for every unit and year.
    2. Sub-district units sum to their district total for every district and year.
    3. 2017 values agree with the independent CERP digitisation of the 2017 census Table 1
       (cerp-analytics/pbs2017) for every unit whose name matches.

Run:  python src/00_census_tables.py
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime
from pathlib import Path

import pandas as pd

LOG = logging.getLogger("census_tables")

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw" / "census"
DOWNLOAD_DIR = RAW_DIR / "_download"
CERP_2017_CSV = DOWNLOAD_DIR / "cerp" / "01_tehsil_disaggregated.csv"
PROVENANCE_DIR = ROOT / "outputs" / "provenance"

PBS_URL = "https://www.pbs.gov.pk/result-excel/"
PROVINCE_FILES: dict[str, str] = {
    "PUNJAB": "2023_table_1_punjab_districts.xlsx",
    "SINDH": "2023_table_1_sindh_districts.xlsx",
    "KHYBER PAKHTUNKHWA": "2023_table_1_kp_districts.xlsx",
    "ISLAMABAD": "2023_table_1_islamabad.xlsx",
}
PROVINCE_CODES: dict[str, str] = {
    "PUNJAB": "PB", "SINDH": "SD", "KHYBER PAKHTUNKHWA": "KP", "ISLAMABAD": "ICT",
}

# Column positions in PBS Table 1 (0-based), fixed by the table layout.
COL_NAME, COL_AREA, COL_POP2023, COL_POP2017 = 0, 1, 2, 10
FIRST_DATA_ROW = 4  # rows 0-3 are title, headers and column numbers
SPLIT_LABELS = ("RURAL", "URBAN")
OUTPUT_COLUMNS = [
    "unit_code", "unit_name", "unit_level", "district", "province", "area_km2",
    "pop_total", "urban_pop", "rural_pop", "source",
]
CERP_KEY_COLS = ["district", "tehsil", "locality"]
# Districts covering the five study cities plus Islamabad (Phase 2 decision).
STUDY_DISTRICTS: tuple[str, ...] = (
    "KARACHI CENTRAL DISTRICT", "KARACHI EAST DISTRICT", "KARACHI SOUTH DISTRICT",
    "KARACHI WEST DISTRICT", "KEAMARI DISTRICT", "KORANGI DISTRICT", "MALIR DISTRICT",
    "LAHORE DISTRICT", "FAISALABAD DISTRICT", "PESHAWAR DISTRICT", "RAWALPINDI DISTRICT",
    "ISLAMABAD DISTRICT",
)


def clean_name(value: object) -> str:
    """Collapse whitespace and upper-case a cell value."""
    return re.sub(r"\s+", " ", str(value)).strip().upper()


def to_int(value: object) -> int:
    """Convert a population cell to int; blanks count as zero."""
    if pd.isna(value):
        return 0
    return int(round(float(value)))


def parse_table1(path: Path, province: str) -> pd.DataFrame:
    """Parse one PBS 2023 Table 1 sheet into one row per unit with both years.

    Args:
        path: Excel file for one province.
        province: Province name written to the output.

    Returns:
        DataFrame with unit identity, area and total/rural/urban population for 2023 and 2017.

    Raises:
        ValueError: If a unit is not followed by its RURAL and URBAN rows.
    """
    sheet = pd.read_excel(path, header=None)
    records: list[dict[str, object]] = []
    district = ""
    district_idx = unit_idx = 0
    rows = sheet.iloc[FIRST_DATA_ROW:].reset_index(drop=True)
    i = 0
    while i < len(rows):
        name = clean_name(rows.at[i, COL_NAME])
        is_unit = (
            name not in SPLIT_LABELS
            and name != "NAN"
            and pd.notna(rows.at[i, COL_POP2023])
            and isinstance(rows.at[i, COL_POP2023], (int, float))
        )
        if not is_unit:
            i += 1
            continue
        if name == province:  # province total row and its RURAL/URBAN split
            i += 3
            continue
        split = [clean_name(rows.at[i + k, COL_NAME]) for k in (1, 2)] if i + 2 < len(rows) else []
        if split != list(SPLIT_LABELS):
            raise ValueError(f"{path.name}: unit {name!r} not followed by RURAL/URBAN rows")
        if name.endswith("DISTRICT"):
            district, district_idx, unit_idx, level = name, district_idx + 1, 0, "district"
        else:
            unit_idx, level = unit_idx + 1, "tehsil"
        code = f"{PROVINCE_CODES[province]}-{district_idx:03d}-{unit_idx:02d}"
        rec: dict[str, object] = {
            "unit_code": code, "unit_name": name, "unit_level": level,
            "district": district, "province": province,
            "area_km2": rows.at[i, COL_AREA],
        }
        for year, col in (("2023", COL_POP2023), ("2017", COL_POP2017)):
            rec[f"pop_total_{year}"] = to_int(rows.at[i, col])
            rec[f"rural_pop_{year}"] = to_int(rows.at[i + 1, col])
            rec[f"urban_pop_{year}"] = to_int(rows.at[i + 2, col])
        records.append(rec)
        i += 3
    return pd.DataFrame.from_records(records)


def check_splits(units: pd.DataFrame, study_districts: tuple[str, ...]) -> None:
    """Check rural + urban == total for every unit and year.

    Source typos outside the study districts are logged; inside them they stop the build.

    Raises:
        ValueError: If a unit in a study district fails the check.
    """
    for year in ("2017", "2023"):
        diff = units[f"rural_pop_{year}"] + units[f"urban_pop_{year}"] - units[f"pop_total_{year}"]
        bad = units[diff != 0]
        if bad.empty:
            continue
        LOG.warning("%s: rural + urban != total (PBS source values) for %s", year,
                    bad[["district", "unit_name"]].to_dict("records"))
        if bad["district"].isin(study_districts).any():
            raise ValueError(f"{year}: split mismatch inside a study district")


def check_district_sums(units: pd.DataFrame) -> pd.DataFrame:
    """Compare district totals with the sum of their sub-district units.

    Returns:
        One row per district and year where the sums differ (empty if all agree).
    """
    out = []
    for year in ("2017", "2023"):
        col = f"pop_total_{year}"
        dist = units[units.unit_level == "district"].set_index(["province", "district"])[col]
        sub = units[units.unit_level == "tehsil"].groupby(["province", "district"])[col].sum()
        diff = (sub.reindex(dist.index).fillna(0) - dist).rename("difference")
        bad = diff[diff != 0].reset_index().assign(year=year)
        out.append(bad)
    return pd.concat(out, ignore_index=True)


def cross_check_cerp(units: pd.DataFrame, cerp_path: Path) -> pd.DataFrame:
    """Compare 2017 totals from the 2023 table with the CERP 2017 digitisation.

    Units are matched on cleaned district and tehsil names. Unmatched names are expected where
    units were created or renamed between censuses.

    Returns:
        Matched rows with both values and their difference.
    """
    cerp = pd.read_csv(cerp_path, encoding="utf-8")
    cerp[CERP_KEY_COLS] = cerp[CERP_KEY_COLS].apply(lambda s: s.map(clean_name))
    cerp["all_sex"] = pd.to_numeric(cerp["all_sex"], errors="coerce").fillna(0)
    cerp_tot = (
        cerp.groupby(["district", "tehsil"])["all_sex"].sum().rename("cerp_2017").reset_index()
    )
    tehsils = units[units.unit_level == "tehsil"][["district", "unit_name", "pop_total_2017"]]
    merged = tehsils.merge(
        cerp_tot, left_on=["district", "unit_name"], right_on=["district", "tehsil"], how="inner"
    )
    merged["difference"] = merged["pop_total_2017"] - merged["cerp_2017"]
    return merged.drop(columns="tehsil")


def to_year_table(units: pd.DataFrame, year: str) -> pd.DataFrame:
    """Select one census year in the output column layout."""
    renamed = units.rename(columns={
        f"pop_total_{year}": "pop_total", f"urban_pop_{year}": "urban_pop",
        f"rural_pop_{year}": "rural_pop",
    })
    note = "" if year == "2023" else " (2017 population on 2023 unit boundaries)"
    renamed["source"] = f"PBS Census 2023 Table 1, {PBS_URL}{note}"
    return renamed[OUTPUT_COLUMNS]


def main() -> None:
    """Parse all provinces, run checks, write census CSVs and a provenance record."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    units = pd.concat(
        [parse_table1(DOWNLOAD_DIR / f, p) for p, f in PROVINCE_FILES.items()], ignore_index=True
    )
    LOG.info("Parsed %d units (%d districts)", len(units), (units.unit_level == "district").sum())

    missing = set(STUDY_DISTRICTS) - set(units["district"])
    if missing:
        raise ValueError(f"Study districts not found in census tables: {sorted(missing)}")
    check_splits(units, STUDY_DISTRICTS)
    sum_issues = check_district_sums(units)
    if sum_issues.empty:
        LOG.info("District totals equal the sum of their sub-district units (both years)")
    else:
        LOG.warning("District sum mismatches:\n%s", sum_issues.to_string(index=False))

    cerp = cross_check_cerp(units, CERP_2017_CSV)
    n_diff = int((cerp["difference"] != 0).sum())
    LOG.info("CERP 2017 cross-check: %d units matched by name, %d differ", len(cerp), n_diff)
    if n_diff:
        LOG.warning("Units differing from CERP:\n%s",
                    cerp[cerp["difference"] != 0].to_string(index=False))

    for year in ("2017", "2023"):
        path = RAW_DIR / f"census_{year}.csv"
        to_year_table(units, year).to_csv(path, index=False, encoding="utf-8")
        LOG.info("Wrote %s", path.relative_to(ROOT))

    PROVENANCE_DIR.mkdir(parents=True, exist_ok=True)
    record = {
        "run_utc": datetime.now(UTC).isoformat(),
        "script": "src/00_census_tables.py",
        "source_url": PBS_URL,
        "input_files": sorted(PROVINCE_FILES.values()),
        "cross_check": {"file": str(CERP_2017_CSV.relative_to(ROOT)),
                        "units_matched": len(cerp), "units_differing": n_diff},
        "district_sum_mismatches": len(sum_issues),
        "n_units": len(units),
    }
    prov = PROVENANCE_DIR / "census_tables.json"
    prov.write_text(json.dumps(record, indent=2), encoding="utf-8")
    LOG.info("Provenance written to %s", prov.relative_to(ROOT))


if __name__ == "__main__":
    main()
