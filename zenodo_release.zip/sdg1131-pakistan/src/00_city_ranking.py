"""Rank Pakistani cities by 2023 census population to confirm the study-city choice.

Source: PBS Census 2023 Table 2 (urban localities, national), which lists every urban locality
with its district and its 2023 and 2017 population.

City rule (documented so the ranking is reproducible):
    city population = all urban localities in the city's district whose name contains
    "CORPORATION" (metropolitan / municipal / district municipal corporation, including the
    parts PBS lists separately per tehsil) plus all "CANTONMENT" localities in that district.
    Karachi's seven districts are merged into one city.
    Districts without a corporation are skipped: no such town reaches the top 15.

Output: outputs/tables/census_city_ranking_2023.csv (supporting table, not a paper table).

Run:  python src/00_city_ranking.py
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime
from pathlib import Path

import pandas as pd

LOG = logging.getLogger("city_ranking")

ROOT = Path(__file__).resolve().parents[1]
TABLE2_XLSX = ROOT / "data" / "raw" / "census" / "_download" / "2023_table_2_national.xlsx"
OUT_CSV = ROOT / "outputs" / "tables" / "census_city_ranking_2023.csv"
PROVENANCE = ROOT / "outputs" / "provenance" / "census_city_ranking.json"
SOURCE_URL = "https://www.pbs.gov.pk/wp-content/uploads/2020/07/table_2_national.xlsx"

COL_NAME, COL_DISTRICT, COL_POP2023, COL_POP2017 = 0, 1, 2, 6
KARACHI_DISTRICTS = {
    "KARACHI CENTRAL DISTRICT", "KARACHI EAST DISTRICT", "KARACHI SOUTH DISTRICT",
    "KARACHI WEST DISTRICT", "KEAMARI DISTRICT", "KORANGI DISTRICT", "MALIR DISTRICT",
}
STUDY_CITIES = {"KARACHI", "LAHORE", "FAISALABAD", "PESHAWAR", "RAWALPINDI"}
TOP_N = 15
GROWTH_YEARS = 6


def clean(value: object) -> str:
    """Collapse whitespace and upper-case a cell value."""
    return re.sub(r"\s+", " ", str(value)).strip().upper()


def load_localities(path: Path) -> pd.DataFrame:
    """Read Table 2 rows that describe an urban locality with numeric populations."""
    raw = pd.read_excel(path, header=None)
    df = pd.DataFrame({
        "locality": raw[COL_NAME].map(clean),
        "district": raw[COL_DISTRICT].map(clean),
        "pop_2023": pd.to_numeric(raw[COL_POP2023], errors="coerce"),
        "pop_2017": pd.to_numeric(raw[COL_POP2017], errors="coerce"),
    })
    return df[df["pop_2023"].notna() & df["district"].str.endswith("DISTRICT")]


def city_of(district: str) -> str:
    """Map a district to its city label (Karachi districts merged)."""
    if district in KARACHI_DISTRICTS:
        return "KARACHI"
    return district.removesuffix(" DISTRICT")


def rank_cities(localities: pd.DataFrame) -> pd.DataFrame:
    """Aggregate corporation and cantonment localities to cities and rank by 2023 population."""
    is_corp = localities["locality"].str.contains("CORPORATION")
    is_cantt = localities["locality"].str.contains("CANTONMENT")
    with_corp = set(localities.loc[is_corp, "district"])
    keep = localities[(is_corp | is_cantt) & localities["district"].isin(with_corp)].copy()
    keep["city"] = keep["district"].map(city_of)
    cities = keep.groupby("city").agg(
        pop_2023=("pop_2023", "sum"), pop_2017=("pop_2017", "sum"),
        n_localities=("locality", "size"),
    )
    cities["growth_pct_per_yr"] = (
        100 * ((cities["pop_2023"] / cities["pop_2017"]) ** (1 / GROWTH_YEARS) - 1)
    ).round(2)
    cities = cities.sort_values("pop_2023", ascending=False).reset_index()
    cities.insert(0, "rank_2023", range(1, len(cities) + 1))
    cities["study_city"] = cities["city"].isin(STUDY_CITIES)
    return cities


def main() -> None:
    """Build the ranking table and provenance record."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    cities = rank_cities(load_localities(TABLE2_XLSX))
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    cities.head(TOP_N).to_csv(OUT_CSV, index=False, encoding="utf-8")
    LOG.info("Top %d cities by 2023 population:\n%s", TOP_N,
             cities.head(TOP_N).to_string(index=False))
    PROVENANCE.write_text(json.dumps({
        "run_utc": datetime.now(UTC).isoformat(),
        "script": "src/00_city_ranking.py",
        "source_url": SOURCE_URL,
        "rule": "corporation + cantonment localities per district; Karachi districts merged",
        "output": str(OUT_CSV.relative_to(ROOT)),
    }, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
