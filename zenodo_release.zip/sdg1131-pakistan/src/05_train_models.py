"""Phase 5 (RQ2): train built-up classifiers on consensus samples with spatial block CV.

Models (PCD Step 5.2): RF-Embed, GBT-Embed, MLP-Embed on AlphaEarth embeddings A00 to A63, and
the RF-S2 baseline on Sentinel-2 TOA bands + NDVI, NDBI, MNDWI. All models use the same rows
(samples that have both feature sets), pooled across cities.

Folds (Step 5.1): whole ~2 km blocks (key city_blockx_blocky) are assigned to 5 folds with
GroupKFold (shuffled, seed 42); never random pixel splits. Light tuning: a small grid searched
with an inner 3-fold GroupKFold inside each training fold. Step 5.3: leave-one-city-out
transfer with each model's most frequently chosen parameters.

These scores are cross-validation on consensus labels, which exclude the hard (disagreement)
pixels. They are NOT map accuracy; map accuracy comes only from the independent validation
sample (Phase 8).

Outputs:
    outputs/tables/Table4_spatial_cv.csv      mean +/- SD across outer folds
    outputs/tables/cv_folds.csv               per-fold scores and chosen parameters
    outputs/tables/cv_per_city.csv            out-of-fold scores per city
    outputs/tables/transfer_loco.csv          leave-one-city-out scores
    outputs/provenance/models.json

Run:  python src/05_train_models.py
      python src/05_train_models.py --cities faisalabad   (single-city check)
"""

from __future__ import annotations

import argparse
import json
import logging
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.base import BaseEstimator, clone
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import GridSearchCV, GroupKFold
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

LOG = logging.getLogger("train_models")

# --- Configuration -----------------------------------------------------------
SEED = 42
YEAR = 2020
N_FOLDS = 5
N_INNER_FOLDS = 3
N_TREES = 500
CITIES = ("karachi", "lahore", "faisalabad", "peshawar", "rawalpindi")
EMBED_FEATURES = [f"A{i:02d}" for i in range(64)]
S2_FEATURES = ["B2", "B3", "B4", "B8", "B11", "B12", "NDVI", "NDBI", "MNDWI"]
LABEL = "label"  # 1 built, 0 non-built

ROOT = Path(__file__).resolve().parents[1]
SAMPLE_DIR = ROOT / "data" / "interim" / "samples"
TABLE_DIR = ROOT / "outputs" / "tables"
PROVENANCE = ROOT / "outputs" / "provenance" / "models.json"


@dataclass
class ModelSpec:
    """A model, its feature set and its small tuning grid."""

    name: str
    features_name: str
    features: list[str]
    estimator: BaseEstimator
    grid: dict[str, list] = field(default_factory=dict)


def model_specs() -> list[ModelSpec]:
    """The four models of PCD Step 5.2."""
    return [
        ModelSpec("RF-Embed", "AlphaEarth A00-A63", EMBED_FEATURES,
                  RandomForestClassifier(n_estimators=N_TREES, n_jobs=-1, random_state=SEED),
                  {"min_samples_leaf": [1, 5]}),
        ModelSpec("GBT-Embed", "AlphaEarth A00-A63", EMBED_FEATURES,
                  HistGradientBoostingClassifier(random_state=SEED),
                  {"learning_rate": [0.05, 0.1]}),
        ModelSpec("MLP-Embed", "AlphaEarth A00-A63 (standardised)", EMBED_FEATURES,
                  make_pipeline(StandardScaler(), MLPClassifier(
                      hidden_layer_sizes=(64, 32), max_iter=500, early_stopping=True,
                      random_state=SEED)),
                  {"mlpclassifier__alpha": [1e-4, 1e-3]}),
        ModelSpec("RF-S2", "Sentinel-2 TOA bands + NDVI, NDBI, MNDWI", S2_FEATURES,
                  RandomForestClassifier(n_estimators=N_TREES, n_jobs=-1, random_state=SEED),
                  {"min_samples_leaf": [1, 5]}),
    ]


def load_samples(cities: list[str]) -> tuple[pd.DataFrame, dict[str, int]]:
    """Join embedding and S2 samples on point_id; keep rows complete in both feature sets.

    Returns:
        The joined table and the number of rows dropped per city.
    """
    frames, dropped = [], {}
    for city in cities:
        emb = pd.read_csv(SAMPLE_DIR / f"samples_{city}_{YEAR}.csv", encoding="utf-8")
        s2 = pd.read_csv(SAMPLE_DIR / f"s2_{city}_{YEAR}.csv", encoding="utf-8")
        joined = emb.merge(s2[["point_id", *S2_FEATURES]], on="point_id", how="left")
        complete = joined.dropna(subset=EMBED_FEATURES + S2_FEATURES)
        dropped[city] = len(joined) - len(complete)
        frames.append(complete)
    data = pd.concat(frames, ignore_index=True)
    data["block"] = block_key(data)
    return data, dropped


def block_key(df: pd.DataFrame) -> pd.Series:
    """Spatial block key ``city_blockx_blocky`` (blocks are unique within a city)."""
    return df["city"] + "_" + df["block_x"].astype(str) + "_" + df["block_y"].astype(str)


def outer_folds(groups: pd.Series, n_folds: int = N_FOLDS) -> np.ndarray:
    """Fold number per row; every block lies in exactly one fold."""
    fold = np.full(len(groups), -1, dtype=int)
    splitter = GroupKFold(n_splits=n_folds, shuffle=True, random_state=SEED)
    for k, (_, test) in enumerate(splitter.split(np.zeros(len(groups)), groups=groups)):
        fold[test] = k
    return fold


def scores(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    """OA and F1 of each class (equation 4), in percent."""
    return {
        "OA": 100 * accuracy_score(y_true, y_pred),
        "F1_built": 100 * f1_score(y_true, y_pred, pos_label=1),
        "F1_nonbuilt": 100 * f1_score(y_true, y_pred, pos_label=0),
    }


def fit_tuned(spec: ModelSpec, x: pd.DataFrame, y: pd.Series, groups: pd.Series
              ) -> tuple[BaseEstimator, dict]:
    """Small grid search with an inner GroupKFold on the training data only."""
    search = GridSearchCV(
        clone(spec.estimator), spec.grid, scoring="f1",
        cv=GroupKFold(n_splits=N_INNER_FOLDS, shuffle=True, random_state=SEED), refit=True,
    )
    search.fit(x, y, groups=groups)
    return search.best_estimator_, search.best_params_


def spatial_cv(data: pd.DataFrame, specs: list[ModelSpec]
               ) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, dict]]:
    """Outer spatial CV for every model.

    Returns:
        Per-fold scores, out-of-fold predictions, and the modal best params per model.
    """
    folds = outer_folds(data["block"])
    y = data[LABEL].to_numpy()
    fold_rows = []
    oof = pd.DataFrame({"point_id": data["point_id"], "city": data["city"], "fold": folds,
                        "y": y})
    best: dict[str, dict] = {}
    for spec in specs:
        pred = np.full(len(data), -1)
        chosen = []
        for k in range(N_FOLDS):
            train, test = folds != k, folds == k
            model, params = fit_tuned(spec, data.loc[train, spec.features],
                                      data.loc[train, LABEL], data.loc[train, "block"])
            pred[test] = model.predict(data.loc[test, spec.features])
            chosen.append(json.dumps(params, sort_keys=True))
            fold_rows.append({"model": spec.name, "fold": k, "n_test": int(test.sum()),
                              "params": params, **scores(y[test], pred[test])})
            LOG.info("%s fold %d: %s", spec.name, k, fold_rows[-1])
        oof[spec.name] = pred
        best[spec.name] = json.loads(Counter(chosen).most_common(1)[0][0])
    return pd.DataFrame(fold_rows), oof, best


def summarise(folds: pd.DataFrame, specs: list[ModelSpec]) -> pd.DataFrame:
    """Table 4: mean and SD across outer folds."""
    rows = []
    for spec in specs:
        f = folds[folds["model"] == spec.name]
        row = {"Model": spec.name, "Features": spec.features_name}
        for metric in ("OA", "F1_built", "F1_nonbuilt"):
            row[f"{metric}_mean"] = round(f[metric].mean(), 1)
            row[f"{metric}_sd"] = round(f[metric].std(ddof=1), 1)
        rows.append(row)
    return pd.DataFrame(rows)


def per_city_fold(oof: pd.DataFrame, specs: list[ModelSpec]) -> pd.DataFrame:
    """Scores per city, model and outer fold (for CIs in Fig 5); folds lacking a class skipped.
    """
    rows = []
    for (city, fold), g in oof.groupby(["city", "fold"]):
        if g["y"].nunique() < 2:
            continue
        for spec in specs:
            rows.append({"city": city, "fold": int(fold), "model": spec.name, "n": len(g),
                         **scores(g["y"].to_numpy(), g[spec.name].to_numpy())})
    return pd.DataFrame(rows)


def per_city(oof: pd.DataFrame, specs: list[ModelSpec]) -> pd.DataFrame:
    """Out-of-fold scores per city and model."""
    rows = []
    for city, g in oof.groupby("city"):
        for spec in specs:
            rows.append({"city": city, "model": spec.name,
                         **{k: round(v, 1) for k, v in scores(g["y"], g[spec.name]).items()}})
    return pd.DataFrame(rows)


def leave_one_city_out(data: pd.DataFrame, specs: list[ModelSpec], best: dict[str, dict]
                       ) -> pd.DataFrame:
    """Train on all other cities, test on each held-out city (Step 5.3)."""
    rows = []
    for city in sorted(data["city"].unique()):
        train, test = data["city"] != city, data["city"] == city
        for spec in specs:
            model = clone(spec.estimator).set_params(**best[spec.name])
            model.fit(data.loc[train, spec.features], data.loc[train, LABEL])
            pred = model.predict(data.loc[test, spec.features])
            rows.append({"held_out_city": city, "model": spec.name,
                         **{k: round(v, 1) for k, v in
                            scores(data.loc[test, LABEL].to_numpy(), pred).items()}})
            LOG.info("LOCO %s %s: %s", city, spec.name, rows[-1])
    return pd.DataFrame(rows)


def main() -> None:
    """Run spatial CV and the transfer test, write tables and provenance."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--cities", nargs="+", default=list(CITIES), choices=list(CITIES))
    parser.add_argument("--skip-loco", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    data, dropped = load_samples(args.cities)
    LOG.info("%d samples, %d blocks; dropped incomplete rows: %s",
             len(data), data["block"].nunique(), dropped)
    specs = model_specs()
    folds, oof, best = spatial_cv(data, specs)
    table4 = summarise(folds, specs)
    LOG.info("Spatial CV (consensus labels, not map accuracy):\n%s", table4.to_string(index=False))

    suffix = "" if len(args.cities) == len(CITIES) else "_" + "_".join(args.cities)
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    table4.to_csv(TABLE_DIR / f"Table4_spatial_cv{suffix}.csv", index=False, encoding="utf-8")
    folds.to_csv(TABLE_DIR / f"cv_folds{suffix}.csv", index=False, encoding="utf-8")
    per_city(oof, specs).to_csv(TABLE_DIR / f"cv_per_city{suffix}.csv", index=False,
                                encoding="utf-8")
    per_city_fold(oof, specs).to_csv(TABLE_DIR / f"cv_folds_per_city{suffix}.csv",
                                     index=False, encoding="utf-8")
    oof.to_csv(TABLE_DIR / f"cv_oof_predictions{suffix}.csv", index=False, encoding="utf-8")
    loco_done = not args.skip_loco and data["city"].nunique() > 1
    if loco_done:
        leave_one_city_out(data, specs, best).to_csv(
            TABLE_DIR / f"transfer_loco{suffix}.csv", index=False, encoding="utf-8")

    record = {
        "run_utc": datetime.now(UTC).isoformat(),
        "script": "src/05_train_models.py",
        "sklearn_version": sklearn.__version__,
        "seed": SEED, "cities": args.cities, "n_samples": len(data),
        "n_blocks": int(data["block"].nunique()), "dropped_incomplete": dropped,
        "class_counts": {str(k): int(v) for k, v in data[LABEL].value_counts().items()},
        "cv": {"outer": f"GroupKFold({N_FOLDS}, shuffle, seed {SEED}) on city_blockx_blocky",
               "inner": f"GroupKFold({N_INNER_FOLDS}) grid search, scoring F1 built"},
        "models": {s.name: {"features": s.features, "estimator": repr(s.estimator),
                            "grid": s.grid, "modal_best_params": best[s.name]} for s in specs},
        "loco": loco_done,
        "note": "CV on consensus labels; not map accuracy.",
    }
    PROVENANCE.parent.mkdir(parents=True, exist_ok=True)
    out = PROVENANCE.with_name(f"models{suffix}.json")
    out.write_text(json.dumps(record, indent=2, default=str), encoding="utf-8")


if __name__ == "__main__":
    main()
