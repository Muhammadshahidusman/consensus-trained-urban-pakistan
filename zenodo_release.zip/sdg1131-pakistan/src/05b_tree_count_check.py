"""Check that fewer trees change the RF-Embed predictions negligibly (supports 100 trees in EE).

Uses the same pooled samples and spatial block folds as src/05_train_models.py. For each tree
count, out-of-fold predictions are compared with those of the 500-tree forest (bootstrap
fraction 0.632, as the Earth Engine bagFraction).

Output: outputs/tables/tree_count_check.csv (n_trees, OA %, disagreement with 500 trees %)

Run:  python src/05b_tree_count_check.py
"""

from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

LOG = logging.getLogger("tree_count_check")

SEED = 42
TREE_COUNTS = (50, 100, 500)
REFERENCE_TREES = 500
BOOTSTRAP_FRACTION = 0.632
N_FOLDS = 5
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "tables" / "tree_count_check.csv"


def _load_training():
    path = Path(__file__).with_name("05_train_models.py")
    spec = importlib.util.spec_from_file_location("train_models", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main() -> None:
    """Out-of-fold predictions per tree count and their disagreement with 500 trees."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    tm = _load_training()
    data, _ = tm.load_samples(list(tm.CITIES))
    folds = tm.outer_folds(data["block"])
    x, y = data[tm.EMBED_FEATURES].to_numpy(), data[tm.LABEL].to_numpy()
    preds = {}
    for n in TREE_COUNTS:
        p = np.empty(len(y), dtype=int)
        for k in range(N_FOLDS):
            train, test = folds != k, folds == k
            rf = RandomForestClassifier(n_estimators=n, max_samples=BOOTSTRAP_FRACTION,
                                        n_jobs=-1, random_state=SEED).fit(x[train], y[train])
            p[test] = rf.predict(x[test])
        preds[n] = p
    rows = [{"n_trees": n, "OA_pct": 100 * float((p == y).mean()),
             "disagreement_vs_500_pct": 100 * float((p != preds[REFERENCE_TREES]).mean())}
            for n, p in preds.items()]
    table = pd.DataFrame(rows)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(OUT, index=False, encoding="utf-8")
    LOG.info("Tree-count check:\n%s", table.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
