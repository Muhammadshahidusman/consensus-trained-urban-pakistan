"""Phase 6, Step 6.3: change maps and per-band COGs from the downloaded map stacks.

Reads data/interim/maps/maps_{city}.tif (gee/06_classify_years.py) and writes one Cloud-
Optimized GeoTIFF per layer (city UTM, 10 m, working AOI):

    data/processed/builtup_{city}_{year}.tif     own model, 2017 / 2023
    data/processed/change_{city}_2017_2023.tif   0 non-built both years, 1 stable built,
                                                 2 new built, 3 reversal (built -> non-built)
    data/processed/dw_{city}_{year}.tif          Dynamic World built, 2017 / 2023
    data/processed/ghsl_{city}_{year}.tif        GHSL built fraction x 100, 2017 / 2023

Pixel counts per class are logged and written to outputs/tables/map_pixel_counts.csv
(Step 6 done check). Reversals are flagged for inspection over Sentinel-2.

Run:  python src/06_change_maps.py faisalabad
      python src/06_change_maps.py
"""

from __future__ import annotations

import argparse
import importlib.util
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from rasterio.enums import Resampling

LOG = logging.getLogger("change_maps")

CITIES = ("karachi", "lahore", "faisalabad", "peshawar", "rawalpindi")
NODATA = 255
CHANGE_CLASSES = {0: "non-built both years", 1: "stable built", 2: "new built", 3: "reversal"}
LAYERS = {  # stack band name -> output file stem pattern
    "built_2017": "builtup_{city}_2017", "built_2023": "builtup_{city}_2023",
    "dw_2017": "dw_{city}_2017", "dw_2023": "dw_{city}_2023",
    "ghsl_2017": "ghsl_{city}_2017", "ghsl_2023": "ghsl_{city}_2023",
}
OVERVIEWS = [2, 4, 8, 16]

ROOT = Path(__file__).resolve().parents[1]
MAP_DIR = ROOT / "data" / "interim" / "maps"
PROCESSED_DIR = ROOT / "data" / "processed"
COUNT_TABLE = ROOT / "outputs" / "tables" / "map_pixel_counts.csv"


def change_map(built_start: np.ndarray, built_end: np.ndarray) -> np.ndarray:
    """Change classes (Step 6.3); NODATA where either year has no data."""
    out = np.full(built_start.shape, NODATA, dtype=np.uint8)
    valid = (built_start != NODATA) & (built_end != NODATA)
    s, e = built_start == 1, built_end == 1
    out[valid & ~s & ~e] = 0
    out[valid & s & e] = 1
    out[valid & ~s & e] = 2
    out[valid & s & ~e] = 3
    return out


def write_cog(path: Path, array: np.ndarray, profile: dict, description: str) -> None:
    """Write a single-band uint8 tiled, compressed GeoTIFF with overviews."""
    prof = {**profile, "count": 1, "dtype": "uint8", "nodata": NODATA, "compress": "deflate",
            "tiled": True, "blockxsize": 512, "blockysize": 512}
    with rasterio.open(path, "w", **prof) as dst:
        dst.write(array, 1)
        dst.set_band_description(1, description)
        dst.build_overviews(OVERVIEWS, Resampling.nearest)


def _load_urban_extent():
    """gee/02_urban_extent.py (city centres, radii and the centre-distance helper)."""
    path = ROOT / "gee" / "02_urban_extent.py"
    spec = importlib.util.spec_from_file_location("urban_extent", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def aoi_mask(city: str, profile: dict) -> np.ndarray:
    """Cells whose centre lies inside the working AOI circle.

    The Earth Engine asset holds only the circle; the download fills the rest of the bounding
    box with 0, which would read as "non-built", so it is set to NODATA here.
    """
    ue = _load_urban_extent()
    c = ue.CITIES[city]
    return ue.centre_distance(profile, c) <= c.radius_km * 1000


def process_city(city: str) -> list[dict]:
    """Split the stack into COGs, build the change map, and count pixels per class."""
    with rasterio.open(MAP_DIR / f"maps_{city}.tif") as src:
        stack = {src.descriptions[i] or f"b{i + 1}": src.read(i + 1) for i in range(src.count)}
        profile = src.profile
        pixel_km2 = abs(src.transform.a * src.transform.e) / 1e6
    inside = aoi_mask(city, profile)
    stack = {k: np.where(inside, v, NODATA).astype(np.uint8) for k, v in stack.items()}
    missing = set(LAYERS) - set(stack)
    if missing:
        raise KeyError(f"{city}: stack lacks bands {sorted(missing)}")
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    for band, stem in LAYERS.items():
        write_cog(PROCESSED_DIR / f"{stem.format(city=city)}.tif", stack[band], profile, band)
    change = change_map(stack["built_2017"], stack["built_2023"])
    write_cog(PROCESSED_DIR / f"change_{city}_2017_2023.tif", change, profile,
              "0 non-built, 1 stable built, 2 new built, 3 reversal")

    rows = []
    for code, name in CHANGE_CLASSES.items():
        n = int((change == code).sum())
        rows.append({"city": city, "layer": "change_2017_2023", "class": name, "pixels": n,
                     "km2": round(n * pixel_km2, 2)})
    for band in ("built_2017", "built_2023", "dw_2017", "dw_2023"):
        n = int((stack[band] == 1).sum())
        rows.append({"city": city, "layer": band, "class": "built", "pixels": n,
                     "km2": round(n * pixel_km2, 2)})
    n_rev, n_built17 = rows[3]["pixels"], int((stack["built_2017"] == 1).sum())
    LOG.info("%s: reversals %d px (%.1f%% of 2017 built) - inspect over Sentinel-2", city,
             n_rev, 100 * n_rev / max(n_built17, 1))
    return rows


def main() -> None:
    """Process the given cities and write the pixel-count table."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("cities", nargs="*", default=list(CITIES))
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    rows = [r for city in args.cities for r in process_city(city)]
    table = pd.DataFrame(rows)
    LOG.info("Pixel counts:\n%s", table.to_string(index=False))
    COUNT_TABLE.parent.mkdir(parents=True, exist_ok=True)
    if COUNT_TABLE.exists():
        old = pd.read_csv(COUNT_TABLE, encoding="utf-8")
        table = pd.concat([old[~old["city"].isin(args.cities)], table], ignore_index=True)
    table.to_csv(COUNT_TABLE, index=False, encoding="utf-8")


if __name__ == "__main__":
    main()
