"""Phase 7, Step 7.1: stratified random validation sample (Olofsson et al., 2014).

Strata come from the own change map (src/06_change_maps.py) inside each city's study extent
(union of 2017 and 2023, own model, gee/02_urban_extent.py --built-source model):
stable non-built, stable built, new built, reversal. Allocation per city follows PCD 7.1
(100, 100, 100, 25). If a stratum has fewer pixels than its allocation, all are taken and the
shortfall is logged. One random generator, seed 42, draws cities in a fixed order.

A reserve of RESERVE_SHARE extra points per stratum is drawn in the same random order; a
point labelled "unclear" is replaced by the next unused reserve point of its own stratum
(docs/response_design.md), which keeps the design random.

Each point is the centre of a 10 m map pixel. Files written:
    data/raw/validation/validation_points.csv  plotid, city, stratum, reserve, reserve_rank,
                                               lon, lat, x, y (the KEY; analysis only, never
                                               opened while labelling)
    data/raw/validation/ceo_upload.csv         main points: plotid, lon, lat only, shuffled,
                                               so interpretation in Collect Earth Online is blind
    data/raw/validation/ceo_reserve.csv        reserve points, same columns, for replacements
    outputs/tables/TableS1_sample_design.csv   city, stratum, mapped area (km²), W_i, n_i
    outputs/provenance/validation_sample.json

Run:  python src/07_validation_sample.py
"""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from pyproj import Transformer
from rasterio import features

LOG = logging.getLogger("validation_sample")

SEED = 42
CITIES = ("karachi", "lahore", "faisalabad", "peshawar", "rawalpindi")
STRATA = {0: "stable non-built", 1: "stable built", 2: "new built", 3: "reversal"}
ALLOCATION = {0: 100, 1: 100, 2: 100, 3: 25}
RESERVE_SHARE = 0.10
NODATA = 255
M2_PER_KM2 = 1e6

ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = ROOT / "data" / "processed"
VALIDATION_DIR = ROOT / "data" / "raw" / "validation"
KEY_CSV = VALIDATION_DIR / "validation_points.csv"
CEO_CSV = VALIDATION_DIR / "ceo_upload.csv"
RESERVE_CSV = VALIDATION_DIR / "ceo_reserve.csv"
DESIGN_TABLE = ROOT / "outputs" / "tables" / "TableS1_sample_design.csv"
PROVENANCE = ROOT / "outputs" / "provenance" / "validation_sample.json"


def sample_strata(strata: np.ndarray, allocation: dict[int, int], rng: np.random.Generator
                  ) -> dict[int, np.ndarray]:
    """Draw flat pixel indices per stratum without replacement.

    Returns:
        Stratum code -> flat indices in random draw order (all pixels if fewer than the
        allocation), so any prefix is itself a simple random sample of the stratum.
    """
    flat = strata.ravel()
    out = {}
    for code, n in allocation.items():
        idx = np.flatnonzero(flat == code)
        take = min(n, idx.size)
        out[code] = rng.choice(idx, size=take, replace=False) if take else idx[:0]
    return out


def with_reserve(allocation: dict[int, int], share: float = RESERVE_SHARE) -> dict[int, int]:
    """Allocation plus reserve points (at least one per stratum)."""
    return {code: n + max(1, int(np.ceil(n * share))) for code, n in allocation.items()}


def design_table(strata: np.ndarray, drawn: dict[int, np.ndarray], pixel_km2: float,
                 city: str) -> pd.DataFrame:
    """Mapped area, weight W_i and planned sample size n_i per stratum (Table S1)."""
    counts = {code: int((strata == code).sum()) for code in STRATA}
    total = sum(counts.values())
    return pd.DataFrame([{
        "city": city, "stratum": STRATA[code],
        "mapped_area_km2": counts[code] * pixel_km2,
        "W_i": counts[code] / total if total else np.nan,
        "n_i": int(min(drawn[code].size, ALLOCATION[code])),
    } for code in STRATA])


def city_sample(city: str, rng: np.random.Generator) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Points and design rows for one city."""
    with rasterio.open(PROCESSED_DIR / f"change_{city}_2017_2023.tif") as src:
        change = src.read(1)
        transform, crs = src.transform, src.crs
    extent = gpd.read_file(PROCESSED_DIR / f"extent_{city}_union.gpkg").to_crs(crs)
    inside = features.geometry_mask(extent.geometry, out_shape=change.shape,
                                    transform=transform, invert=True)
    strata = np.where(inside, change, NODATA)
    drawn = sample_strata(strata, with_reserve(ALLOCATION), rng)
    for code, idx in drawn.items():
        if idx.size < ALLOCATION[code]:
            LOG.warning("%s: stratum %s has only %d pixels (< %d)", city, STRATA[code],
                        idx.size, ALLOCATION[code])

    rows, cols, codes, ranks = [], [], [], []
    for code, idx in drawn.items():
        r, c = np.unravel_index(idx, strata.shape)
        rows.append(r)
        cols.append(c)
        codes.append(np.full(idx.size, code))
        ranks.append(np.arange(idx.size))
    r, c, code = np.concatenate(rows), np.concatenate(cols), np.concatenate(codes)
    rank = np.concatenate(ranks)
    n_main = np.array([ALLOCATION[k] for k in code])
    xs, ys = rasterio.transform.xy(transform, r, c)  # pixel centres
    lon, lat = Transformer.from_crs(crs, "EPSG:4326", always_xy=True).transform(xs, ys)
    points = pd.DataFrame({"city": city, "stratum": [STRATA[k] for k in code],
                           "reserve": rank >= n_main,
                           "reserve_rank": np.where(rank >= n_main, rank - n_main + 1, 0),
                           "lon": np.round(lon, 7), "lat": np.round(lat, 7),
                           "x": xs, "y": ys})
    pixel_km2 = abs(transform.a * transform.e) / M2_PER_KM2
    return points, design_table(strata, drawn, pixel_km2, city)


def main() -> None:
    """Draw the sample for all cities and write the key, the CEO file and Table S1."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if KEY_CSV.exists():
        raise FileExistsError(f"{KEY_CSV} exists; the sample is drawn once. Delete it on purpose "
                              "to redraw (only before any labelling has started).")
    rng = np.random.default_rng(SEED)
    parts = [city_sample(city, rng) for city in CITIES]
    points = pd.concat([p for p, _ in parts], ignore_index=True)
    design = pd.concat([d for _, d in parts], ignore_index=True)

    order = rng.permutation(len(points))  # plot IDs carry no stratum or city order
    points = points.iloc[order].reset_index(drop=True)
    points.insert(0, "plotid", np.arange(1, len(points) + 1))

    VALIDATION_DIR.mkdir(parents=True, exist_ok=True)
    points.to_csv(KEY_CSV, index=False, encoding="utf-8")
    ceo_cols = ["plotid", "lon", "lat"]
    points.loc[~points["reserve"], ceo_cols].to_csv(CEO_CSV, index=False, encoding="utf-8")
    points.loc[points["reserve"], ceo_cols].to_csv(RESERVE_CSV, index=False, encoding="utf-8")
    DESIGN_TABLE.parent.mkdir(parents=True, exist_ok=True)
    design.to_csv(DESIGN_TABLE, index=False, encoding="utf-8")
    LOG.info("Sample design:\n%s", design.to_string(index=False))
    LOG.info("%d main + %d reserve points; CEO files have no stratum or city column",
             int((~points["reserve"]).sum()), int(points["reserve"].sum()))

    record = {
        "run_utc": datetime.now(UTC).isoformat(),
        "script": "src/07_validation_sample.py",
        "seed": SEED, "design": "stratified random, Olofsson et al. (2014)",
        "strata_source": "data/processed/change_{city}_2017_2023.tif inside "
                         "extent_{city}_union.gpkg (own model)",
        "allocation": {STRATA[k]: v for k, v in ALLOCATION.items()},
        "reserve_share": RESERVE_SHARE,
        "unit": "10 m pixel, point at pixel centre",
        "n_main": int((~points["reserve"]).sum()), "n_reserve": int(points["reserve"].sum()),
        "files": {"key": str(KEY_CSV.relative_to(ROOT)), "ceo": str(CEO_CSV.relative_to(ROOT)),
                  "reserve": str(RESERVE_CSV.relative_to(ROOT))},
    }
    PROVENANCE.parent.mkdir(parents=True, exist_ok=True)
    PROVENANCE.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
