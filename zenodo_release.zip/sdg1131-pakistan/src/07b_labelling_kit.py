"""Phase 7: labelling kit for blind interpretation in Google Earth Pro (alternative to CEO setup).

Builds, from the blind upload file only (plotid, lon, lat; no city, stratum or map class):
    data/raw/validation/labelling_points.kml   one placemark per plot: the 10 m plot square
                                               centred on the point, named by plotid, in plot
                                               order; open in Google Earth Pro and step through
                                               with the historical imagery slider
    data/raw/validation/labelling_sheet.csv    answer sheet, one row per plot, with the question
                                               columns read by src/08_accuracy_area.py

The interpreter fills "Built in 2017?" and "Built in 2023?" with Yes / No / Unclear and the
image date and source columns, following docs/response_design.md, then saves the sheet as
data/raw/validation/ceo_export.csv (same format as a CEO export).

The key file (validation_points.csv) is never read here, so the kit stays blind.

Run:  python src/07b_labelling_kit.py              (main sample)
      python src/07b_labelling_kit.py --reserve    (reserve points, labelled only on request)
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from xml.sax.saxutils import escape

import pandas as pd
from pyproj import Geod

LOG = logging.getLogger("labelling_kit")

PLOT_SIZE_M = 10
QUESTION_COLUMNS = ["Built in 2017?", "Built in 2023?", "Image date 2017", "Image source 2017",
                    "Image date 2023", "Image source 2023", "Note"]
ROOT = Path(__file__).resolve().parents[1]
VALIDATION = ROOT / "data" / "raw" / "validation"
GEOD = Geod(ellps="WGS84")


def plot_square(lon: float, lat: float, size_m: float = PLOT_SIZE_M) -> list[tuple[float, float]]:
    """Corners (lon, lat) of a size_m square centred on the point, closed ring, N-up."""
    half = size_m / 2
    ring = []
    for dx, dy in ((-half, -half), (half, -half), (half, half), (-half, half), (-half, -half)):
        lo, la, _ = GEOD.fwd(lon, lat, 90, dx)
        lo, la, _ = GEOD.fwd(lo, la, 0, dy)
        ring.append((lo, la))
    return ring


def kml(points: pd.DataFrame) -> str:
    """KML document with one plot-square placemark per point."""
    head = ['<?xml version="1.0" encoding="UTF-8"?>',
            '<kml xmlns="http://www.opengis.net/kml/2.2"><Document>',
            "<name>SDG 11.3.1 validation plots</name>",
            '<Style id="plot"><LineStyle><color>ff00ffff</color><width>2</width></LineStyle>'
            "<PolyStyle><fill>0</fill></PolyStyle></Style>"]
    body = []
    for r in points.itertuples():
        coords = " ".join(f"{lo:.7f},{la:.7f},0" for lo, la in plot_square(r.lon, r.lat))
        body.append(
            f"<Placemark><name>{escape(str(r.plotid))}</name><styleUrl>#plot</styleUrl>"
            f"<LookAt><longitude>{r.lon:.7f}</longitude><latitude>{r.lat:.7f}</latitude>"
            "<range>120</range><tilt>0</tilt></LookAt>"
            f"<Polygon><outerBoundaryIs><LinearRing><coordinates>{coords}</coordinates>"
            "</LinearRing></outerBoundaryIs></Polygon></Placemark>")
    return "\n".join(head + body + ["</Document></kml>"]) + "\n"


def answer_sheet(points: pd.DataFrame) -> pd.DataFrame:
    """Empty answer sheet in plot order."""
    sheet = points[["plotid", "lon", "lat"]].copy()
    for col in QUESTION_COLUMNS:
        sheet[col] = ""
    return sheet


def main() -> None:
    """Write the KML and the answer sheet for the main or the reserve sample."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--reserve", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    src = VALIDATION / ("ceo_reserve.csv" if args.reserve else "ceo_upload.csv")
    points = pd.read_csv(src, encoding="utf-8").sort_values("plotid")
    tag = "_reserve" if args.reserve else ""
    kml_path = VALIDATION / f"labelling_points{tag}.kml"
    sheet_path = VALIDATION / f"labelling_sheet{tag}.csv"
    kml_path.write_text(kml(points), encoding="utf-8")
    if sheet_path.exists():
        raise FileExistsError(f"{sheet_path.name} exists; it may hold answers. Not overwritten.")
    answer_sheet(points).to_csv(sheet_path, index=False, encoding="utf-8-sig")  # Excel-ready
    LOG.info("Wrote %s and %s (%d plots)", kml_path.name, sheet_path.name, len(points))


if __name__ == "__main__":
    main()
