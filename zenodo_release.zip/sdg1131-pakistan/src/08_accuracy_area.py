"""Phase 8: accuracy and area estimation from the independent validation sample.

Inputs:
    data/raw/validation/validation_points.csv   key (src/07_validation_sample.py)
    data/raw/validation/ceo_export.csv          interpreter labels from Collect Earth Online
    outputs/tables/TableS1_sample_design.csv    stratum sizes
    data/processed/*                            maps (src/06_change_maps.py), extents

Reference labels are the interpreter's answers only. Points answered "Unclear" for a year are
left out of that year; points replaced by reserves (docs/response_design.md) enter through
their reserve. Estimators: src/estimators.py. The own change map's strata equal its classes,
so its error matrix and areas follow PRD eq. (5) to (8) (Olofsson et al., 2014). The own
yearly maps, Dynamic World and GHSL have classes that differ from the strata and are scored
with Stehman (2014) ratio estimators (PRD Phase 8.2). GHSL is "built" where its interpolated
fraction is >= 0.50 (PCD 6.4).

Area-adjusted built-up area comes from the reference labels, so it is one estimate per city and
year (with 95% CI); each product's mapped (pixel-counted) area is reported beside it.

Outputs:
    outputs/tables/Table5_accuracy.csv
    outputs/tables/Table6_area_estimates.csv
    outputs/tables/TableS2_error_matrices.csv
    outputs/tables/accuracy_fringe.csv         Step 8.3, suburban ring of the 2023 extent
    outputs/provenance/accuracy_area.json

Run:  python src/08_accuracy_area.py
"""

from __future__ import annotations

import importlib.util
import json
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from rasterio import features

LOG = logging.getLogger("accuracy_area")

CITIES = ("karachi", "lahore", "faisalabad", "peshawar", "rawalpindi")
YEARS = (2017, 2023)
STRATUM_CODES = {"stable non-built": 0, "stable built": 1, "new built": 2, "reversal": 3}
GHSL_BUILT_MIN_PCT = 50  # GHSL fraction x 100 >= 50 -> built (PCD 6.4)
SUBURBAN_CLASS = 1  # urbanness raster: 0 rural, 1 suburban, 2 urban
NODATA = 255
PIXEL_KM2 = 1e-4  # 10 m pixels
# Collect Earth Online question texts (docs/response_design.md section 3)
CEO_QUESTIONS = {2017: "Built in 2017?", 2023: "Built in 2023?"}
ANSWER_CODES = {"yes": 1, "no": 0}

ROOT = Path(__file__).resolve().parents[1]
VALIDATION_DIR = ROOT / "data" / "raw" / "validation"
PROCESSED_DIR = ROOT / "data" / "processed"
DENSITY_DIR = ROOT / "data" / "interim" / "density"
TABLE_DIR = ROOT / "outputs" / "tables"
PROVENANCE = ROOT / "outputs" / "provenance" / "accuracy_area.json"


def _load_estimators():
    path = Path(__file__).with_name("estimators.py")
    spec = importlib.util.spec_from_file_location("estimators", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


est = _load_estimators()


# --- Inputs ------------------------------------------------------------------
def read_reference(path: Path) -> pd.DataFrame:
    """Interpreter answers per plot: ref_2017, ref_2023 as 1 / 0 / NaN (unclear or missing).

    Accepts a CEO export whose question columns are named by the question text (matched
    case-insensitively, ignoring surrounding spaces).
    """
    raw = pd.read_csv(path, encoding="utf-8")
    cols = {c.strip().lower(): c for c in raw.columns}
    if "plotid" not in cols:
        raise KeyError(f"{path.name}: no plotid column")
    out = pd.DataFrame({"plotid": raw[cols["plotid"]].astype(int)})
    for year, question in CEO_QUESTIONS.items():
        col = cols.get(question.lower())
        if col is None:
            raise KeyError(f"{path.name}: no column for question {question!r}")
        answers = raw[col].astype(str).str.strip().str.lower()
        out[f"ref_{year}"] = answers.map(ANSWER_CODES)  # "unclear" / blank -> NaN
    return out


def raster_values(path: Path, xs: np.ndarray, ys: np.ndarray) -> np.ndarray:
    """Values of a single-band raster at projected coordinates."""
    with rasterio.open(path) as src:
        return np.array([v[0] for v in src.sample(zip(xs, ys, strict=True))])


def map_values(city: str, pts: pd.DataFrame) -> pd.DataFrame:
    """Own, Dynamic World and GHSL classes and the fringe flag at the city's points."""
    xs, ys = pts["x"].to_numpy(), pts["y"].to_numpy()
    out = pd.DataFrame(index=pts.index)
    for year in YEARS:
        out[f"own_{year}"] = raster_values(PROCESSED_DIR / f"builtup_{city}_{year}.tif", xs, ys)
        out[f"dw_{year}"] = raster_values(PROCESSED_DIR / f"dw_{city}_{year}.tif", xs, ys)
        ghsl = raster_values(PROCESSED_DIR / f"ghsl_{city}_{year}.tif", xs, ys)
        out[f"ghsl_{year}"] = np.where(ghsl == NODATA, NODATA, ghsl >= GHSL_BUILT_MIN_PCT)
    out["change"] = raster_values(PROCESSED_DIR / f"change_{city}_2017_2023.tif", xs, ys)
    urbanness = raster_values(DENSITY_DIR / f"urbanness_{city}_2023.tif", xs, ys)
    out["fringe"] = urbanness == SUBURBAN_CLASS
    return out


def mapped_areas(city: str) -> dict[str, float]:
    """Pixel-counted built area (km²) of each source and year inside the study extent."""
    areas = {}
    with rasterio.open(PROCESSED_DIR / f"builtup_{city}_2017.tif") as src:
        shape, transform, crs = src.shape, src.transform, src.crs
    extent = gpd.read_file(PROCESSED_DIR / f"extent_{city}_union.gpkg").to_crs(crs)
    inside = features.geometry_mask(extent.geometry, out_shape=shape, transform=transform,
                                    invert=True)
    for year in YEARS:
        for source, stem in (("own", "builtup"), ("dw", "dw"), ("ghsl", "ghsl")):
            with rasterio.open(PROCESSED_DIR / f"{stem}_{city}_{year}.tif") as src:
                a = src.read(1)
            built = (a >= GHSL_BUILT_MIN_PCT) & (a != NODATA) if source == "ghsl" else a == 1
            areas[f"{source}_{year}"] = float((built & inside).sum() * PIXEL_KM2)
    return areas


# --- Estimation (pure; tested) -----------------------------------------------
def assess_city(df: pd.DataFrame, n_pixels: dict[int, int]) -> dict[str, pd.DataFrame]:
    """Accuracy, area, error matrices and fringe accuracy for one city.

    Args:
        df: One row per labelled point with columns ``h`` (stratum code), ``ref_{year}``
            (1/0/NaN), ``own_{year}``, ``dw_{year}``, ``ghsl_{year}``, ``change``, ``fringe``.
        n_pixels: Stratum code -> number of pixels in the study extent.

    Returns:
        Tables keyed "accuracy", "area", "matrices", "fringe".
    """
    acc_rows, area_rows, mat_rows, fringe_rows = [], [], [], []
    a_tot = sum(n_pixels.values()) * PIXEL_KM2
    for year in YEARS:
        d = df[df[f"ref_{year}"].notna()]
        ref = d[f"ref_{year}"].astype(int).to_numpy()
        area = est.proportion(ref == 1, d["h"], n_pixels).scaled(a_tot)
        lo, hi = area.ci95
        area_rows.append({"year": year, "n": len(d), "area_km2": area.value,
                          "se_km2": area.se, "ci_low_km2": lo, "ci_high_km2": hi})
        for source in ("own", "dw", "ghsl"):
            m = d[f"{source}_{year}"].to_numpy()
            a = est.accuracy(m, ref, d["h"], n_pixels)
            row = {"map": source, "year": year, "n": len(d)}
            for k in ("OA", "UA", "PA"):
                lo, hi = a[k].ci95
                row.update({k: 100 * a[k].value, f"{k}_ci_low": 100 * lo,
                            f"{k}_ci_high": 100 * hi})
            row["F1"] = 100 * a["F1"].value
            acc_rows.append(row)
            mat = est.error_matrix(m, ref, d["h"], n_pixels, classes=[1, 0])
            for i in (1, 0):
                for j in (1, 0):
                    mat_rows.append({"map": source, "year": year, "map_class": i,
                                     "ref_class": j, "p_ij": mat.loc[i, j]})
            fr = est.domain_accuracy(m, ref, d["fringe"].to_numpy(), d["h"], n_pixels)
            fringe_rows.append({"map": source, "year": year, "n_fringe": int(d["fringe"].sum()),
                                **{k: 100 * fr[k].value for k in ("OA", "UA", "PA")}})
    both = df[df["ref_2017"].notna() & df["ref_2023"].notna()]
    cov = est.covariance(both["ref_2017"] == 1, both["ref_2023"] == 1, both["h"], n_pixels)
    area_df = pd.DataFrame(area_rows).assign(cov_2017_2023_km2sq=cov * a_tot**2)
    ref_change = change_class(both["ref_2017"].astype(int), both["ref_2023"].astype(int))
    mat = est.error_matrix(both["change"].to_numpy(), ref_change, both["h"], n_pixels,
                           classes=[0, 1, 2, 3])
    for i in range(4):
        for j in range(4):
            mat_rows.append({"map": "own_change", "year": "2017-2023", "map_class": i,
                             "ref_class": j, "p_ij": mat.loc[i, j]})
    return {"accuracy": pd.DataFrame(acc_rows), "area": area_df,
            "matrices": pd.DataFrame(mat_rows), "fringe": pd.DataFrame(fringe_rows)}


def change_class(start: pd.Series, end: pd.Series) -> np.ndarray:
    """Reference change class: 0 non-built both, 1 stable built, 2 new built, 3 reversal."""
    s, e = start.to_numpy() == 1, end.to_numpy() == 1
    return np.select([~s & ~e, s & e, ~s & e], [0, 1, 2], default=3)


def main() -> None:
    """Run the assessment for all cities and write Tables 5, 6, S2 and the fringe table."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    key = pd.read_csv(VALIDATION_DIR / "validation_points.csv", encoding="utf-8")
    ref = read_reference(VALIDATION_DIR / "ceo_export.csv")
    labelled = key.merge(ref, on="plotid", how="inner")
    design = pd.read_csv(TABLE_DIR / "TableS1_sample_design.csv", encoding="utf-8")
    LOG.info("%d of %d key points have labels", len(labelled), len(key))

    tables: dict[str, list[pd.DataFrame]] = {"accuracy": [], "area": [], "matrices": [],
                                             "fringe": []}
    for city in CITIES:
        pts = labelled[labelled["city"] == city].copy()
        pts["h"] = pts["stratum"].map(STRATUM_CODES)
        pts = pts.join(map_values(city, pts))
        mismatch = int((pts["change"] != pts["h"]).sum())
        if mismatch:
            raise ValueError(f"{city}: {mismatch} points whose map class differs from stratum")
        d = design[design["city"] == city]
        n_pixels = {STRATUM_CODES[s]: int(round(a / PIXEL_KM2))
                    for s, a in zip(d["stratum"], d["mapped_area_km2"], strict=True)}
        out = assess_city(pts, n_pixels)
        mapped = mapped_areas(city)
        out["area"]["own_mapped_km2"] = [mapped[f"own_{y}"] for y in out["area"]["year"]]
        out["area"]["dw_mapped_km2"] = [mapped[f"dw_{y}"] for y in out["area"]["year"]]
        out["area"]["ghsl_mapped_km2"] = [mapped[f"ghsl_{y}"] for y in out["area"]["year"]]
        for k, v in out.items():
            tables[k].append(v.assign(city=city))

    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    names = {"accuracy": "Table5_accuracy", "area": "Table6_area_estimates",
             "matrices": "TableS2_error_matrices", "fringe": "accuracy_fringe"}
    for k, name in names.items():
        table = pd.concat(tables[k], ignore_index=True)
        table.to_csv(TABLE_DIR / f"{name}.csv", index=False, encoding="utf-8")
        LOG.info("%s:\n%s", name, table.round(2).to_string(index=False))

    record = {
        "run_utc": datetime.now(UTC).isoformat(), "script": "src/08_accuracy_area.py",
        "n_key": len(key), "n_labelled": len(labelled),
        "unclear": {str(y): int(labelled[f"ref_{y}"].isna().sum()) for y in YEARS},
        "estimators": "src/estimators.py: Olofsson (2014) for own change map, Stehman (2014) "
                      "ratio estimators for maps whose classes differ from the strata",
        "ghsl_built": f"fraction x 100 >= {GHSL_BUILT_MIN_PCT}",
        "fringe": "urbanness_{city}_2023 == suburban (own-model extent)",
    }
    PROVENANCE.parent.mkdir(parents=True, exist_ok=True)
    PROVENANCE.write_text(json.dumps(record, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
