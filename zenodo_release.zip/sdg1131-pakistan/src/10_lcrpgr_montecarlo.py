"""Phase 9, Steps 9.2 and 9.3: SDG 11.3.1 (LCRPGR) per city and source, Monte Carlo 95% CI.

Equations (PRD section 7):
    LCR = ln(Urb_2023 / Urb_2017) / y                       (10)
    PGR = ln(Pop_2023 / Pop_2017) / y                       (11)
    LCRPGR = LCR / PGR                                      (12)
    BUpc_t = Urb_t / Pop_t   (reported in m² per person)    (13)
    Urb_t^(k) ~ N(A_t, [A_tot S(p_t)]^2), k = 1..10,000      (16)

Sources and estimate types:
    own, area-adjusted: Urb_t from the validation sample (Table 6), with Monte Carlo CI.
    own / dw / ghsl, mapped: pixel-counted built area inside the study extent. These are
        counts, not sample estimates, so they carry no sampling CI; they are compared against
        the area-adjusted estimate and its CI (H2).

Monte Carlo mode (``--mc``): ``independent`` follows equation (16) as written (2017 and 2023
drawn independently). ``correlated`` draws both years jointly with the covariance estimated
from the shared sample points (src/estimators.py covariance), which equation (16) ignores.
Census population is treated as fixed.

Interpretation (PCD 9.3): "sprawl" if the CI lies above 1, "compact" if below 1, otherwise
"inconclusive"; mapped values without CI get "above 1 (no CI)" / "below 1 (no CI)".

Inputs:
    outputs/tables/Table6_area_estimates.csv   (src/08_accuracy_area.py)
    data/processed/population_extent.csv       (gee/09_population.py)

Outputs:
    outputs/tables/Table7_sdg1131{_correlated}.csv
    outputs/provenance/lcrpgr{_correlated}.json

Run:  python src/10_lcrpgr_montecarlo.py
      python src/10_lcrpgr_montecarlo.py --mc correlated
"""

from __future__ import annotations

import argparse
import json
import logging
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import pandas as pd

LOG = logging.getLogger("lcrpgr")

SEED = 42
N_DRAWS = 10_000
T0, T1 = 2017, 2023
INTERVAL_Y = T1 - T0
CI_PCT = (2.5, 97.5)
M2_PER_KM2 = 1e6

ROOT = Path(__file__).resolve().parents[1]
AREA_TABLE = ROOT / "outputs" / "tables" / "Table6_area_estimates.csv"
POP_TABLE = ROOT / "data" / "processed" / "population_extent.csv"
OUT_DIR = ROOT / "outputs" / "tables"
PROV_DIR = ROOT / "outputs" / "provenance"


def lcr(urb0, urb1, years: float = INTERVAL_Y):
    """Land consumption rate, equation (10)."""
    return np.log(np.asarray(urb1, dtype=float) / np.asarray(urb0, dtype=float)) / years


def pgr(pop0: float, pop1: float, years: float = INTERVAL_Y) -> float:
    """Population growth rate, equation (11)."""
    return float(np.log(pop1 / pop0) / years)


def bupc_m2(urb_km2: float, pop: float) -> float:
    """Built-up area per capita in m² per person, equation (13)."""
    return urb_km2 * M2_PER_KM2 / pop


def draw_areas(a0: float, se0: float, a1: float, se1: float, cov: float, mode: str,
               rng: np.random.Generator, n: int = N_DRAWS) -> np.ndarray:
    """Monte Carlo draws of (Urb_2017, Urb_2023), equation (16); shape (n, 2)."""
    if mode == "independent":
        cov = 0.0
    sigma = np.array([[se0**2, cov], [cov, se1**2]])
    return rng.multivariate_normal([a0, a1], sigma, size=n, method="cholesky")


def interpret(low: float, high: float) -> str:
    """PCD 9.3 interpretation of a CI for LCRPGR."""
    if low > 1:
        return "sprawl"
    if high < 1:
        return "compact"
    return "inconclusive"


def city_rows(city: str, area: pd.DataFrame, pop: pd.DataFrame, mode: str,
              rng: np.random.Generator) -> list[dict]:
    """Table 7 rows for one city."""
    a = area.set_index("year")
    p = pop.set_index("year")["pop_extent"]
    pop0, pop1 = float(p[T0]), float(p[T1])
    g = pgr(pop0, pop1)
    rows = []

    draws = draw_areas(a.loc[T0, "area_km2"], a.loc[T0, "se_km2"], a.loc[T1, "area_km2"],
                       a.loc[T1, "se_km2"], float(a.loc[T0, "cov_2017_2023_km2sq"]), mode, rng)
    valid = (draws > 0).all(axis=1)
    ratio = lcr(draws[valid, 0], draws[valid, 1]) / g
    low, high = np.percentile(ratio, CI_PCT)
    point = float(lcr(a.loc[T0, "area_km2"], a.loc[T1, "area_km2"]) / g)
    rows.append({
        "city": city, "source": "own", "estimate": "area-adjusted",
        "LCR": float(lcr(a.loc[T0, "area_km2"], a.loc[T1, "area_km2"])), "PGR": g,
        "LCRPGR": point, "ci_low": float(low), "ci_high": float(high),
        "BUpc_2017_m2": bupc_m2(a.loc[T0, "area_km2"], pop0),
        "BUpc_2023_m2": bupc_m2(a.loc[T1, "area_km2"], pop1),
        "interpretation": interpret(low, high), "mc_draws_dropped": int((~valid).sum()),
        "point_inside_ci": bool(low <= point <= high),
    })
    for source in ("own", "dw", "ghsl"):
        u0, u1 = a.loc[T0, f"{source}_mapped_km2"], a.loc[T1, f"{source}_mapped_km2"]
        value = float(lcr(u0, u1) / g)
        rows.append({
            "city": city, "source": source, "estimate": "mapped",
            "LCR": float(lcr(u0, u1)), "PGR": g, "LCRPGR": value,
            "ci_low": np.nan, "ci_high": np.nan,
            "BUpc_2017_m2": bupc_m2(u0, pop0), "BUpc_2023_m2": bupc_m2(u1, pop1),
            "interpretation": ("above 1 (no CI)" if value > 1 else "below 1 (no CI)"),
            "mc_draws_dropped": 0, "point_inside_ci": np.nan,
        })
    if g <= 0:
        LOG.warning("%s: PGR <= 0 (%.4f); LCRPGR sign and interpretation need care", city, g)
    return rows


def main() -> None:
    """Compute Table 7 for all cities."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--mc", choices=["independent", "correlated"], default="independent")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    area = pd.read_csv(AREA_TABLE, encoding="utf-8")
    pop = pd.read_csv(POP_TABLE, encoding="utf-8")
    rng = np.random.default_rng(SEED)
    rows = []
    for city in area["city"].unique():
        rows += city_rows(city, area[area["city"] == city], pop[pop["city"] == city],
                          args.mc, rng)
    table = pd.DataFrame(rows)
    bad = table[(table["estimate"] == "area-adjusted") & ~table["point_inside_ci"].astype(bool)]
    if len(bad):
        LOG.warning("Point estimate outside its CI (PCD 9.3 done check): %s",
                    bad["city"].tolist())
    suffix = "" if args.mc == "independent" else "_correlated"
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    table.to_csv(OUT_DIR / f"Table7_sdg1131{suffix}.csv", index=False, encoding="utf-8")
    LOG.info("Table 7:\n%s", table.round(3).to_string(index=False))
    record = {
        "run_utc": datetime.now(UTC).isoformat(), "script": "src/10_lcrpgr_montecarlo.py",
        "seed": SEED, "n_draws": N_DRAWS, "mc_mode": args.mc, "interval_years": INTERVAL_Y,
        "ci_percentiles": CI_PCT, "inputs": [str(AREA_TABLE.relative_to(ROOT)),
                                             str(POP_TABLE.relative_to(ROOT))],
        "population": "census, fixed (no sampling uncertainty)",
    }
    PROV_DIR.mkdir(parents=True, exist_ok=True)
    (PROV_DIR / f"lcrpgr{suffix}.json").write_text(json.dumps(record, indent=2),
                                                   encoding="utf-8")


if __name__ == "__main__":
    main()
