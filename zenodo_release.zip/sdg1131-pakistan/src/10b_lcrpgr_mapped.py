"""SDG 11.3.1 without manual validation (authors' decision, 27 Oct 2026; docs/decisions.md).

There is no reference sample, so there are no accuracy figures, area-adjusted areas or confidence
intervals. Instead, LCRPGR (equations 10 to 12) and BUpc (13) are computed from *mapped*
built-up areas for every data source and every applicable sensitivity setting:

    setting                      own model   Dynamic World   GHSL
    baseline                     yes         yes             yes
    threshold 0.40 / 0.60        label tau_b, retrained   -   map threshold
    label erosion 0 px           retrained   -               -
    extent: Degree of Urbanisation  yes      yes             yes
    population: WorldPop         yes         yes             yes
    population: census units     yes         yes             yes
    change rule: no reversal     yes         yes             -
    change rule: 3-year majority yes         -               -
    continuous built surface     -           -               yes

Population: census units takes PGR from the census units that hold the extent, so it needs no
gridded population at all. No reversal keeps built land built (2023 = 2017 or 2023). 3-year
majority uses the years between (gee/13_midyear_maps.py): a pixel is built if built in at least 2
of 2017-2019, and of 2021-2023; those windows centre on 2018 and 2022, so its LCR uses y = 4.
Continuous built surface sums GHSL fractions instead of thresholding them.

For each city and source, the sensitivity range is the minimum to maximum LCRPGR over its
settings. It is a range over methodological choices, not a confidence interval, and must
never be reported as one. Interpretation: "sprawl (all settings)" if every value > 1, "compact
(all settings)" if every value < 1, otherwise "depends on setting". H2 (source choice flips a
city's interpretation) is read from the baseline values across sources.

RQ2 support: pixel agreement between the 2023 built-up maps of the three sources inside both the
study extent and the Degree of Urbanisation extent (overall agreement, Jaccard index of built,
built share of each map). The study extent comes from the own maps, so it favours the own model;
the Degree of Urbanisation extent does not depend on the own maps, though it is built from GHSL
data. Gross gain, gross loss and net change are reported for the own model and Dynamic World.

Outputs:
    outputs/tables/lcrpgr_all_settings.csv   one row per city x source x setting
    outputs/tables/Table7_sdg1131.csv        baseline + sensitivity range per city x source
    outputs/tables/Table8_sensitivity.csv    change vs baseline per setting, flip flag
    outputs/tables/map_agreement_2023.csv    pairwise agreement of 2023 maps, both extents
    outputs/tables/gross_net_change.csv      gain, loss, net and reversal share, study extent
    outputs/tables/temporal_consistency.csv  own built area per year and pixels flipping repeatedly

Run:  python src/10b_lcrpgr_mapped.py
"""

from __future__ import annotations

import logging
from itertools import combinations
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from rasterio import features
from rasterio.windows import from_bounds

LOG = logging.getLogger("lcrpgr_mapped")

CITIES = ("karachi", "lahore", "faisalabad", "peshawar", "rawalpindi")
T0, T1 = 2017, 2023
INTERVAL_Y = T1 - T0
NODATA = 255
PIXEL_KM2 = 1e-4
M2_PER_KM2 = 1e6
GHSL_BASE_PCT = 50
GHSL_VARIANTS_PCT = {"Map threshold 0.40": 40, "Map threshold 0.60": 60}
OWN_VARIANTS = {"Label threshold 0.40": "_tau040", "Label threshold 0.60": "_tau060",
                "Label erosion 0 px": "_ero0"}
EXTENT_SETTING = "Extent: Degree of Urbanisation"
MAJORITY_MIN = 2  # of 3 years
MAJORITY_INTERVAL_Y = 4  # the 3-year windows centre on 2018 and 2022
MID_YEARS = (2018, 2019, 2021, 2022)
PERCENT = 100
SOURCES = ("own", "dw", "ghsl")

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
MAPS = ROOT / "data" / "interim" / "maps"
TABLES = ROOT / "outputs" / "tables"


# --- Equations (pure; tested) ------------------------------------------------
def lcr(urb0: float, urb1: float, years: float = INTERVAL_Y) -> float:
    """Land consumption rate, equation (10)."""
    return float(np.log(urb1 / urb0) / years)


def pgr(pop0: float, pop1: float, years: float = INTERVAL_Y) -> float:
    """Population growth rate, equation (11)."""
    return float(np.log(pop1 / pop0) / years)


def interpret(values: list[float]) -> str:
    """Interpretation over a set of LCRPGR values (all settings of one city and source)."""
    v = np.asarray(values, dtype=float)
    if (v > 1).all():
        return "sprawl (all settings)"
    if (v < 1).all():
        return "compact (all settings)"
    return "depends on setting"


def no_reversal(built0: np.ndarray, built1: np.ndarray) -> np.ndarray:
    """Consistency rule: land built at the first date stays built at the second."""
    return built0 | built1


def temporal_majority(stack: np.ndarray) -> np.ndarray:
    """Pixels built in at least MAJORITY_MIN of the layers of a boolean (years, H, W) stack."""
    return stack.sum(axis=0) >= MAJORITY_MIN


def gross_change(built0: np.ndarray, built1: np.ndarray) -> dict[str, float]:
    """Gross gain, gross loss and net change (km²), and loss as a share of gain (%)."""
    gain = float((built1 & ~built0).sum() * PIXEL_KM2)
    loss = float((built0 & ~built1).sum() * PIXEL_KM2)
    return {"gain_km2": gain, "loss_km2": loss, "net_km2": gain - loss,
            "loss_pct_of_gain": PERCENT * loss / gain if gain else np.nan}


def repeated_flip_pct(stack: np.ndarray) -> float:
    """Share (%) of ever-built pixels that change state more than once in a (years, H, W) stack."""
    changes = (stack[1:] != stack[:-1]).sum(axis=0)
    ever = stack.any(axis=0)
    return PERCENT * float((changes[ever] > 1).mean()) if ever.any() else np.nan


def pairwise_agreement(maps: dict[str, np.ndarray]) -> list[dict]:
    """Overall agreement and Jaccard index of built for each pair of binary maps."""
    rows = []
    for a, b in combinations(maps, 2):
        x, y = maps[a], maps[b]
        union = (x | y).sum()
        rows.append({"pair": f"{a}-{b}", "overall_agreement_pct": 100 * float((x == y).mean()),
                     "jaccard_built": float((x & y).sum() / union) if union else np.nan,
                     "built_pct_first": 100 * float(x.mean()),
                     "built_pct_second": 100 * float(y.mean())})
    return rows


# --- Raster access -----------------------------------------------------------
def extent_mask(city: str, tag: str, shape, transform, crs) -> np.ndarray:
    """Mask of the own-model union extent (tag '') or the DEGURBA urban centre ('degurba_')."""
    path = PROCESSED / f"extent_{tag}{city}_union.gpkg"
    if not path.exists():
        path = PROCESSED / f"extent_{tag}{city}.gpkg"
    ext = gpd.read_file(path).to_crs(crs)
    return features.geometry_mask(ext.geometry, out_shape=shape, transform=transform,
                                  invert=True)


def built(path: Path, band: str = "", min_value: int = 1) -> tuple[np.ndarray, rasterio.Affine,
                                                                   object]:
    """Binary built map (NODATA -> False) from a band (by name, or band 1)."""
    with rasterio.open(path) as src:
        names = list(src.descriptions)
        idx = names.index(band) + 1 if band and band in names else 1
        a = src.read(idx)
        return (a >= min_value) & (a != NODATA), src.transform, src.crs


def area_km2(path: Path, city: str, tag: str = "", band: str = "", min_value: int = 1) -> float:
    """Built area inside an extent."""
    b, transform, crs = built(path, band, min_value)
    return float((b & extent_mask(city, tag, b.shape, transform, crs)).sum() * PIXEL_KM2)


def population(city: str, suffix: str = "", column: str = "pop_extent") -> tuple[float, float]:
    """Population 2017 and 2023 (gee/09_population.py): in the extent, or of its census units."""
    p = pd.read_csv(PROCESSED / f"population_extent{suffix}.csv", encoding="utf-8")
    p = p[p["city"] == city].set_index("year")[column]
    return float(p[T0]), float(p[T1])


def continuous_area_km2(path: Path, city: str, tag: str = "") -> float:
    """Built surface in an extent: sum of GHSL fractions, with no threshold."""
    with rasterio.open(path) as src:
        a, transform, crs = src.read(1), src.transform, src.crs
    mask = extent_mask(city, tag, a.shape, transform, crs) & (a != NODATA)
    return float(a[mask].sum() / PERCENT * PIXEL_KM2)


def own_in_window(city: str, year: int, bounds, shape) -> np.ndarray:
    """Own built map of one year on the grid of the study-extent stack."""
    with rasterio.open(PROCESSED / f"builtup_{city}_{year}.tif") as src:
        a = src.read(1, window=from_bounds(*bounds, transform=src.transform),
                     out_shape=shape)
    return (a == 1)


def own_stack(city: str) -> tuple[np.ndarray, list[int]] | None:
    """Own built maps of all mapped years inside the study extent (False outside it)."""
    path = MAPS / f"maps_{city}_midyears.tif"
    if not path.exists():
        return None
    with rasterio.open(path) as src:
        names = list(src.descriptions)
        shape, transform, crs, bounds = (src.height, src.width), src.transform, src.crs, src.bounds
        layers = {y: src.read(names.index(f"built_{y}") + 1) == 1 for y in MID_YEARS}
    layers[T0] = own_in_window(city, T0, bounds, shape)
    layers[T1] = own_in_window(city, T1, bounds, shape)
    mask = extent_mask(city, "", shape, transform, crs)
    years = sorted(layers)
    return np.stack([layers[y] & mask for y in years]), years


def source_paths(city: str, source: str, year: int) -> tuple[Path, int]:
    """Baseline raster and built threshold of a source."""
    if source == "own":
        return PROCESSED / f"builtup_{city}_{year}.tif", 1
    if source == "dw":
        return PROCESSED / f"dw_{city}_{year}.tif", 1
    return PROCESSED / f"ghsl_{city}_{year}.tif", GHSL_BASE_PCT


def city_settings(city: str) -> list[dict]:
    """Areas, populations and indicators for every source and applicable setting."""
    rows = []

    def add(source: str, setting: str, u0: float, u1: float, p0: float, p1: float,
            years: int = INTERVAL_Y) -> None:
        g = pgr(p0, p1)
        rows.append({"city": city, "source": source, "setting": setting,
                     "urb_2017_km2": u0, "urb_2023_km2": u1, "pop_2017": p0, "pop_2023": p1,
                     "LCR": lcr(u0, u1, years), "PGR": g, "LCRPGR": lcr(u0, u1, years) / g,
                     "BUpc_2017_m2": u0 * M2_PER_KM2 / p0, "BUpc_2023_m2": u1 * M2_PER_KM2 / p1})

    base_pop = population(city)
    for source in SOURCES:
        (p17, m), (p23, _) = source_paths(city, source, T0), source_paths(city, source, T1)
        u0, u1 = area_km2(p17, city, min_value=m), area_km2(p23, city, min_value=m)
        add(source, "baseline", u0, u1, *base_pop)
        try:
            add(source, "Population: WorldPop", u0, u1, *population(city, "_worldpop_model"))
        except FileNotFoundError:
            LOG.warning("%s: WorldPop population missing", city)
        try:
            d0 = area_km2(p17, city, "degurba_", min_value=m)
            d1 = area_km2(p23, city, "degurba_", min_value=m)
            add(source, EXTENT_SETTING, d0, d1, *population(city, "_ghspop_degurba"))
        except FileNotFoundError:
            LOG.warning("%s: Degree of Urbanisation inputs missing", city)
        add(source, "Population: census units", u0, u1,
            *population(city, column="census_units_total"))
        if source != "ghsl":
            b0, transform, crs = built(p17, min_value=m)
            b1, _, _ = built(p23, min_value=m)
            mask = extent_mask(city, "", b0.shape, transform, crs)
            add(source, "Change rule: no reversal", u0,
                float((no_reversal(b0, b1) & mask).sum() * PIXEL_KM2), *base_pop)
    for setting, variant in OWN_VARIANTS.items():
        path = MAPS / f"maps_{city}{variant}.tif"
        if not path.exists():
            LOG.warning("%s: own-model variant %s missing, skipped", city, variant)
            continue
        add("own", setting, area_km2(path, city, band=f"built_{T0}"),
            area_km2(path, city, band=f"built_{T1}"), *base_pop)
    stacked = own_stack(city)
    if stacked is None:
        LOG.warning("%s: middle-year maps missing, 3-year majority skipped", city)
    else:
        stack, years = stacked
        early = stack[[years.index(y) for y in (T0, 2018, 2019)]]
        late = stack[[years.index(y) for y in (2021, 2022, T1)]]
        add("own", "Change rule: 3-year majority",
            float(temporal_majority(early).sum() * PIXEL_KM2),
            float(temporal_majority(late).sum() * PIXEL_KM2), *base_pop,
            years=MAJORITY_INTERVAL_Y)
    for setting, pct in GHSL_VARIANTS_PCT.items():
        add("ghsl", setting, area_km2(PROCESSED / f"ghsl_{city}_{T0}.tif", city, min_value=pct),
            area_km2(PROCESSED / f"ghsl_{city}_{T1}.tif", city, min_value=pct), *base_pop)
    add("ghsl", "Continuous built surface",
        continuous_area_km2(PROCESSED / f"ghsl_{city}_{T0}.tif", city),
        continuous_area_km2(PROCESSED / f"ghsl_{city}_{T1}.tif", city), *base_pop)
    return rows


def city_change(city: str) -> list[dict]:
    """Gross gain, loss and net change inside the study extent, own model and Dynamic World."""
    rows = []
    for source in ("own", "dw"):
        (p0, m), (p1, _) = source_paths(city, source, T0), source_paths(city, source, T1)
        b0, transform, crs = built(p0, min_value=m)
        b1, _, _ = built(p1, min_value=m)
        mask = extent_mask(city, "", b0.shape, transform, crs)
        rows.append({"city": city, "source": source, **gross_change(b0 & mask, b1 & mask)})
    return rows


def city_consistency(city: str) -> list[dict]:
    """Own built area per mapped year and the share of pixels flipping more than once."""
    stacked = own_stack(city)
    if stacked is None:
        return []
    stack, years = stacked
    flips = repeated_flip_pct(stack)
    return [{"city": city, "year": y, "built_km2": float(layer.sum() * PIXEL_KM2),
             "repeated_flip_pct": flips} for y, layer in zip(years, stack, strict=True)]


def city_agreement(city: str, tag: str = "") -> list[dict]:
    """Pairwise agreement of the 2023 maps inside the study (tag '') or DEGURBA extent."""
    maps, mask = {}, None
    for source in SOURCES:
        path, m = source_paths(city, source, T1)
        b, transform, crs = built(path, min_value=m)
        if mask is None:
            mask = extent_mask(city, tag, b.shape, transform, crs)
        maps[source] = b[mask]
    extent = "degurba" if tag else "study"
    return [{"city": city, "extent": extent, **r} for r in pairwise_agreement(maps)]


def summarise(all_rows: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Table 7 (baseline + range) and Table 8 (change vs baseline, flips)."""
    t7, t8 = [], []
    for (city, source), g in all_rows.groupby(["city", "source"], sort=False):
        base = g[g["setting"] == "baseline"].iloc[0]
        other_extent = g.loc[g["setting"] == EXTENT_SETTING, "LCRPGR"]
        t7.append({"city": city, "source": source, "LCR": base["LCR"], "PGR": base["PGR"],
                   "LCRPGR": base["LCRPGR"],
                   "LCRPGR_degurba": other_extent.iloc[0] if len(other_extent) else np.nan,
                   "range_low": g["LCRPGR"].min(),
                   "range_high": g["LCRPGR"].max(), "n_settings": len(g),
                   "BUpc_2017_m2": base["BUpc_2017_m2"], "BUpc_2023_m2": base["BUpc_2023_m2"],
                   "interpretation": interpret(g["LCRPGR"].tolist())})
        for _, r in g[g["setting"] != "baseline"].iterrows():
            t8.append({"city": city, "source": source, "setting": r["setting"],
                       "baseline_lcrpgr": base["LCRPGR"], "lcrpgr": r["LCRPGR"],
                       "delta_lcrpgr": r["LCRPGR"] - base["LCRPGR"],
                       "flips": (r["LCRPGR"] > 1) != (base["LCRPGR"] > 1)})
    return pd.DataFrame(t7), pd.DataFrame(t8)


def main() -> None:
    """Compute every setting, summarise, and report H2 flips."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    all_rows = pd.DataFrame([r for c in CITIES for r in city_settings(c)])
    t7, t8 = summarise(all_rows)
    agreement = pd.DataFrame([r for c in CITIES for tag in ("", "degurba_")
                              for r in city_agreement(c, tag)])
    change = pd.DataFrame([r for c in CITIES for r in city_change(c)])
    consistency = pd.DataFrame([r for c in CITIES for r in city_consistency(c)])
    TABLES.mkdir(parents=True, exist_ok=True)
    all_rows.to_csv(TABLES / "lcrpgr_all_settings.csv", index=False, encoding="utf-8")
    t7.to_csv(TABLES / "Table7_sdg1131.csv", index=False, encoding="utf-8")
    t8.to_csv(TABLES / "Table8_sensitivity.csv", index=False, encoding="utf-8")
    agreement.to_csv(TABLES / "map_agreement_2023.csv", index=False, encoding="utf-8")
    change.to_csv(TABLES / "gross_net_change.csv", index=False, encoding="utf-8")
    consistency.to_csv(TABLES / "temporal_consistency.csv", index=False, encoding="utf-8")
    LOG.info("Table 7 (baseline and sensitivity range; not CIs):\n%s",
             t7.round(3).to_string(index=False))
    base = t7.pivot(index="city", columns="source", values="LCRPGR")
    h2 = base[(base > 1).any(axis=1) & (base < 1).any(axis=1)]
    LOG.info("H2, cities whose baseline interpretation differs between sources: %s",
             h2.index.tolist() or "none")
    LOG.info("2023 map agreement:\n%s", agreement.round(3).to_string(index=False))
    LOG.info("Gross and net change:\n%s", change.round(2).to_string(index=False))


if __name__ == "__main__":
    main()
