"""Review response: compare the maps with Open Buildings 2.5D Temporal (independent of the labels).

Open Buildings played no part in the labels or the model, so it can look at the pixels that
consensus labels leave out. It is another model's output, so everything here is agreement between
maps. It is not accuracy, and it does not replace the reference sample, which it never touches.

Land cover maps call whole blocks built, streets included, while Open Buildings marks buildings.
Pixels are therefore compared through the building share of the surrounding WINDOW_M square.

    ob_disputed.csv      disputed pixels (1 or 2 products in 2020) inside the study extent: mean
                         building share where each source says built and where it says non-built
    ob_change.csv        mean building share in 2017 and 2023 for the change classes of the own
                         model and Dynamic World, and the building area each class gained. Do
                         reversals lose buildings, or is it map noise? Is growth infill or new land?
    ob_lcr.csv           building area 2017 and 2023 inside both extents, its LCR and LCRPGR
    ob_correlation.csv   100 m cells: Pearson correlation of the building share with GHSL
                         fraction and with the built share of the 10 m maps, for 2023 and change
    ob_dense.csv         share of the cells at least DENSE_MIN_PCT building that each 2023 map
                         calls built, inside the study extent

Run:  python src/10c_open_buildings_check.py
"""

from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from scipy.ndimage import uniform_filter

LOG = logging.getLogger("open_buildings_check")

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
AGREEMENT = ROOT / "data" / "interim" / "agreement"
TABLES = ROOT / "outputs" / "tables"
CITIES = ("karachi", "lahore", "faisalabad", "peshawar", "rawalpindi")
NODATA = 255
PIXEL_M = 10
WINDOW_M = 110
CELL_PX = 10  # 100 m
DENSE_MIN_PCT = 50
PIXEL_KM2 = 1e-4
PERCENT = 100
DISPUTED = (1, 2)
SOURCES = ("own", "dw", "ghsl")
CHANGE_CLASSES = {"stable non-built": (0, 0), "new built": (0, 1), "reversal": (1, 0),
                  "stable built": (1, 1)}


def _load(rel: str, name: str):
    path = ROOT / rel
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


lm = _load("src/10b_lcrpgr_mapped.py", "lcrpgr_mapped")


def local_share(share: np.ndarray, window_px: int) -> np.ndarray:
    """Mean of a 10 m share map in a square window around each pixel."""
    return uniform_filter(share.astype("float32"), size=window_px, mode="nearest")


def split_by_call(share: np.ndarray, call: np.ndarray, scope: np.ndarray) -> dict[str, float]:
    """Mean share where a map says built and non-built, inside ``scope``."""
    built, other = share[scope & call], share[scope & ~call]
    return {"share_where_built_pct": float(built.mean()) if built.size else np.nan,
            "share_where_nonbuilt_pct": float(other.mean()) if other.size else np.nan,
            "built_pct_of_scope": PERCENT * float(call[scope].mean())}


def building_change_km2(share0: np.ndarray, share1: np.ndarray, scope: np.ndarray) -> float:
    """Change in building area (km2) inside ``scope`` from 10 m shares in percent."""
    return (float(share1[scope].sum()) - float(share0[scope].sum())) / PERCENT * PIXEL_KM2


def cell_means(a: np.ndarray, valid: np.ndarray, cell_px: int = CELL_PX) -> np.ndarray:
    """Block means over complete valid cells; NaN where a cell has any invalid pixel."""
    rows, cols = (s // cell_px * cell_px for s in a.shape)
    shape = (rows // cell_px, cell_px, cols // cell_px, cell_px)
    blocks = a[:rows, :cols].astype("float32").reshape(shape)
    ok = valid[:rows, :cols].reshape(shape).all(axis=(1, 3))
    return np.where(ok, blocks.mean(axis=(1, 3)), np.nan)


def pearson(x: np.ndarray, y: np.ndarray) -> float:
    """Pearson correlation over cells where both values exist."""
    m = np.isfinite(x) & np.isfinite(y)
    return float(np.corrcoef(x[m], y[m])[0, 1]) if m.sum() > 1 else np.nan


def read_ob(city: str) -> tuple[np.ndarray, np.ndarray, rasterio.Affine, object]:
    """Open Buildings shares (%) for 2017 and 2023, with the grid of the raster."""
    with rasterio.open(PROCESSED / f"ob_{city}.tif") as src:
        return src.read(1), src.read(2), src.transform, src.crs


def source_built(city: str, year: int) -> dict[str, np.ndarray]:
    """Built maps of the three sources for one year."""
    out = {}
    for source in SOURCES:
        path, m = lm.source_paths(city, source, year)
        out[source] = lm.built(path, min_value=m)[0]
    return out


def city_tables(city: str, pop: pd.DataFrame) -> tuple[list, list, list, list, list]:
    """All five comparison tables for one city."""
    ob17, ob23, transform, crs = read_ob(city)
    valid = (ob17 != NODATA) & (ob23 != NODATA)
    study = lm.extent_mask(city, "", ob17.shape, transform, crs) & valid
    window = WINDOW_M // PIXEL_M
    near17 = local_share(np.where(valid, ob17, 0), window)
    near23 = local_share(np.where(valid, ob23, 0), window)
    b17, b23 = source_built(city, lm.T0), source_built(city, lm.T1)

    with rasterio.open(AGREEMENT / f"count_{city}_2020.tif") as src:
        count = src.read(1)
    disputed = study & np.isin(count, DISPUTED)
    dis = [{"city": city, "source": s, **split_by_call(near23, b23[s], disputed)} for s in SOURCES]

    dense = study & (ob23 >= DENSE_MIN_PCT)
    dense_rows = [{"city": city, "source": s, "cells": int(dense.sum()),
                   "built_pct": PERCENT * float(b23[s][dense].mean())} for s in SOURCES]

    change = []
    for source in ("own", "dw"):
        for label, (was, now) in CHANGE_CLASSES.items():
            scope = study & (b17[source] == bool(was)) & (b23[source] == bool(now))
            if not scope.any():
                continue
            change.append({"city": city, "source": source, "class": label,
                           "area_km2": float(scope.sum() * PIXEL_KM2),
                           "share_2017_pct": float(near17[scope].mean()),
                           "share_2023_pct": float(near23[scope].mean()),
                           "gained_buildings_pct_of_class":
                               PERCENT * float((near23[scope] > near17[scope]).mean()),
                           "building_change_km2": building_change_km2(ob17, ob23, scope)})

    lcr_rows = []
    for tag, name in (("", "study"), ("degurba_", "degurba")):
        mask = lm.extent_mask(city, tag, ob17.shape, transform, crs) & valid
        a17 = float(ob17[mask].sum()) / PERCENT * PIXEL_KM2
        a23 = float(ob23[mask].sum()) / PERCENT * PIXEL_KM2
        suffix = "_ghspop_degurba" if tag else ""
        p = pop[suffix]
        lcr, pgr = lm.lcr(a17, a23), lm.pgr(*p[city])
        lcr_rows.append({"city": city, "extent": name, "building_km2_2017": a17,
                         "building_km2_2023": a23, "LCR": lcr, "PGR": pgr, "LCRPGR": lcr / pgr})

    cells = cell_means(ob23, study)
    cells17 = cell_means(ob17, study)
    corr = []
    for source in SOURCES:
        with rasterio.open(lm.source_paths(city, source, lm.T1)[0]) as src:
            raw23 = src.read(1)
        with rasterio.open(lm.source_paths(city, source, lm.T0)[0]) as src:
            raw17 = src.read(1)
        # GHSL as its continuous fraction; the 10 m maps as built share of the cell
        v23 = raw23 if source == "ghsl" else PERCENT * b23[source]
        v17 = raw17 if source == "ghsl" else PERCENT * b17[source]
        m23, m17 = cell_means(v23, study), cell_means(v17, study)
        corr.append({"city": city, "source": source, "r_2023": pearson(cells, m23),
                     "r_change": pearson(cells - cells17, m23 - m17)})
    return dis, change, lcr_rows, corr, dense_rows


def main() -> None:
    """Write the five comparison tables."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    pop = {s: {c: lm.population(c, s) for c in CITIES} for s in ("", "_ghspop_degurba")}
    parts = [city_tables(c, pop) for c in CITIES]
    names = ("ob_disputed", "ob_change", "ob_lcr", "ob_correlation", "ob_dense")
    for i, name in enumerate(names):
        table = pd.DataFrame([r for p in parts for r in p[i]])
        table.to_csv(TABLES / f"{name}.csv", index=False, encoding="utf-8")
        LOG.info("%s:\n%s", name, table.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
