"""Phase 10: sensitivity of LCRPGR to one setting at a time (PCD Phase 10).

Settings (baseline in brackets) and what each changes:
    GHSL built threshold tau_b  0.40, (0.50), 0.60   own model retrained (maps_{city}_tau040,
                                                     _tau060) and the GHSL mapped area
    Consensus erosion           0, (1) pixel         own model retrained (maps_{city}_ero0)
    Urban extent method         (UN-Habitat), DEGURBA  extent and population domain
    Population source           (GHS-POP), WorldPop  PGR

Each variant is compared with the baseline estimate of the same kind:
* model-label settings (tau_b, erosion) and the extent method change mapped areas, so they are
  compared with the baseline own *mapped* LCRPGR (the area-adjusted estimate comes from the
  reference labels, which these settings do not change);
* the population source is applied to the baseline area-adjusted LCRPGR.

Variant maps come from gee/01 (--variant, --ghsl-built-min / --erosion-px) then gee/06
(--variant). Missing variants are skipped with a warning.

Inputs: outputs/tables/Table7_sdg1131.csv, data/processed/population_extent*.csv,
        data/interim/maps/maps_{city}{variant}.tif, data/processed/extent_*.gpkg,
        data/processed/ghsl_{city}_{year}.tif
Output: outputs/tables/Table8_sensitivity.csv

Run:  python src/11_sensitivity.py
"""

from __future__ import annotations

import logging
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from rasterio import features

LOG = logging.getLogger("sensitivity")

T0, T1 = 2017, 2023
INTERVAL_Y = T1 - T0
NODATA = 255
PIXEL_KM2 = 1e-4
MODEL_VARIANTS = {"_tau040": ("GHSL threshold", "0.40"), "_tau060": ("GHSL threshold", "0.60"),
                  "_ero0": ("Erosion", "0 px")}
GHSL_THRESHOLDS_PCT = {"0.40": 40, "0.60": 60}

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
PROCESSED = ROOT / "data" / "processed"
MAPS = ROOT / "data" / "interim" / "maps"


def lcrpgr(urb0: float, urb1: float, pop0: float, pop1: float) -> float:
    """LCRPGR from areas and populations (equations 10 to 12)."""
    return float(np.log(urb1 / urb0) / np.log(pop1 / pop0))


def side_of_one(value: float) -> str:
    """Interpretation side for flip detection."""
    return "above 1" if value > 1 else "below 1"


def extent_mask(city: str, tag: str, shape: tuple[int, int], transform, crs) -> np.ndarray:
    """Raster mask of an extent polygon ('' own-model union, 'degurba_' urban centre)."""
    path = PROCESSED / f"extent_{tag}{city}_union.gpkg"
    if not path.exists():
        path = PROCESSED / f"extent_{tag}{city}.gpkg"
    ext = gpd.read_file(path).to_crs(crs)
    return features.geometry_mask(ext.geometry, out_shape=shape, transform=transform,
                                  invert=True)


def band_area(path: Path, band_name: str, city: str, tag: str = "",
              min_value: int = 1) -> float:
    """Area (km²) of cells >= min_value (and not NODATA) of one band inside an extent."""
    with rasterio.open(path) as src:
        names = list(src.descriptions)
        idx = names.index(band_name) + 1 if band_name in names else 1
        a = src.read(idx)
        mask = extent_mask(city, tag, a.shape, src.transform, src.crs)
    return float(((a >= min_value) & (a != NODATA) & mask).sum() * PIXEL_KM2)


def population(city: str, suffix: str = "") -> tuple[float, float]:
    """Population in the extent for 2017 and 2023 from a population_extent file."""
    p = pd.read_csv(PROCESSED / f"population_extent{suffix}.csv", encoding="utf-8")
    p = p[p["city"] == city].set_index("year")["pop_extent"]
    return float(p[T0]), float(p[T1])


def city_rows(city: str, t7: pd.DataFrame) -> list[dict]:
    """Sensitivity rows for one city."""
    rows = []
    base = t7[t7["city"] == city].set_index(["source", "estimate"])
    own_mapped = float(base.loc[("own", "mapped"), "LCRPGR"])
    own_adj = float(base.loc[("own", "area-adjusted"), "LCRPGR"])
    ghsl_mapped = float(base.loc[("ghsl", "mapped"), "LCRPGR"])
    pop0, pop1 = population(city)

    def add(setting: str, value: str, compared: str, base_val: float, new: float) -> None:
        rows.append({"city": city, "setting": f"{setting} = {value}", "compared_with": compared,
                     "baseline_lcrpgr": base_val, "lcrpgr": new,
                     "delta_lcrpgr": new - base_val,
                     "flips": side_of_one(new) != side_of_one(base_val)})

    for variant, (setting, value) in MODEL_VARIANTS.items():
        path = MAPS / f"maps_{city}{variant}.tif"
        if not path.exists():
            LOG.warning("%s: variant %s missing, skipped", city, variant)
            continue
        u0, u1 = (band_area(path, f"built_{y}", city) for y in (T0, T1))
        add(setting, value, "own mapped", own_mapped, lcrpgr(u0, u1, pop0, pop1))
    for value, pct in GHSL_THRESHOLDS_PCT.items():
        u0, u1 = (band_area(PROCESSED / f"ghsl_{city}_{y}.tif", "", city, min_value=pct)
                  for y in (T0, T1))
        add("GHSL threshold (GHSL map)", value, "GHSL mapped", ghsl_mapped,
            lcrpgr(u0, u1, pop0, pop1))
    try:
        d0, d1 = population(city, "_ghspop_degurba")
        u0, u1 = (band_area(PROCESSED / f"builtup_{city}_{y}.tif", "", city, "degurba_")
                  for y in (T0, T1))
        add("Urban extent", "GHSL Degree of Urbanisation", "own mapped", own_mapped,
            lcrpgr(u0, u1, d0, d1))
    except FileNotFoundError:
        LOG.warning("%s: Degree of Urbanisation population missing, skipped", city)
    try:
        w0, w1 = population(city, "_worldpop_model")
        lcr = own_adj * np.log(pop1 / pop0)  # LCR * y is unchanged; only PGR changes
        add("Population", "WorldPop", "own area-adjusted", own_adj,
            float(lcr / np.log(w1 / w0)))
    except FileNotFoundError:
        LOG.warning("%s: WorldPop population missing, skipped", city)
    return rows


def main() -> None:
    """Write Table 8."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    t7 = pd.read_csv(TABLES / "Table7_sdg1131.csv", encoding="utf-8")
    rows = [r for city in t7["city"].unique() for r in city_rows(city, t7)]
    table = pd.DataFrame(rows)
    table.to_csv(TABLES / "Table8_sensitivity.csv", index=False, encoding="utf-8")
    LOG.info("Table 8:\n%s", table.round(3).to_string(index=False))
    flips = table[table["flips"]]
    LOG.info("Interpretation flips (PCD 10 done check): %s",
             flips[["city", "setting"]].values.tolist() or "none")


if __name__ == "__main__":
    main()
