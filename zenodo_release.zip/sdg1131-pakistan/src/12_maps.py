"""Phase 11, Step 11.3: paper maps (PRD section 6). Maps whose inputs are missing are skipped.

    Fig3_agreement_2020    5 city tiles + key tile, number of products calling built (1-3)
    Fig6_change_2017_2023  5 city tiles + key tile, own-model change classes
    Fig7_lahore_change     large map of Lahore change + key card with locator
    FigS1_extents          5 city tiles + key tile, study extent 2017 and added by 2023
    FigS2_validation       5 city tiles + key tile, validation points (not in the paper)

Design: light, print-friendly figures with no empty space. Every tile is filled to its edges by a
soft greyscale Sentinel-2 composite, with thematic classes on top, so "non-built" is real imagery
instead of a blank area. Outside the circular working area the imagery fades towards white:
nothing is mapped there, and the legend says so. Each tile has a scale bar and north arrow; the
CRS and sources are in the footer. Classes, colours and extent rules are identical across tiles.
Categorical rasters are reduced for display with the modal value of each block (Resampling.mode),
never by smoothing.
Fig 1 (study area) and Fig 8 (zoom sites) are in src/12b_maps_s2.py.

Run:  python src/12_maps.py               (all available)
      python src/12_maps.py Fig6 Fig7
"""

from __future__ import annotations

import argparse
import importlib.util
import logging
import sys
import textwrap
from functools import lru_cache
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import geopandas as gpd  # noqa: E402
import matplotlib.patheffects as pe  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import rasterio  # noqa: E402
from matplotlib.colors import to_rgb  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402
from rasterio.enums import Resampling  # noqa: E402
from rasterio.windows import from_bounds  # noqa: E402
from shapely.geometry import Polygon  # noqa: E402

LOG = logging.getLogger("maps")

ROOT = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location("plot_style", ROOT / "src" / "plot_style.py")
ps = importlib.util.module_from_spec(_spec)
sys.modules["plot_style"] = ps
_spec.loader.exec_module(ps)
PROCESSED = ROOT / "data" / "processed"
AGREEMENT = ROOT / "data" / "interim" / "agreement"
S2_DIR = ROOT / "data" / "interim" / "s2"
PAKISTAN_SHP = ROOT / "data" / "Pakistan" / "Pakistan.shp"  # PIPS map, province level
VALIDATION = ROOT / "data" / "raw" / "validation" / "validation_points.csv"
OUT_DIR = ROOT / "outputs" / "maps"
NODATA = 255
ALBERS = "ESRI:102028"
DISPLAY_PX = 1300  # max raster side for a tile at 600 dpi (mode-reduced)
ZOOM_PX = 2800  # max raster side for the Lahore map
OUTSIDE_FADE = 0.65  # blend towards white outside the working area
TILE_MARGIN_CM, TILE_GAP_CM = 0.22, 0.1
HEADER_CM, FOOTER_CM = 1.1, 0.95
FOOTER_WRAP = 185  # characters per footer line at 5.3 pt across 17 cm
TILE_LINE_WIDTH = 0.55
LOCATOR_FILL = "#C9D2E3"
OUTLINE_CLOSE_M = 2000  # closes gaps between province polygons when drawing the outline
YEAR_COLOURS = {2017: ps.CHANGE_COLOURS[1], 2023: ps.CHANGE_COLOURS[2]}
STRATUM_COLOURS = {"stable non-built": "#5B6478", "stable built": ps.CHANGE_COLOURS[1],
                   "new built": ps.CHANGE_COLOURS[2], "reversal": "#C2187A"}
BASE_NOTE = "Base: Sentinel-2 2023 dry-season composite, greyscale (contains modified Copernicus " \
            "Sentinel data [2023])."
CRS_NOTE = "UTM zone 42N (EPSG:32642): Karachi, Peshawar; zone 43N (EPSG:32643): other cities."
SOURCE_LINE = {
    "agreement": "Data: ESA WorldCover 2020 v100; Google Dynamic World V1 2020; "
                 "JRC GHS-BUILT-S R2023A 2020.",
    "change": "Data: own classification of AlphaEarth Foundations Satellite Embedding V1 "
              "(Google, Google DeepMind), 2017 and 2023.",
}


def _load(rel: str, name: str):
    path = ROOT / rel
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


me = _load("src/map_elements.py", "map_elements")
ue = _load("gee/02_urban_extent.py", "urban_extent")


def read_display(path: Path, band: int = 1, max_px: int = DISPLAY_PX,
                 bounds: tuple | None = None) -> tuple[np.ndarray, tuple, object]:
    """Read a categorical band reduced by block mode; returns array, extent, CRS.

    Args:
        path: Raster file.
        band: Band number.
        max_px: Largest side of the returned array.
        bounds: Optional window (left, bottom, right, top) in the raster CRS.
    """
    with rasterio.open(path) as src:
        win = from_bounds(*bounds, transform=src.transform) if bounds else None
        width, height = (win.width, win.height) if win else (src.width, src.height)
        factor = max(1, int(np.ceil(max(width, height) / max_px)))
        shape = (int(height // factor), int(width // factor))
        a = src.read(band, window=win, out_shape=shape, resampling=Resampling.mode)
        b = src.window_bounds(win) if win else src.bounds
        return a, (b[0], b[2], b[1], b[3]), src.crs


def aoi_mask_display(city: str, a: np.ndarray, extent: tuple, crs) -> np.ndarray:
    """Cells of a display grid inside the AOI circle."""
    left, right, bottom, top = extent
    transform = rasterio.transform.from_bounds(left, bottom, right, top, a.shape[1], a.shape[0])
    prof = {"height": a.shape[0], "width": a.shape[1], "transform": transform}
    return ue.centre_distance(prof, ue.CITIES[city]) <= ue.CITIES[city].radius_km * 1000


def class_overlay(a: np.ndarray, colours: dict[int, str], keep: np.ndarray) -> np.ndarray:
    """RGBA image of the listed classes; other codes and cells outside ``keep`` are transparent."""
    rgba = np.zeros((*a.shape, 4))
    for code, colour in colours.items():
        m = (a == code) & keep
        rgba[m, :3] = to_rgb(colour)
        rgba[m, 3] = 1.0
    return rgba


def basemap(ax, city: str) -> None:
    """Greyscale Sentinel-2 composite filling the tile; faded outside the working area."""
    with rasterio.open(S2_DIR / f"rgb_{city}_2023.tif") as src:
        rgb = np.moveaxis(src.read([1, 2, 3]), 0, -1).astype(float)
        b = src.bounds
    extent = (b.left, b.right, b.bottom, b.top)
    image = me.duotone(rgb)
    inside = aoi_mask_display(city, rgb[..., 0], extent, None)
    image[~inside] = image[~inside] * (1 - OUTSIDE_FADE) + OUTSIDE_FADE
    ax.imshow(image, extent=extent, interpolation="bilinear", zorder=0)


def working_area_circle(ax, city: str, crs, colour: str = ps.INK) -> None:
    """Thin dashed circle around the working area."""
    c = ue.CITIES[city]
    aoi = gpd.GeoSeries.from_xy([c.lon], [c.lat], crs="EPSG:4326").to_crs(crs)
    circle = aoi.buffer(c.radius_km * 1000, quad_segs=64).iloc[0].exterior
    ax.plot(*circle.xy, color=colour, lw=0.45, ls=(0, (3, 3)), alpha=0.75, zorder=3)


def tile_label(ax, text: str) -> None:
    """City name inside the tile, top left."""
    ax.text(0.03, 0.965, text, transform=ax.transAxes, ha="left", va="top", fontsize=8,
            fontweight="bold", color=ps.INK, zorder=6,
            path_effects=[pe.withStroke(linewidth=1.8, foreground=ps.PAGE)])


def furnish(ax, city: str, label: str | None = None, epsg: int | None = None) -> None:
    """Scale bar, north arrow, tile label and a thin frame for one UTM tile; no ticks."""
    me.add_scale_bar(ax, f"EPSG:{epsg or ue.CITIES[city].epsg}", on_image=True)
    me.add_north_arrow(ax)
    tile_label(ax, ps.CITY_LABELS[city] if label is None else label)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.grid(False)
    frame(ax)


def frame(ax) -> None:
    """Thin frame around a tile, so pale imagery keeps a clear edge on the white page."""
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.4)
        spine.set_color(ps.FRAME)


def outline(ax, path: Path, crs, **kw) -> None:
    """Draw a polygon file's boundary in the panel CRS."""
    if path.exists():
        gpd.read_file(path).to_crs(crs).boundary.plot(ax=ax, zorder=4, **kw)


def tile_figure(title: str, subtitle: str, rows: int = 2, cols: int = 3) -> tuple[plt.Figure, list]:
    """Figure with a header, a footer and square tiles that fill the full width."""
    width = 17.0
    tile = (width - 2 * TILE_MARGIN_CM - (cols - 1) * TILE_GAP_CM) / cols
    height = HEADER_CM + rows * tile + (rows - 1) * TILE_GAP_CM + FOOTER_CM
    fig = plt.figure(figsize=(width * ps.CM, height * ps.CM), facecolor=ps.PAGE)
    axes = []
    for r in range(rows):
        for c in range(cols):
            x = TILE_MARGIN_CM + c * (tile + TILE_GAP_CM)
            y = FOOTER_CM + (rows - 1 - r) * (tile + TILE_GAP_CM)
            axes.append(fig.add_axes([x / width, y / height, tile / width, tile / height]))
    header(fig, title, subtitle, height)
    return fig, axes


def header(fig, title: str, subtitle: str, height_cm: float) -> None:
    """Left-aligned title and subtitle at the top of a figure."""
    x = TILE_MARGIN_CM / 17.0
    fig.text(x, 1 - 0.14 / height_cm, title, fontsize=10.5, fontweight="bold", color=ps.INK,
             va="top")
    fig.text(x, 1 - 0.62 / height_cm, subtitle, fontsize=7, color=ps.MUTED, va="top")


def footer(fig, lines: list[str]) -> None:
    """Source and CRS notes in the footer of a figure."""
    wrapped = "\n".join(textwrap.fill(line, FOOTER_WRAP) for line in lines)
    fig.text(TILE_MARGIN_CM / 17.0, 0.008, wrapped, fontsize=5.3, color=ps.MUTED,
             va="bottom", linespacing=1.3)


@lru_cache(maxsize=1)
def pakistan_provinces() -> gpd.GeoDataFrame:
    """PIPS province polygons in Asia South Albers (invalid rings repaired)."""
    provinces = gpd.read_file(PAKISTAN_SHP)
    return provinces.assign(geometry=provinces.make_valid()).to_crs(ALBERS)


def pakistan_outline() -> gpd.GeoDataFrame:
    """PIPS country outline in Asia South Albers, for drawing.

    The province polygons do not meet exactly, so the dissolved outline has slivers and holes
    along internal borders. They are closed here for display only; no analysis uses this shape.
    """
    union = pakistan_provinces().union_all()
    closed = union.buffer(OUTLINE_CLOSE_M).buffer(-OUTLINE_CLOSE_M)
    parts = closed.geoms if closed.geom_type == "MultiPolygon" else [closed]
    return gpd.GeoDataFrame(geometry=[Polygon(p.exterior) for p in parts], crs=ALBERS)


def locator(ax, cities: tuple[str, ...]) -> None:
    """Small Pakistan silhouette with the given cities marked."""
    pakistan_outline().plot(ax=ax, color=LOCATOR_FILL, edgecolor=ps.MUTED, lw=0.35)
    for city in cities:
        c = ue.CITIES[city]
        gpd.GeoSeries.from_xy([c.lon], [c.lat], crs="EPSG:4326").to_crs(ALBERS).plot(
            ax=ax, color=ps.CHANGE_COLOURS[2], markersize=7, edgecolor=ps.PAGE, linewidth=0.3,
            zorder=3)
    ax.set_axis_off()


def key_tile(ax, handles: list, title: str) -> None:
    """Sixth tile: legend above a locator, so no tile position is left empty."""
    ax.set_facecolor(ps.BAND)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.grid(False)
    frame(ax)
    legend = ax.legend(handles=handles, title=title, loc="upper left", fontsize=6.5,
                       title_fontsize=7.5, labelcolor=ps.INK, alignment="left",
                       borderaxespad=0.9, labelspacing=0.65, handlelength=1.6)
    legend.get_title().set_color(ps.INK)
    legend.get_title().set_fontweight("bold")
    inset = ax.inset_axes([0.2, 0.02, 0.62, 0.42])
    locator(inset, ps.CITY_ORDER)


def context_handles(colours: dict[int, str], labels: dict[int, str]) -> list:
    """Legend entries for the classes, the imagery base and the two outlines."""
    handles = [Patch(facecolor=ps.IMAGERY_SWATCH, label=labels[0])]
    handles += [Patch(facecolor=colours[k], label=labels[k]) for k in sorted(colours)]
    handles += [Patch(facecolor=ps.OUTSIDE_SWATCH, edgecolor=ps.FRAME, lw=0.3,
                      label="Outside working area (not mapped)"),
                Line2D([], [], color=ps.EXTENT_LINE, lw=0.8, label="Study extent 2017–2023")]
    return handles


def small_multiples(colours: dict[int, str], labels: dict[int, str], path_of, band: int,
                    source: str, legend_title: str, title: str, subtitle: str) -> plt.Figure:
    """Shared builder for the 5-city categorical maps."""
    fig, axes = tile_figure(title, subtitle)
    for ax, city in zip(axes, ps.CITY_ORDER, strict=False):
        a, extent, crs = read_display(path_of(city), band)
        keep = (a != NODATA) & aoi_mask_display(city, a, extent, crs)
        basemap(ax, city)
        ax.imshow(class_overlay(a, colours, keep), extent=extent, interpolation="nearest",
                  zorder=2)
        working_area_circle(ax, city, crs)
        outline(ax, PROCESSED / f"extent_{city}_union.gpkg", crs, color=ps.EXTENT_LINE,
                lw=TILE_LINE_WIDTH)
        ax.set_xlim(extent[0], extent[1])
        ax.set_ylim(extent[2], extent[3])
        furnish(ax, city)
    key_tile(axes[-1], context_handles(colours, labels), legend_title)
    footer(fig, [source + " " + BASE_NOTE, CRS_NOTE])
    return fig


def fig3_agreement() -> plt.Figure:
    """Number of products calling each pixel built-up, 2020."""
    agr = _load("gee/03_agreement_maps.py", "agreement_maps")

    def path_of(city: str) -> Path:
        p = AGREEMENT / f"pattern_{city}_2020.tif"
        out = AGREEMENT / f"count_{city}_2020.tif"
        if not out.exists() or out.stat().st_mtime < p.stat().st_mtime:
            with rasterio.open(p) as src:
                pat, prof = src.read(1), src.profile
            prof.update(nodata=NODATA)
            with rasterio.open(out, "w", **prof) as dst:
                dst.write(np.where(pat == NODATA, NODATA, agr.n_built(pat)).astype("uint8"), 1)
        return out

    labels = {0: "0 of 3 (imagery)", **{k: f"{k} of 3" for k in range(1, 4)}}
    return small_multiples(ps.AGREEMENT_COLOURS, labels, path_of, 1, SOURCE_LINE["agreement"],
                           "Products calling built-up",
                           "Agreement of three global built-up products, 2020",
                           "WorldCover, Dynamic World and GHSL: how many call each pixel built-up")


def fig6_change() -> plt.Figure:
    """Own-model built-up change 2017-2023."""
    return small_multiples(ps.CHANGE_COLOURS, ps.CHANGE_LABELS,
                           lambda c: PROCESSED / f"change_{c}_2017_2023.tif", 1,
                           SOURCE_LINE["change"], "Built-up change",
                           "Built-up change in five Pakistani cities, 2017–2023",
                           "Consensus-trained random forest on AlphaEarth Foundations embeddings")


def fig7_lahore() -> plt.Figure:
    """Lahore change map cropped to the study extent, with a key card and locator."""
    city = "lahore"
    width, height, card = 17.0, 12.4, 4.6
    gap = TILE_GAP_CM
    map_w, map_h = width - card - gap - 2 * TILE_MARGIN_CM, height - 2 * TILE_MARGIN_CM
    fig = plt.figure(figsize=(width * ps.CM, height * ps.CM), facecolor=ps.PAGE)
    ax = fig.add_axes([TILE_MARGIN_CM / width, TILE_MARGIN_CM / height, map_w / width,
                       map_h / height])
    with rasterio.open(PROCESSED / f"change_{city}_2017_2023.tif") as src:
        crs = src.crs
    ext = gpd.read_file(PROCESSED / f"extent_{city}_union.gpkg").to_crs(crs)
    xmin, ymin, xmax, ymax = ext.total_bounds
    cx, cy, half_h = (xmin + xmax) / 2, (ymin + ymax) / 2, (ymax - ymin) / 2 + 1500
    half_w = max(half_h * map_w / map_h, (xmax - xmin) / 2 + 1500)
    half_h = half_w * map_h / map_w
    bounds = (cx - half_w, cy - half_h, cx + half_w, cy + half_h)
    a, extent, _ = read_display(PROCESSED / f"change_{city}_2017_2023.tif", max_px=ZOOM_PX,
                                bounds=bounds)
    keep = (a != NODATA) & aoi_mask_display(city, a, extent, crs)
    basemap(ax, city)
    ax.imshow(class_overlay(a, ps.CHANGE_COLOURS, keep), extent=extent, interpolation="nearest",
              zorder=2)
    working_area_circle(ax, city, crs)
    outline(ax, PROCESSED / f"extent_{city}_union.gpkg", crs, color=ps.EXTENT_LINE, lw=0.7)
    ax.set_xlim(extent[0], extent[1])
    ax.set_ylim(extent[2], extent[3])
    furnish(ax, city, label="")

    side = fig.add_axes([(width - TILE_MARGIN_CM - card) / width, TILE_MARGIN_CM / height,
                         card / width, map_h / height])
    side.set_facecolor(ps.BAND)
    side.set_xticks([])
    side.set_yticks([])
    side.grid(False)
    frame(side)
    side.text(0.07, 0.975, "Built-up change\nin Lahore,\n2017–2023", transform=side.transAxes,
              va="top", fontsize=11, fontweight="bold", color=ps.INK, linespacing=1.15)
    legend = side.legend(handles=context_handles(ps.CHANGE_COLOURS, ps.CHANGE_LABELS),
                         loc="upper left", bbox_to_anchor=(0.03, 0.8), fontsize=6.2,
                         labelcolor=ps.INK, labelspacing=0.75, handlelength=1.6)
    legend.set_zorder(5)
    locator(side.inset_axes([0.14, 0.27, 0.72, 0.3]), (city,))
    note = " ".join([SOURCE_LINE["change"], BASE_NOTE, me.UTM_NOTES[32643] + ".",
                     "Locator: " + me.ALBERS_NOTE + "."])
    side.text(0.07, 0.02, textwrap.fill(note, 46), transform=side.transAxes, va="bottom",
              fontsize=5.2, color=ps.MUTED, linespacing=1.3)
    return fig


def figs1_extents() -> plt.Figure:
    """Study extent 2017 and the area added by 2023, per city (own model)."""
    fig, axes = tile_figure("Urban extents, 2017 and 2023",
                            "UN-Habitat built-up density method on the own-model maps")
    for ax, city in zip(axes, ps.CITY_ORDER, strict=False):
        c = ue.CITIES[city]
        crs = f"EPSG:{c.epsg}"
        with rasterio.open(PROCESSED / f"change_{city}_2017_2023.tif") as src:
            b = src.bounds
        basemap(ax, city)
        for year in (2023, 2017):  # 2017 drawn on top, so what stays visible was added
            gpd.read_file(PROCESSED / f"extent_{city}_{year}.gpkg").to_crs(crs).plot(
                ax=ax, color=YEAR_COLOURS[year], linewidth=0, zorder=2)
        working_area_circle(ax, city, crs)
        ax.set_xlim(b.left, b.right)
        ax.set_ylim(b.bottom, b.top)
        furnish(ax, city)
    key_tile(axes[-1], [
        Patch(facecolor=YEAR_COLOURS[2017], label="Extent 2017"),
        Patch(facecolor=YEAR_COLOURS[2023], label="Added by 2023"),
        Patch(facecolor=ps.IMAGERY_SWATCH, label="Rest of working area (imagery)"),
        Patch(facecolor=ps.OUTSIDE_SWATCH, edgecolor=ps.FRAME, lw=0.3,
              label="Outside working area (not mapped)")],
        "Urban extent")
    footer(fig, [SOURCE_LINE["change"] + " " + BASE_NOTE, CRS_NOTE])
    return fig


def figs2_validation() -> plt.Figure:
    """Validation points by stratum (main sample only)."""
    pts = pd.read_csv(VALIDATION, encoding="utf-8")
    pts = pts[~pts["reserve"]]
    fig, axes = tile_figure("Validation sample", "Points by stratum of the own change map")
    for ax, city in zip(axes, ps.CITY_ORDER, strict=False):
        crs = f"EPSG:{ue.CITIES[city].epsg}"
        with rasterio.open(PROCESSED / f"change_{city}_2017_2023.tif") as src:
            b = src.bounds
        basemap(ax, city)
        outline(ax, PROCESSED / f"extent_{city}_union.gpkg", crs, color=ps.EXTENT_LINE,
                lw=TILE_LINE_WIDTH)
        p = pts[pts["city"] == city]
        for stratum, colour in STRATUM_COLOURS.items():
            q = p[p["stratum"] == stratum]
            ax.scatter(q["x"], q["y"], s=3, color=colour, linewidths=0, zorder=5)
        ax.set_xlim(b.left, b.right)
        ax.set_ylim(b.bottom, b.top)
        furnish(ax, city)
    key_tile(axes[-1], [Patch(color=c, label=s) for s, c in STRATUM_COLOURS.items()],
             "Stratum")
    footer(fig, [BASE_NOTE, CRS_NOTE])
    return fig


MAPS = {
    "Fig3": ("Fig3_agreement_2020", fig3_agreement),
    "Fig6": ("Fig6_change_2017_2023", fig6_change),
    "Fig7": ("Fig7_lahore_change", fig7_lahore),
    "FigS1": ("FigS1_extents", figs1_extents),
    "FigS2": ("FigS2_validation", figs2_validation),
}


def main() -> None:
    """Render the requested (default: all) maps; skip those without inputs."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("maps", nargs="*", choices=[*MAPS, []], default=[])
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("fontTools").setLevel(logging.WARNING)
    ps.apply_style()
    for key in args.maps or list(MAPS):
        name, func = MAPS[key]
        try:
            fig = func()
        except (FileNotFoundError, rasterio.errors.RasterioIOError) as e:
            LOG.warning("%s skipped: input missing (%s)", name, e)
            continue
        paths = ps.save(fig, OUT_DIR, name, tight=False)
        plt.close(fig)
        LOG.info("Wrote %s", ", ".join(p.name for p in paths))


if __name__ == "__main__":
    main()
