"""Phase 11, Step 11.3: maps on Sentinel-2 true colour (Fig 1 study area, Fig 8 zoom sites).

Inputs come from gee/12_s2_rgb.py (data/interim/s2/). Sentinel-2 only: never Google Earth or
Esri imagery (CLAUDE.md). Same light design as src/12_maps.py.

    Fig1_study_area   (a) Pakistan in Asia South Albers with provinces and city locations;
                      (b-f) each working area on a 2023 dry-season Sentinel-2 composite with
                      the study extent, in the city's UTM zone
    Fig8_zoom_sites   3 sites x 4 columns: Sentinel-2 2017, Sentinel-2 2023, own-model change,
                      Dynamic World change (same 3 km window, same change classes). The two
                      true-colour dates of a site share one stretch, so the treatment cannot
                      create or hide change.

Run:  python src/12b_maps_s2.py
"""

from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import geopandas as gpd  # noqa: E402
import matplotlib.patheffects as pe  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import rasterio  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402
from rasterio.windows import from_bounds  # noqa: E402

LOG = logging.getLogger("maps_s2")

ROOT = Path(__file__).resolve().parents[1]
S2_DIR = ROOT / "data" / "interim" / "s2"
PROCESSED = ROOT / "data" / "processed"
OUT_DIR = ROOT / "outputs" / "maps"
ALBERS = "ESRI:102028"
SITE_KM = 3
LABEL_OFFSETS = {"karachi": (6, 3), "lahore": (6, -3), "faisalabad": (-14, -11),
                 "peshawar": (-40, 3), "rawalpindi": (-12, 7)}  # points; avoid overlaps
NODATA = 255
ROW_LABEL_CM, SITE_GAP_CM = 0.62, 0.08
SITE_HEADER_CM, SITE_LEGEND_CM, SITE_FOOTER_CM = 1.5, 0.55, 0.42
BOUNDARY_NOTE = ("Boundaries: Pakistan Institute for Parliamentary Services (PIPS) map, shown for "
                 "location only; they do not imply any judgement on the legal status of "
                 "territories.")


def _load(rel: str, name: str):
    path = ROOT / rel
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


ps = _load("src/plot_style.py", "plot_style")
me = _load("src/map_elements.py", "map_elements")
maps = _load("src/12_maps.py", "maps")
ue = maps.ue
chg = _load("src/06_change_maps.py", "change_maps")


def read_rgb(path: Path) -> tuple[np.ndarray, tuple]:
    """RGB GeoTIFF as an (H, W, 3) array and its plotting extent."""
    with rasterio.open(path) as src:
        b = src.bounds
        return np.moveaxis(src.read([1, 2, 3]), 0, -1), (b.left, b.right, b.bottom, b.top)


def fig1_study_area() -> plt.Figure:
    """Overview of Pakistan plus five city tiles on Sentinel-2 true colour."""
    fig, axes = maps.tile_figure("Study area", "Five major Pakistani cities: working areas and "
                                 "study extents on Sentinel-2 true colour, 2023 dry season")
    ax0 = axes[0]
    ax0.set_facecolor(ps.BAND)
    provinces = maps.pakistan_provinces()
    provinces.plot(ax=ax0, color=maps.LOCATOR_FILL, edgecolor=ps.PAGE, lw=0.45)
    maps.pakistan_outline().boundary.plot(ax=ax0, color=ps.INK, lw=0.6)
    for city in ps.CITY_ORDER:
        c = ue.CITIES[city]
        pt = gpd.GeoSeries.from_xy([c.lon], [c.lat], crs="EPSG:4326").to_crs(ALBERS)
        ax0.plot(pt.x, pt.y, "o", color=ps.CHANGE_COLOURS[2], ms=3.8, mec=ps.PAGE, mew=0.4)
        ax0.annotate(ps.CITY_LABELS[city].split("–")[0], (pt.x.iloc[0], pt.y.iloc[0]),
                     xytext=LABEL_OFFSETS[city], textcoords="offset points", fontsize=6,
                     color=ps.INK, path_effects=[pe.withStroke(linewidth=1.2,
                                                                   foreground=ps.PAGE)])
    x0, y0, x1, y1 = provinces.total_bounds
    half = max(x1 - x0, y1 - y0) / 2 * 1.08
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    ax0.set_xlim(cx - half, cx + half)
    ax0.set_ylim(cy - half, cy + half)
    ax0.set_aspect("equal")
    me.add_scale_bar(ax0, ALBERS, on_image=True)
    me.add_north_arrow(ax0, x=0.08, y=0.8)
    maps.tile_label(ax0, "(a) Pakistan")
    ax0.set_xticks([])
    ax0.set_yticks([])
    ax0.set_xlabel("")
    ax0.set_ylabel("")
    ax0.grid(False)
    maps.frame(ax0)
    for i, city in enumerate(ps.CITY_ORDER, start=1):
        ax = axes[i]
        rgb, extent = read_rgb(S2_DIR / f"rgb_{city}_2023.tif")
        ax.imshow(me.vivid(rgb), extent=extent, interpolation="bilinear")
        crs = f"EPSG:{ue.CITIES[city].epsg}"
        maps.working_area_circle(ax, city, crs, colour=ps.EXTENT_LINE_TRUE_COLOUR)
        maps.outline(ax, PROCESSED / f"extent_{city}_union.gpkg", crs,
                     color=ps.EXTENT_LINE_TRUE_COLOUR, lw=0.8)
        ax.set_xlim(extent[0], extent[1])
        ax.set_ylim(extent[2], extent[3])
        maps.furnish(ax, city, label=f"({'abcdef'[i]}) {ps.CITY_LABELS[city]}")
    fig.legend(handles=[
        Line2D([], [], color=ps.EXTENT_LINE_TRUE_COLOUR, lw=1.2, label="Study extent 2017–2023"),
        Line2D([], [], color=ps.EXTENT_LINE_TRUE_COLOUR, lw=0.8, ls=(0, (3, 3)),
               label="Working area")],
        loc="upper right", bbox_to_anchor=(0.992, 0.998), fontsize=6.5, ncol=2,
        labelcolor=ps.INK)
    maps.footer(fig, ["Contains modified Copernicus Sentinel data [2023] (dry-season median, true "
                      "colour). " + BOUNDARY_NOTE,
                      f"(a) {me.ALBERS_NOTE}. (b–f) {maps.CRS_NOTE}"])
    return fig


def change_window(path_or_pair, bounds) -> tuple[np.ndarray, tuple]:
    """Change classes in a window: from a change raster, or from a (2017, 2023) raster pair."""
    if isinstance(path_or_pair, tuple):
        arrays = []
        for p in path_or_pair:
            with rasterio.open(p) as src:
                arrays.append(src.read(1, window=from_bounds(*bounds, transform=src.transform)))
        out = chg.change_map(*arrays)
    else:
        with rasterio.open(path_or_pair) as src:
            out = src.read(1, window=from_bounds(*bounds, transform=src.transform))
    left, bottom, right, top = bounds
    return out, (left, right, bottom, top)


def fig8_zoom_sites() -> plt.Figure:
    """Sites (rows) x Sentinel-2 2017, 2023, own change, Dynamic World change (columns)."""
    sites = pd.read_csv(S2_DIR / "sites.csv", encoding="utf-8")
    rows, width = len(sites), 17.0
    tile = (width - ROW_LABEL_CM - 2 * maps.TILE_MARGIN_CM - 3 * SITE_GAP_CM) / 4
    height = (SITE_HEADER_CM + rows * tile + (rows - 1) * SITE_GAP_CM + SITE_LEGEND_CM
              + SITE_FOOTER_CM)
    fig = plt.figure(figsize=(width * ps.CM, height * ps.CM), facecolor=ps.PAGE)
    maps.header(fig, "Three sites of mapped growth, 2017–2023",
                "Sentinel-2 true colour beside the own-model and Dynamic World change maps",
                height)
    cols = ["Sentinel-2, 2017", "Sentinel-2, 2023", "Own model change", "Dynamic World change"]
    half = SITE_KM * 1000 / 2
    for r, s in enumerate(sites.itertuples()):
        bounds = (s.x - half, s.y - half, s.x + half, s.y + half)
        y_cm = height - SITE_HEADER_CM - (r + 1) * tile - r * SITE_GAP_CM
        axes = [fig.add_axes([(maps.TILE_MARGIN_CM + ROW_LABEL_CM + c * (tile + SITE_GAP_CM))
                              / width, y_cm / height, tile / width, tile / height])
                for c in range(4)]
        rgb17, extent = read_rgb(S2_DIR / f"site_{s.site}_2017.tif")
        rgb23, _ = read_rgb(S2_DIR / f"site_{s.site}_2023.tif")
        limits = me.channel_limits(rgb17, rgb23)
        axes[0].imshow(me.vivid(rgb17, limits), extent=extent, interpolation="nearest")
        axes[1].imshow(me.vivid(rgb23, limits), extent=extent, interpolation="nearest")
        own, ext = change_window(PROCESSED / f"change_{s.city}_2017_2023.tif", bounds)
        dw, _ = change_window((PROCESSED / f"dw_{s.city}_2017.tif",
                               PROCESSED / f"dw_{s.city}_2023.tif"), bounds)
        for ax, a in ((axes[2], own), (axes[3], dw)):
            ax.imshow(me.duotone(rgb23), extent=extent, interpolation="bilinear", zorder=0)
            ax.imshow(maps.class_overlay(a, ps.CHANGE_COLOURS, a != NODATA), extent=ext,
                      interpolation="nearest", zorder=2)
        for c, ax in enumerate(axes):
            ax.set_xlim(bounds[0], bounds[2])
            ax.set_ylim(bounds[1], bounds[3])
            ax.set_xticks([])
            ax.set_yticks([])
            ax.grid(False)
            maps.frame(ax)
            if r == 0:
                ax.set_title(cols[c], fontsize=7.5, fontweight="bold", color=ps.INK, pad=3,
                             loc="left")
        me.add_scale_bar(axes[0], f"EPSG:{s.epsg}", on_image=True)
        me.add_north_arrow(axes[0], x=0.92, y=0.94)
        fig.text((maps.TILE_MARGIN_CM + ROW_LABEL_CM / 2 - 0.05) / width,
                 (y_cm + tile / 2) / height,
                 f"{ps.CITY_LABELS[s.city]}\n{s.lat:.3f}° N, {s.lon:.3f}° E", rotation=90,
                 ha="center", va="center", fontsize=6.3, color=ps.INK, linespacing=1.25)
    handles = [Patch(facecolor=ps.IMAGERY_SWATCH, label=ps.CHANGE_LABELS[0])]
    handles += [Patch(facecolor=ps.CHANGE_COLOURS[k], label=ps.CHANGE_LABELS[k])
                for k in ps.CHANGE_COLOURS]
    fig.legend(handles=handles, loc="center left",
               bbox_to_anchor=(maps.TILE_MARGIN_CM / width,
                               (SITE_FOOTER_CM + SITE_LEGEND_CM / 2) / height),
               ncol=4, fontsize=6.5, labelcolor=ps.INK, borderaxespad=0, borderpad=0,
               handlelength=1.6)
    fig.text(maps.TILE_MARGIN_CM / width, 0.008, "Contains modified Copernicus Sentinel data "
             f"[2017, 2023]. Sites: {SITE_KM} km window inside the study extent with the largest "
             "own-model new built-up share (rule fixed in advance). UTM zones as in Figure 1.",
             fontsize=5.3, color=ps.MUTED, va="bottom")
    return fig


def main() -> None:
    """Render Fig 1 and Fig 8."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("fontTools").setLevel(logging.WARNING)
    ps.apply_style()
    for name, func in (("Fig1_study_area", fig1_study_area), ("Fig8_zoom_sites", fig8_zoom_sites)):
        fig = func()
        paths = ps.save(fig, OUT_DIR, name, tight=False)
        plt.close(fig)
        LOG.info("Wrote %s", ", ".join(p.name for p in paths))


if __name__ == "__main__":
    main()
