"""Phase 11, Step 11.4: charts (PRD section 8). Figures whose inputs do not exist yet are skipped.

    Fig2_workflow             method diagram
    Fig4_agreement_bars       % of study extent by number of products calling built (Table 3)
    Fig5_model_f1             F1 (built) per model per city, mean +/- 95% interval over folds
    Fig9_lcrpgr_forest        LCRPGR per city and source on a log axis, sensitivity range (not CI)
    Fig10_radial_profile      built-up share vs distance from centre (1 km rings), gain and loss
    Fig11_sensitivity_heatmap change in LCRPGR per source x setting and city (Table 8)
    Fig12_lcr_pgr             land consumption rate per source against population growth rate
    FigS3_umap                UMAP of embedding samples by consensus stratum
    FigS5_importance          permutation importance of the Sentinel-2 baseline RF

All charts: shared design system (src/plot_style.py), no in-image titles, axis labels with units,
uncertainty where it exists, colour + marker shape per source, 600 dpi PNG + PDF.

Run:  python src/13_charts.py                 (all available)
      python src/13_charts.py Fig4 FigS3
"""

from __future__ import annotations

import argparse
import importlib.util
import logging
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import rasterio  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap, SymLogNorm  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import FancyBboxPatch, Patch  # noqa: E402

LOG = logging.getLogger("charts")

SEED = 42
ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
OUT_DIR = ROOT / "outputs" / "figures"
SAMPLES = ROOT / "data" / "interim" / "samples"
PROCESSED = ROOT / "data" / "processed"
RING_KM = 1.0
UMAP_N = 5000
Z_95 = 1.96
STRATUM_STYLE = {  # consensus sampling strata (gee/01_consensus_labels.py)
    1: ("Built", "#3D5AFE"), 0: ("Non-built land", "#E05A00"), 2: ("Water", "#0B9385"),
}
WORKFLOW_RAMP = ("#3D5AFE", "#6F45E8", "#A83CC9", "#D81B7A", "#E8433F", "#E66C08")  # step order
HEATMAP_COLOURS = ("#2A45C8", "#7F97F5", "#F3F4F8", "#F5A26B", "#C94A00")
HEATMAP_LINTHRESH = 0.1
LUMA = (0.299, 0.587, 0.114)
SEGMENT_LABEL_MIN_PCT = 4
SPRAWL_TINT = "#FDEFE6"
FOREST_X_LIMITS = (0.04, 5.0)
FOREST_X_TICKS = (0.05, 0.1, 0.25, 0.5, 1, 2, 4)
FOREST_CITY_GAP = 0.8
FILL_ALPHA = 0.75


def _load(rel: str, name: str):
    path = ROOT / rel
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


ps = _load("src/plot_style.py", "plot_style")


def fig2_workflow() -> plt.Figure:
    """Workflow: data -> consensus labels -> model -> maps -> comparison -> indicator."""
    steps = [
        ("Inputs", "AlphaEarth embeddings;\nWorldCover, Dynamic World,\n"
                   "GHSL; Sentinel-2;\ncensus; GHS-POP"),
        ("Consensus labels (2020)", "All three products agree;\n1 px erosion;\n"
                                    "2,500 + 2,500 samples per city"),
        ("Model", "Random forest on embeddings;\nspatial block CV against a\n"
                  "Sentinel-2 baseline"),
        ("Maps 2017 and 2023", "Built-up and change maps;\nurban extent (UN-Habitat\n"
                               "built-up density)"),
        ("Product comparison", "2023 map agreement with\nDynamic World and GHSL;\n"
                               "mapped built-up areas"),
        ("SDG 11.3.1", "LCR, PGR, LCRPGR per city\nand data source;\nsensitivity ranges"),
    ]
    n_cols, box_w, box_h = 3, 0.9, 0.8
    fig = plt.figure(figsize=(ps.WIDTH_DOUBLE, 6.7 * ps.CM))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, n_cols)
    ax.set_ylim(0, 2)
    ax.axis("off")
    arrow = {"arrowstyle": "-|>", "color": ps.MUTED, "lw": 0.9, "shrinkA": 0, "shrinkB": 0}
    for i, (head, text) in enumerate(steps):
        col, row = i % n_cols, 1 - i // n_cols  # row 1 = top
        x0, y0 = col + (1 - box_w) / 2, row + (1 - box_h) / 2
        ax.add_patch(FancyBboxPatch((x0, y0), box_w, box_h,
                                    boxstyle="round,pad=0,rounding_size=0.05",
                                    facecolor=ps.BAND, edgecolor="none"))
        ax.text(x0 + 0.085, y0 + box_h - 0.16, str(i + 1), ha="center", va="center", fontsize=8,
                fontweight="bold", color="white",
                bbox={"boxstyle": "circle,pad=0.35", "facecolor": WORKFLOW_RAMP[i],
                      "edgecolor": "none"})
        ax.text(x0 + 0.17, y0 + box_h - 0.16, head, ha="left", va="center", fontsize=8.5,
                fontweight="bold", color=ps.INK)
        ax.text(x0 + 0.05, y0 + box_h - 0.31, text, ha="left", va="top", fontsize=7.2,
                color=ps.MUTED, linespacing=1.35)
        if col < n_cols - 1:
            ax.annotate("", xy=(col + 1 + (1 - box_w) / 2, row + 0.5),
                        xytext=(x0 + box_w, row + 0.5), arrowprops=arrow)
    gap_y = 1.0  # step 3 (top right) -> step 4 (bottom left)
    ax.plot([2.5, 2.5, 0.5], [1 + (1 - box_h) / 2, gap_y, gap_y], color=ps.MUTED, lw=0.9)
    ax.annotate("", xy=(0.5, 1 - (1 - box_h) / 2), xytext=(0.5, gap_y), arrowprops=arrow)
    return fig


def fig4_agreement_bars() -> plt.Figure:
    """Stacked horizontal bars: % of the study extent by agreement class A(x)."""
    t = pd.read_csv(TABLES / "Table3_consensus_summary.csv", encoding="utf-8").set_index("city")
    cities = [c for c in ps.CITY_ORDER if c in t.index][::-1]
    colours = {0: ps.AGREEMENT_ZERO, **ps.AGREEMENT_COLOURS}
    fig, ax = plt.subplots(figsize=(ps.WIDTH_DOUBLE, 6 * ps.CM))
    left = np.zeros(len(cities))
    for k in range(4):
        vals = t.loc[cities, f"A{k}_pct"].to_numpy()
        ax.barh(range(len(cities)), vals, left=left, height=0.68, color=colours[k],
                edgecolor="white", linewidth=1.4, label=f"{k} of 3")
        for y, (lft, v) in enumerate(zip(left, vals, strict=True)):
            if v >= SEGMENT_LABEL_MIN_PCT:
                ax.text(lft + v / 2, y, f"{v:.0f}%", ha="center", va="center", fontsize=7.5,
                        fontweight="bold", color="white" if k == 3 else ps.INK)
        left += vals
    ax.set_yticks(range(len(cities)), [ps.CITY_LABELS[c] for c in cities])
    ax.set_xlim(0, 100)
    ax.set_xlabel("Share of study extent (%)")
    ax.grid(False)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.legend(title="Products calling the pixel built-up, 2020", ncol=4, loc="lower left",
              bbox_to_anchor=(0, 1.0), borderaxespad=0.3, title_fontsize=7.5, alignment="left",
              handlelength=1.4, columnspacing=1.4)
    return fig


def fig5_model_f1() -> plt.Figure:
    """F1 (built) per model per city: mean +/- 1.96 SE over spatial CV folds."""
    t = pd.read_csv(TABLES / "cv_folds_per_city.csv", encoding="utf-8")
    models = ["RF-Embed", "GBT-Embed", "MLP-Embed", "RF-S2"]
    colours = {"RF-Embed": ps.PALETTE["own_model"], "GBT-Embed": ps.PALETTE["gbt"],
               "MLP-Embed": ps.PALETTE["mlp"], "RF-S2": ps.PALETTE["s2_rf"]}
    markers = {"RF-Embed": "o", "GBT-Embed": "s", "MLP-Embed": "^", "RF-S2": "D"}
    fig, ax = plt.subplots(figsize=(ps.WIDTH_DOUBLE, 6.4 * ps.CM))
    cities = [c for c in ps.CITY_ORDER if c in set(t["city"])]
    for i in range(0, len(cities), 2):
        ax.axvspan(i - 0.5, i + 0.5, color=ps.BAND, lw=0, zorder=0)
    for j, m in enumerate(models):
        g = t[t["model"] == m].groupby("city")["F1_built"]
        mean = g.mean().reindex(cities)
        half = (Z_95 * g.std(ddof=1) / np.sqrt(g.count())).reindex(cities)
        x = np.arange(len(cities)) + (j - 1.5) * 0.17
        ax.errorbar(x, mean, yerr=half, fmt=markers[m], color=colours[m], ms=5.5, lw=1.1,
                    capsize=0, mec="white", mew=0.5, label=m, zorder=3)
    ax.set_xticks(range(len(cities)), [ps.CITY_LABELS[c] for c in cities])
    ax.set_xlim(-0.5, len(cities) - 0.5)
    ax.set_ylabel("F1, built-up (%)\nspatial CV on consensus labels")
    ax.spines["left"].set_visible(False)
    handles = [Line2D([], [], marker=markers[m], ls="", color=colours[m], ms=5.5, label=m)
               for m in models]
    ax.legend(handles=handles, ncol=4, loc="lower left", bbox_to_anchor=(0, 1.0),
              borderaxespad=0.2, handletextpad=0.3, columnspacing=1.6)
    return fig


def fig9_lcrpgr_forest() -> plt.Figure:
    """Forest plot on a log axis: baseline LCRPGR per city and source, capsule = sensitivity range.

    LCRPGR is a ratio, so a log axis treats values above and below 1 alike. The capsules are
    ranges over methodological settings (Table 8), not confidence intervals.
    """
    t = pd.read_csv(TABLES / "Table7_sdg1131.csv", encoding="utf-8")
    sources = [s for s in ps.SOURCE_LABELS if s in set(t["source"])]
    cities = [c for c in ps.CITY_ORDER if c in set(t["city"])]
    fig, ax = plt.subplots(figsize=(ps.WIDTH_DOUBLE, 10.5 * ps.CM))
    ax.set_xscale("log")
    ax.axvspan(1, FOREST_X_LIMITS[1], color=SPRAWL_TINT, lw=0, zorder=0)
    half_gap = FOREST_CITY_GAP / 2
    y, ticks = 0.0, []
    for n, city in enumerate(cities):
        if n % 2 == 0:
            ax.axhspan(-(y + len(sources) - 1 + half_gap), -(y - half_gap), color=ps.INK,
                       alpha=0.03, lw=0, zorder=1)
        for src in sources:
            r = t[(t["city"] == city) & (t["source"] == src)].iloc[0]
            colour = ps.SOURCE_COLOURS[src]
            ax.plot([r["range_low"], r["range_high"]], [-y, -y], color=colour, lw=6, alpha=0.26,
                    solid_capstyle="round", zorder=2)
            ax.plot(r["LCRPGR"], -y, ms=6.5, zorder=3, **ps.source_marker(src))
            ax.text(1.012, -y, f"{r['LCRPGR']:.2f}", transform=ax.get_yaxis_transform(),
                    va="center", ha="left", fontsize=7.5, fontweight="bold", color=colour)
            y += 1
        ticks.append(-(y - (len(sources) + 1) / 2))
        y += FOREST_CITY_GAP
    ax.axvline(1, color=ps.INK, ls=(0, (4, 3)), lw=0.9, zorder=2)
    ax.set_xlim(*FOREST_X_LIMITS)
    ax.set_ylim(-(y - 1 - half_gap), 0.95)
    ax.set_yticks(ticks, [ps.CITY_LABELS[c] for c in cities], fontweight="bold")
    ax.set_xticks(FOREST_X_TICKS, [f"{v:g}" for v in FOREST_X_TICKS])
    ax.xaxis.set_minor_locator(plt.NullLocator())
    ax.set_xlabel("LCRPGR, 2017–2023 (ratio, log scale)")
    ax.grid(axis="x", color=ps.GRID, linewidth=0.6)
    ax.grid(axis="y", visible=False)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.text(0.95, 0.62, "Population grew faster", ha="right", va="center", fontsize=7,
            color=ps.MUTED)
    ax.text(1.05, 0.62, "Land consumed faster", ha="left", va="center", fontsize=7, color=ps.MUTED)
    labels = {**ps.SOURCE_LABELS, "ghsl": ps.GHSL_QUANTITY_LABEL}
    handles = [Line2D([], [], ms=6, label=labels[s], **ps.source_marker(s)) for s in sources]
    handles.append(Line2D([], [], color=ps.MUTED, lw=6, alpha=0.3, solid_capstyle="round",
                          label="Range over settings (not a CI)"))
    ax.legend(handles=handles, ncol=4, loc="lower left", bbox_to_anchor=(0, 1.0),
              borderaxespad=0.3, columnspacing=1.5)
    return fig


def radial_profile(built: np.ndarray, valid: np.ndarray, dist_m: np.ndarray,
                   ring_km: float = RING_KM) -> pd.DataFrame:
    """Built-up fraction of valid cells per distance ring."""
    ring = (dist_m // (ring_km * 1000)).astype(int)
    df = pd.DataFrame({"ring": ring[valid], "built": built[valid] == 1})
    out = df.groupby("ring")["built"].mean().rename("fraction").reset_index()
    out["distance_km"] = (out["ring"] + 0.5) * ring_km
    return out


def fig10_radial_profile() -> plt.Figure:
    """Built-up share vs distance from the centre, own maps 2017 and 2023 (map-based)."""
    ue = _load("gee/02_urban_extent.py", "urban_extent")
    cities = [c for c in ps.CITY_ORDER if (PROCESSED / f"builtup_{c}_2023.tif").exists()]
    fig, axes = plt.subplots(1, len(cities), figsize=(ps.WIDTH_DOUBLE, 5.8 * ps.CM), sharey=True,
                             squeeze=False)
    blue, gain, loss = ps.PALETTE["own_model"], ps.PALETTE["ghsl"], ps.PALETTE["dynamic_world"]
    for ax, city in zip(axes[0], cities, strict=True):
        profiles = {}
        for year in (2017, 2023):
            with rasterio.open(PROCESSED / f"builtup_{city}_{year}.tif") as src:
                a, profile = src.read(1), src.profile
            dist = ue.centre_distance(profile, ue.CITIES[city])
            profiles[year] = radial_profile(a, a != 255, dist).set_index("distance_km")["fraction"]
        both = pd.concat(profiles, axis=1).dropna()
        x, p17, p23 = both.index.to_numpy(), 100 * both[2017], 100 * both[2023]
        ax.fill_between(x, p17, p23, where=p23 >= p17, interpolate=True, color=gain,
                        alpha=FILL_ALPHA, lw=0)
        ax.fill_between(x, p17, p23, where=p23 < p17, interpolate=True, color=loss,
                        alpha=FILL_ALPHA, lw=0)
        ax.plot(x, p17, color=ps.INK, lw=0.8, ls=(0, (3, 2)))
        ax.plot(x, p23, color=blue, lw=1.5)
        ax.set_title(ps.CITY_LABELS[city].replace("–", "–\n"), fontsize=7.5, fontweight="bold",
                     loc="left")
        ax.spines["left"].set_visible(False)
        ax.set_ylim(0, 102)
    fig.supxlabel("Distance from city centre (km)", fontsize=8.5, y=-0.07)
    axes[0][0].set_ylabel("Built-up share of ring (%)")
    fig.legend(handles=[Line2D([], [], color=blue, lw=1.5, label="2023"),
                        Line2D([], [], color=ps.INK, lw=0.8, ls=(0, (3, 2)), label="2017"),
                        Patch(color=gain, alpha=FILL_ALPHA, label="Gain 2017–2023"),
                        Patch(color=loss, alpha=FILL_ALPHA, label="Loss 2017–2023")],
               ncol=4, loc="lower left", bbox_to_anchor=(0.06, 0.97))
    return fig


def fig11_sensitivity_heatmap() -> plt.Figure:
    """Change in LCRPGR vs baseline, grouped by source (rows) and city (columns).

    The colour scale is symmetric-log so that small changes stay visible next to Peshawar; every
    cell also prints its value. Cells that move LCRPGR across 1 are outlined.
    """
    t = pd.read_csv(TABLES / "Table8_sensitivity.csv", encoding="utf-8")
    groups = {"own": "Own model", "dw": "Dynamic World", "ghsl": ps.GHSL_QUANTITY_LABEL}
    cities = [c for c in ps.CITY_ORDER if c in set(t["city"])]
    counts = [t.loc[t["source"] == s, "setting"].nunique() for s in groups]
    lim = float(t["delta_lcrpgr"].abs().max())
    norm = SymLogNorm(linthresh=HEATMAP_LINTHRESH, linscale=0.6, vmin=-lim, vmax=lim)
    cmap = LinearSegmentedColormap.from_list("change", HEATMAP_COLOURS)
    fig = plt.figure(figsize=(ps.WIDTH_DOUBLE, (2.8 + 0.62 * sum(counts)) * ps.CM))
    grid = fig.add_gridspec(len(groups), 2, height_ratios=counts, width_ratios=[40, 1],
                            hspace=0.28, wspace=0.03)
    labels = [ps.CITY_LABELS[c].replace("–", "–\n") for c in cities]
    for n, (src, name) in enumerate(groups.items()):
        ax = fig.add_subplot(grid[n, 0])
        g = t[t["source"] == src]
        settings = list(dict.fromkeys(g["setting"]))
        delta = g.pivot_table(index="setting", columns="city",
                              values="delta_lcrpgr").loc[settings, cities].to_numpy()
        flips = g.pivot_table(index="setting", columns="city", values="flips",
                              aggfunc="any").loc[settings, cities].to_numpy()
        mesh = ax.pcolormesh(delta, cmap=cmap, norm=norm, edgecolors="white", linewidth=1.6)
        ax.invert_yaxis()
        for (i, j), v in np.ndenumerate(delta):
            shade = np.array(cmap(norm(v))[:3]) @ np.array(LUMA)
            label = "0.00" if abs(v) < 0.005 else f"{v:+.2f}".replace("-", "−")
            ax.text(j + 0.5, i + 0.5, label, ha="center", va="center", fontsize=7,
                    color="white" if shade < 0.5 else ps.INK)
            if bool(flips[i, j]):
                ax.add_patch(plt.Rectangle((j + 0.03, i + 0.05), 0.94, 0.9, fill=False,
                                           ec=ps.INK, lw=1.3))
        ax.set_yticks(np.arange(len(settings)) + 0.5, settings, fontsize=7.2)
        ax.set_title(name, loc="left", fontsize=8, fontweight="bold", pad=2)
        ax.grid(False)
        for spine in ax.spines.values():
            spine.set_visible(False)
        if n == len(groups) - 1:
            ax.set_xticks(np.arange(len(cities)) + 0.5, labels, fontsize=7.5)
        else:
            ax.set_xticks([])
    cax = fig.add_subplot(grid[:, 1])
    bar = fig.colorbar(mesh, cax=cax, ticks=[-1, -0.3, -0.1, 0, 0.1, 0.3, 1])
    bar.ax.set_yticklabels(["−1", "−0.3", "−0.1", "0", "+0.1", "+0.3", "+1"], fontsize=7)
    bar.ax.minorticks_off()
    bar.outline.set_visible(False)
    bar.set_label("Change in LCRPGR vs baseline (outlined: crosses 1)", fontsize=7.5)
    return fig


def fig12_lcr_pgr() -> plt.Figure:
    """LCR per source against PGR per city: the two parts of the ratio, shown separately."""
    t = pd.read_csv(TABLES / "Table7_sdg1131.csv", encoding="utf-8")
    sources = [s for s in ps.SOURCE_LABELS if s in set(t["source"])]
    cities = [c for c in ps.CITY_ORDER if c in set(t["city"])][::-1]
    fig, ax = plt.subplots(figsize=(ps.WIDTH_DOUBLE, 6.6 * ps.CM))
    for y, city in enumerate(cities):
        if y % 2 == 0:
            ax.axhspan(y - 0.5, y + 0.5, color=ps.BAND, lw=0, zorder=0)
        g = t[t["city"] == city].set_index("source")
        lcr = 100 * g["LCR"]
        ax.plot([lcr.min(), lcr.max()], [y, y], color=ps.RULE, lw=2.5, zorder=1,
                solid_capstyle="round")
        for src in sources:
            ax.plot(lcr[src], y, ms=6.5, zorder=3, **ps.source_marker(src))
        pgr = 100 * g["PGR"].iloc[0]
        ax.plot([pgr, pgr], [y - 0.32, y + 0.32], color=ps.INK, lw=2.2, zorder=2,
                solid_capstyle="butt")
    ax.set_yticks(range(len(cities)), [ps.CITY_LABELS[c] for c in cities], fontweight="bold")
    ax.set_ylim(-0.5, len(cities) - 0.5)
    ax.set_xlim(left=0)
    ax.set_xlabel("Rate, 2017–2023 (% per year)")
    ax.grid(axis="x", color=ps.GRID, linewidth=0.6)
    ax.grid(axis="y", visible=False)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    labels = {**ps.SOURCE_LABELS, "ghsl": ps.GHSL_QUANTITY_LABEL}
    handles = [Line2D([], [], ms=6, label=f"LCR, {labels[s]}", **ps.source_marker(s))
               for s in sources]
    handles.append(Line2D([], [], color=ps.INK, lw=2.2, label="PGR"))
    ax.legend(handles=handles, ncol=4, loc="lower left", bbox_to_anchor=(0, 1.0),
              borderaxespad=0.3, columnspacing=1.4)
    return fig


def figs3_umap() -> plt.Figure:
    """UMAP of a random subset of embedding samples, coloured by consensus stratum."""
    import umap

    frames = [pd.read_csv(p, encoding="utf-8") for p in sorted(SAMPLES.glob("samples_*_2020.csv"))]
    data = pd.concat(frames, ignore_index=True).sample(n=UMAP_N, random_state=SEED)
    emb = umap.UMAP(random_state=SEED).fit_transform(data[[f"A{i:02d}" for i in range(64)]])
    fig, ax = plt.subplots(figsize=(ps.WIDTH_SINGLE, ps.WIDTH_SINGLE))
    for code, (label, colour) in STRATUM_STYLE.items():
        m = data["stratum"].to_numpy() == code
        ax.scatter(emb[m, 0], emb[m, 1], s=2.5, color=colour, label=label, linewidths=0,
                   alpha=0.9)
    ax.set_xlabel("UMAP 1")
    ax.set_ylabel("UMAP 2")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_facecolor(ps.BAND)
    ax.grid(False)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.legend(markerscale=4, ncol=3, loc="lower left", bbox_to_anchor=(0, 1.0),
              borderaxespad=0.2, handletextpad=0.1, columnspacing=1.0)
    return fig


def figs5_importance() -> plt.Figure:
    """Permutation importance of the Sentinel-2 baseline RF on one spatial test fold."""
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.inspection import permutation_importance

    tm = _load("src/05_train_models.py", "train_models")
    data, _ = tm.load_samples(list(tm.CITIES))
    folds = tm.outer_folds(data["block"])
    train, test = folds != 0, folds == 0
    rf = RandomForestClassifier(n_estimators=tm.N_TREES, n_jobs=-1, random_state=SEED)
    rf.fit(data.loc[train, tm.S2_FEATURES], data.loc[train, tm.LABEL])
    imp = permutation_importance(rf, data.loc[test, tm.S2_FEATURES], data.loc[test, tm.LABEL],
                                 n_repeats=10, random_state=SEED, n_jobs=-1)
    order = np.argsort(imp.importances_mean)
    fig, ax = plt.subplots(figsize=(ps.WIDTH_SINGLE, 6 * ps.CM))
    ax.barh(np.array(tm.S2_FEATURES)[order], 100 * imp.importances_mean[order],
            xerr=100 * Z_95 * imp.importances_std[order] / np.sqrt(10),
            color=ps.PALETTE["s2_rf"], height=0.68,
            error_kw={"ecolor": ps.INK, "elinewidth": 0.9})
    ax.set_xlabel("Drop in agreement when permuted\n(percentage points)")
    ax.grid(axis="x", color=ps.GRID, linewidth=0.6)
    ax.grid(axis="y", visible=False)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    return fig


FIGURES = {
    "Fig2": ("Fig2_workflow", fig2_workflow),
    "Fig4": ("Fig4_agreement_bars", fig4_agreement_bars),
    "Fig5": ("Fig5_model_f1", fig5_model_f1),
    "Fig9": ("Fig9_lcrpgr_forest", fig9_lcrpgr_forest),
    "Fig10": ("Fig10_radial_profile", fig10_radial_profile),
    "Fig11": ("Fig11_sensitivity_heatmap", fig11_sensitivity_heatmap),
    "Fig12": ("Fig12_lcr_pgr", fig12_lcr_pgr),
    "FigS3": ("FigS3_umap", figs3_umap),
    "FigS5": ("FigS5_importance", figs5_importance),
}


def main() -> None:
    """Render the requested (default: all) charts; skip those without inputs."""
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("figures", nargs="*", choices=[*FIGURES, []], default=[])
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ps.apply_style()
    for key in args.figures or list(FIGURES):
        name, func = FIGURES[key]
        try:
            fig = func()
        except FileNotFoundError as e:
            LOG.warning("%s skipped: input missing (%s)", name, e.filename or e)
            continue
        paths = ps.save(fig, OUT_DIR, name)
        plt.close(fig)
        LOG.info("Wrote %s", ", ".join(p.name for p in paths))


if __name__ == "__main__":
    main()
