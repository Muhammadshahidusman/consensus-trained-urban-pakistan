"""Phase 11, Step 11.5: MDPI-style tables (booktabs LaTeX) from the CSVs in outputs/tables.

Fixed decimals (PRD section 9): areas 1 dp (km²), percentages 1 dp, LCRPGR 2 dp. Three
horizontal rules, no vertical lines, units in headers. Tables whose inputs are missing are
skipped. Every value is read from the named CSV; nothing is typed in by hand.

Output: paper/tables/Table{N}_{name}.tex

Run:  python src/14_tables.py
"""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import pandas as pd

LOG = logging.getLogger("tables")

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
PROCESSED = ROOT / "data" / "processed"
SAMPLES = ROOT / "data" / "interim" / "samples"
OUT = ROOT / "paper" / "tables"
CITY_ORDER = ("karachi", "lahore", "faisalabad", "peshawar", "rawalpindi")
CITY_LABELS = {"karachi": "Karachi", "lahore": "Lahore", "faisalabad": "Faisalabad",
               "peshawar": "Peshawar", "rawalpindi": "Rawalpindi--Islamabad"}
PROVINCES = {"karachi": "Sindh", "lahore": "Punjab", "faisalabad": "Punjab",
             "peshawar": "Khyber Pakhtunkhwa", "rawalpindi": "Punjab / ICT"}
UTM = {"karachi": "42N", "lahore": "43N", "faisalabad": "43N", "peshawar": "42N",
       "rawalpindi": "43N"}
SOURCE_LABELS = {"own": "Own model", "dw": "Dynamic World", "ghsl": "GHSL*"}
GHSL_NOTE = ("*GHSL measures building surface, not built-up l"
             "and, so it is not directly comparable with the other sources.")
INTERVAL_Y = 6
WIDE_MIN_COLS = 6
WIDE_TABCOLSEP = "4pt"
INTERPRETATION_SHORT = {"compact (all settings)": "compact", "sprawl (all settings)": "sprawl",
                        "depends on setting": "depends"}
DATASETS = [  # Table 2; IDs and roles as in CLAUDE.md section 5 and docs/data_register.md
    ("AlphaEarth Foundations Satellite Embedding V1", "Google, Google DeepMind", "10 m",
     "2017, 2020, 2023", "GOOGLE/SATELLITE\\_EMBEDDING/V1/ANNUAL", "Model features"),
    ("ESA WorldCover v100", "ESA", "10 m", "2020", "ESA/WorldCover/v100", "Consensus labels"),
    ("Dynamic World V1", "Google, WRI, NGS", "10 m", "2017, 2020, 2023",
     "GOOGLE/DYNAMICWORLD/V1", "Labels; comparison"),
    ("GHS-BUILT-S R2023A", "EC JRC", "100 m", "2015, 2020, 2025 epochs",
     "JRC/GHSL/P2023A/GHS\\_BUILT\\_S", "Labels; comparison"),
    ("GHS-SMOD R2023A", "EC JRC", "1 km", "2020", "JRC/GHSL/P2023A/GHS\\_SMOD\\_V2-0",
     "Sensitivity extent"),
    ("Sentinel-2 L1C (TOA)", "ESA Copernicus", "10--20 m", "2017--2023",
     "COPERNICUS/S2\\_HARMONIZED", "Baseline features; figures"),
    ("Cloud Score+", "Google", "10 m", "2017--2023",
     "GOOGLE/CLOUD\\_SCORE\\_PLUS/V1/S2\\_HARMONIZED", "Cloud mask"),
    ("GHS-POP R2023A", "EC JRC", "100 m", "2015, 2020, 2025 epochs",
     "JRC/GHSL/P2023A/GHS\\_POP", "Population distribution"),
    ("WorldPop", "WorldPop", "100 m", "2017, 2020", "WorldPop/GP/100m/pop",
     "Population sensitivity"),
    ("Population Census 2017, 2023", "PBS", "Admin. units", "2017, 2023", "--",
     "Population totals"),
    ("COD-AB Pakistan", "OCHA/HDX", "Vector", "2022", "--", "Census unit polygons"),
    ("Pakistan province boundaries", "PIPS", "Vector", "2024", "--",
     "Map boundaries"),
]


def latex(df: pd.DataFrame, caption: str, label: str, colfmt: str | None = None) -> str:
    """booktabs table in the MDPI template pattern: bold header, three rules, no vertical lines.

    Tables with WIDE_MIN_COLS or more columns span the full page width as in the template: the
    caption stays in the text column and only the tabular enters the adjustwidth block.
    """
    colfmt = colfmt or "l" + "r" * (df.shape[1] - 1)
    wide = df.shape[1] >= WIDE_MIN_COLS
    lines = ["\\begin{table}[H]", f"\\caption{{{caption}\\label{{{label}}}}}"]
    lines += ["\\begin{adjustwidth}{-\\extralength}{0cm}"] if wide else []
    lines += ["\\centering", "\\footnotesize" if wide else "\\small"]
    lines += [f"\\setlength{{\\tabcolsep}}{{{WIDE_TABCOLSEP}}}"] if wide else []
    lines += [f"\\begin{{tabular}}{{{colfmt}}}", "\\toprule",
              " & ".join(f"\\textbf{{{c}}}" for c in df.columns) + " \\\\", "\\midrule"]
    lines += [" & ".join(str(v) for v in row) + " \\\\" for row in df.itertuples(index=False)]
    lines += ["\\bottomrule", "\\end{tabular}"]
    lines += ["\\end{adjustwidth}"] if wide else []
    lines += ["\\end{table}"]
    return "\n".join(lines) + "\n"


def right(width_cm: float) -> str:
    """Right-aligned fixed-width column, so long headers wrap instead of widening the table."""
    return f">{{\\raggedleft\\arraybackslash}}p{{{width_cm}cm}}"


def f1(x: float) -> str:
    """One decimal place."""
    return "--" if pd.isna(x) else f"{x:.1f}"


def table1() -> str:
    """Study cities."""
    pop = pd.read_csv(PROCESSED / "population_extent.csv", encoding="utf-8")
    ext = pd.read_csv(TABLES / "extent_areas.csv", encoding="utf-8")
    rows = []
    for c in CITY_ORDER:
        p = pop[pop["city"] == c].set_index("year")["pop_extent"]
        area = ext[(ext["city"] == c) & (ext["year"].astype(str) == "union")]["extent_km2"]
        pgr = 100 * np.log(p[2023] / p[2017]) / INTERVAL_Y
        rows.append([CITY_LABELS[c], PROVINCES[c], f"{p[2017]:,.0f}", f"{p[2023]:,.0f}",
                     f"{pgr:.2f}", f1(float(area.iloc[0])), UTM[c]])
    df = pd.DataFrame(rows, columns=["City", "Province", "Population 2017",
                                     "Population 2023", "PGR (\\%/yr)",
                                     "Urban extent (km\\textsuperscript{2})", "UTM zone"])
    return latex(df, "Study cities. Population inside the study extent (census totals "
                 "distributed with GHS-POP, Equation~(\\ref{eq:dasy})); urban extent is the "
                 "union of the 2017 and 2023 extents.", "tab:cities", "llrrrrl")


def breakable_id(text: str) -> str:
    """Let a long Earth Engine ID break after slashes and underscores in a table cell."""
    return text.replace("/", "/\\allowbreak ").replace("\\_", "\\_\\allowbreak ")


def table2() -> str:
    """Datasets."""
    df = pd.DataFrame(DATASETS, columns=["Dataset", "Provider", "Resolution", "Years",
                                         "Earth Engine ID", "Role in study"])
    df["Earth Engine ID"] = df["Earth Engine ID"].map(breakable_id)
    return latex(df, "Datasets.", "tab:data",
                 "p{3.3cm}p{2.1cm}lp{2.1cm}p{4.3cm}p{2.5cm}")


def table3() -> str:
    """Consensus label summary: samples and agreement share of the working area."""
    pat = pd.read_csv(TABLES / "agreement_patterns.csv", encoding="utf-8")
    rows = []
    for c in CITY_ORDER:
        s = pd.read_csv(SAMPLES / f"samples_{c}_2020.csv", encoding="utf-8", usecols=["label"])
        a = pat[(pat["city"] == c) & (pat["frame"] == "aoi")]
        total = a["km2"].sum()
        full = a[a["n_built"].isin([0, 3])]["km2"].sum()
        built3 = a[a["n_built"] == 3]["km2"].sum()
        rows.append([CITY_LABELS[c], int((s["label"] == 1).sum()), int((s["label"] == 0).sum()),
                     f1(100 * full / total), f1(100 * built3 / total),
                     f1(100 * (total - full) / total)])
    df = pd.DataFrame(rows, columns=["City", "Built samples", "Non-built samples",
                                     "Full agreement (\\% of AOI)",
                                     "of which built (\\%)", "Disagreement (\\% of AOI)"])
    return latex(df, "Consensus labels and product agreement in 2020 within each working "
                 "area (AOI). Full agreement: all three products call the pixel built-up or "
                 "all call it non-built-up.", "tab:consensus")


def table4() -> str:
    """Spatial CV results (mean +/- SD over folds)."""
    t = pd.read_csv(TABLES / "Table4_spatial_cv.csv", encoding="utf-8")
    df = pd.DataFrame({
        "Model": t["Model"], "Features": t["Features"],
        "OA (\\%)": [f"{m:.1f} $\\pm$ {s:.1f}" for m, s in zip(t["OA_mean"], t["OA_sd"],
                                                                 strict=True)],
        "F1 built (\\%)": [f"{m:.1f} $\\pm$ {s:.1f}" for m, s in
                           zip(t["F1_built_mean"], t["F1_built_sd"], strict=True)],
        "F1 non-built (\\%)": [f"{m:.1f} $\\pm$ {s:.1f}" for m, s in
                               zip(t["F1_nonbuilt_mean"], t["F1_nonbuilt_sd"], strict=True)],
    })
    return latex(df, "Spatial block cross-validation on consensus labels (mean $\\pm$ SD over "
                 "five folds). These scores measure agreement with consensus labels, not map "
                 "accuracy.", "tab:cv", "lp{4.4cm}rrr")


def table5() -> str:
    """Pairwise agreement of the 2023 built-up maps inside both extents (RQ2)."""
    t = pd.read_csv(TABLES / "map_agreement_2023.csv", encoding="utf-8")
    pair_labels = {f"{a}-{b}": f"{SOURCE_LABELS[a]} vs {SOURCE_LABELS[b]}"
                   for a, b in (("own", "dw"), ("own", "ghsl"), ("dw", "ghsl"))}
    rows = []
    for c in CITY_ORDER:
        study = t[(t["city"] == c) & (t["extent"] == "study")].set_index("pair")
        degurba = t[(t["city"] == c) & (t["extent"] == "degurba")].set_index("pair")
        for i, pair in enumerate(pair_labels):
            rows.append([CITY_LABELS[c] if i == 0 else "", pair_labels[pair],
                         f1(study.loc[pair, "overall_agreement_pct"]),
                         f"{study.loc[pair, 'jaccard_built']:.2f}",
                         f1(degurba.loc[pair, "overall_agreement_pct"]),
                         f"{degurba.loc[pair, 'jaccard_built']:.2f}"])
    df = pd.DataFrame(rows, columns=["City", "Pair", "Agreement, study (\\%)", "Jaccard, study",
                                     "Agreement, DoU (\\%)", "Jaccard, DoU"])
    return latex(df, "Pixel agreement between the 2023 built-up maps inside the study extent and "
                 "the Degree of Urbanisation (DoU) extent (10 m grid; GHSL built if fraction "
                 "$\\geq$ 0.50). The study extent comes from the own model; the DoU extent does "
                 "not. Agreement is not accuracy: no independent reference sample was "
                 "interpreted. Dynamic World and GHSL are label sources of the own model, so "
                 "agreement with them is partly circular. " + GHSL_NOTE, "tab:agreement",
                 "p{2.4cm}p{3.9cm}" + (right(1.8) + right(1.5)) * 2)


def table6() -> str:
    """Mapped built-up area per source, with gross gain and loss."""
    t = pd.read_csv(TABLES / "lcrpgr_all_settings.csv", encoding="utf-8")
    t = t[t["setting"] == "baseline"]
    g = pd.read_csv(TABLES / "gross_net_change.csv", encoding="utf-8").set_index(["city", "source"])
    rows = []
    for c in CITY_ORDER:
        for i, src in enumerate(("own", "dw", "ghsl")):
            r = t[(t["city"] == c) & (t["source"] == src)].iloc[0]
            gain = f1(g.loc[(c, src), "gain_km2"]) if (c, src) in g.index else "--"
            loss = f1(g.loc[(c, src), "loss_km2"]) if (c, src) in g.index else "--"
            rows.append([CITY_LABELS[c] if i == 0 else "", SOURCE_LABELS[src],
                         f1(r["urb_2017_km2"]), f1(r["urb_2023_km2"]),
                         f1(100 * (r["urb_2023_km2"] / r["urb_2017_km2"] - 1)), gain, loss])
    df = pd.DataFrame(rows, columns=["City", "Source", "Area 2017 (km\\textsuperscript{2})",
                                     "Area 2023 (km\\textsuperscript{2})", "Net change (\\%)",
                                     "Gross gain (km\\textsuperscript{2})",
                                     "Gross loss (km\\textsuperscript{2})"])
    return latex(df, "Mapped built-up area within the study extent (pixel counts), with gross "
                 "gain and loss between the two dates. Without an independent reference sample "
                 "these are not bias-adjusted and carry no sampling interval. GHSL gain and loss "
                 "are not shown because its 2017 and 2023 layers are interpolated. " + GHSL_NOTE,
                 "tab:area",
                 "p{2.4cm}l" + right(1.6) * 5)


def table7() -> str:
    """SDG 11.3.1 per source: primary rates first, then the ratio and its range."""
    t = pd.read_csv(TABLES / "Table7_sdg1131.csv", encoding="utf-8")
    rows = []
    for c in CITY_ORDER:
        for i, (_, r) in enumerate(t[t["city"] == c].iterrows()):
            rows.append([CITY_LABELS[c] if i == 0 else "", SOURCE_LABELS[r["source"]],
                         f"{100 * r['LCR']:.2f}", f"{100 * r['PGR']:.2f}",
                         f"{r['BUpc_2017_m2']:.1f}", f"{r['BUpc_2023_m2']:.1f}",
                         f"{r['LCRPGR']:.2f}", f"{r['LCRPGR_degurba']:.2f}",
                         f"{r['range_low']:.2f}--{r['range_high']:.2f} ({r['n_settings']})",
                         INTERPRETATION_SHORT[r["interpretation"]]])
    df = pd.DataFrame(rows, columns=["City", "Source", "LCR", "PGR", "BUpc 2017", "BUpc 2023",
                                     "LCRPGR", "LCRPGR (DoU)", "Range (n)", "Reading"])
    return latex(df, "SDG indicator 11.3.1, 2017--2023 "
                 "(Equations~(\\ref{eq:lcr})--(\\ref{eq:bupc})) at baseline settings. LCR, PGR "
                 "and built-up area per capita (BUpc) are the primary results: LCR and PGR in "
                 "\\%/yr, BUpc in m\\textsuperscript{2} per person. LCRPGR uses the study extent; "
                 "LCRPGR (DoU) uses the Degree of Urbanisation extent. Range: minimum to maximum "
                 "over the n settings of Table~\\ref{tab:sensitivity}; it reflects method choices "
                 "and is not a confidence interval. Reading: compact if the whole range is below "
                 "1, sprawl if it is above 1, otherwise depends. " + GHSL_NOTE, "tab:sdg",
                 "p{2.2cm}lrr" + right(1.1) * 2 + right(1.3) * 2 + "rl")


def table8() -> str:
    """Sensitivity analysis: LCRPGR per source x setting (rows) and city (columns)."""
    t = pd.read_csv(TABLES / "lcrpgr_all_settings.csv", encoding="utf-8")
    base = t[t["setting"] == "baseline"].set_index(["city", "source"])["LCRPGR"]
    rows = []
    for src in ("own", "dw", "ghsl"):
        s = t[t["source"] == src]
        for i, setting in enumerate(dict.fromkeys(s["setting"])):
            cells = []
            for c in CITY_ORDER:
                v = s[(s["city"] == c) & (s["setting"] == setting)]["LCRPGR"]
                if v.empty:
                    cells.append("--")
                    continue
                flip = setting != "baseline" and (v.iloc[0] > 1) != (base[(c, src)] > 1)
                cells.append(f"{v.iloc[0]:.2f}" + ("\\textsuperscript{\\dag}" if flip else ""))
            rows.append([SOURCE_LABELS[src] if i == 0 else "", setting, *cells])
    df = pd.DataFrame(rows, columns=["Source", "Setting", *[CITY_LABELS[c] for c in CITY_ORDER]])
    return latex(df, "LCRPGR under one-at-a-time sensitivity settings. \\dag: the setting moves "
                 "the value across 1 relative to the baseline of the same source. " + GHSL_NOTE,
                 "tab:sensitivity", "ll" + "r" * len(CITY_ORDER))


def table9() -> str:
    """Comparison with Open Buildings: disputed pixels, building-based LCR, where buildings grew."""
    d = pd.read_csv(TABLES / "ob_disputed.csv", encoding="utf-8").set_index(["city", "source"])
    b = pd.read_csv(TABLES / "ob_lcr.csv", encoding="utf-8")
    b = b[b["extent"] == "study"].set_index("city")
    g = pd.read_csv(TABLES / "ob_change.csv", encoding="utf-8")
    g = g[g["source"] == "own"].set_index(["city", "class"])["building_change_km2"]
    rows = []
    for c in CITY_ORDER:
        cells = []
        for src in ("own", "dw", "ghsl"):
            r = d.loc[(c, src)]
            cells.append(f"{r['share_where_built_pct']:.1f} / "
                         f"{r['share_where_nonbuilt_pct']:.1f}")
        total = g.loc[c].sum()
        rows.append([CITY_LABELS[c], *cells, f"{100 * b.loc[c, 'LCR']:.2f}",
                     f"{b.loc[c, 'LCRPGR']:.2f}", f"{100 * g.loc[(c, 'stable built')] / total:.0f}",
                     f"{100 * g.loc[(c, 'new built')] / total:.0f}"])
    df = pd.DataFrame(rows, columns=["City", "Own model", "Dynamic World", "GHSL*",
                                     "LCR, buildings (\\%/yr)", "LCRPGR, buildings",
                                     "Gain on stable built (\\%)", "Gain on new built (\\%)"])
    return latex(df, "Comparison with Open Buildings 2.5D Temporal, which played no part in the "
                 "labels or the model. Columns 2--4: pixels disputed in 2020 (one or two products "
                 "call them built-up) inside the study extent; mean 2023 building share (\\%) of "
                 "the surrounding 110 m square where the 2023 map of the source says built / "
                 "non-built. A larger positive gap means the calls follow the buildings more "
                 "closely. Columns 5--6: rates from building area in the study extent, which "
                 "count infill and so measure a different quantity from LCR on built-up land. "
                 "Columns 7--8: share of the building area gained that lies on stable built and "
                 "on new built land of the own model. Open Buildings is itself a model output, "
                 "so all of this is agreement between maps, not accuracy. " + GHSL_NOTE, "tab:ob",
                 "p{2.2cm}" + right(1.7) * 3 + right(1.5) * 4)


def table_s1() -> str:
    """Per-city spatial CV and leave-one-city-out transfer (consensus labels)."""
    cv = pd.read_csv(TABLES / "cv_per_city.csv", encoding="utf-8")
    loco = pd.read_csv(TABLES / "transfer_loco.csv", encoding="utf-8")
    rows = []
    for c in CITY_ORDER:
        for i, m in enumerate(dict.fromkeys(cv["model"])):
            a = cv[(cv["city"] == c) & (cv["model"] == m)].iloc[0]
            b = loco[(loco["held_out_city"] == c) & (loco["model"] == m)].iloc[0]
            rows.append([CITY_LABELS[c] if i == 0 else "", m, f1(a["OA"]), f1(a["F1_built"]),
                         f1(b["OA"]), f1(b["F1_built"])])
    df = pd.DataFrame(rows, columns=["City", "Model", "Spatial CV OA (\\%)",
                                     "Spatial CV F1 built (\\%)", "LOCO OA (\\%)",
                                     "LOCO F1 built (\\%)"])
    return latex(df, "Per-city scores on consensus labels: pooled five-fold spatial block "
                 "cross-validation (test points of each city) and leave-one-city-out (LOCO) "
                 "transfer, where the model is trained on the other four cities. Not map "
                 "accuracy.", "tab:loco", "llrrrr")


TABLE_FUNCS = {"Table1_cities": table1, "Table2_datasets": table2,
               "Table3_consensus": table3, "Table4_spatial_cv": table4,
               "Table5_map_agreement": table5, "Table6_mapped_area": table6,
               "Table7_sdg1131": table7, "Table8_sensitivity": table8,
               "Table9_open_buildings": table9,
               "TableS1_cv_transfer": table_s1}


def main() -> None:
    """Write every table whose inputs exist."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    OUT.mkdir(parents=True, exist_ok=True)
    for name, func in TABLE_FUNCS.items():
        try:
            text = func()
        except FileNotFoundError as e:
            LOG.warning("%s skipped: input missing (%s)", name, Path(e.filename).name)
            continue
        (OUT / f"{name}.tex").write_text(text, encoding="utf-8")
        LOG.info("Wrote %s.tex", name)


if __name__ == "__main__":
    main()
