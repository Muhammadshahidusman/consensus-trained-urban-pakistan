"""Design-based estimators for a stratified random sample (Olofsson et al., 2014; Stehman, 2014).

The sample is stratified on the own change map. Every quantity is written as a total or a
ratio of totals of per-point variables, following Stehman (2014), so the same code serves:

* maps whose classes equal the strata (the own change map): the estimators reduce exactly to
  PRD equations (5) to (9) (Olofsson et al., 2014);
* maps whose classes differ from the strata (own yearly maps, Dynamic World, GHSL): Stehman's
  ratio estimators, as PRD Phase 8.2 requires. Plain Olofsson formulas are never applied to
  those maps.

Notation: h stratum, N_h stratum size (pixels), n_h sample size, W_h = N_h / N.
Finite population corrections are ignored (n_h << N_h), as in Olofsson et al. (2014).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

Z_95 = 1.96


@dataclass(frozen=True)
class Estimate:
    """Point estimate with standard error and 95% confidence interval."""

    value: float
    se: float

    @property
    def ci95(self) -> tuple[float, float]:
        """Normal-approximation 95% confidence interval."""
        return self.value - Z_95 * self.se, self.value + Z_95 * self.se

    def scaled(self, factor: float) -> Estimate:
        """Multiply value and SE by a constant (e.g. a proportion -> an area)."""
        return Estimate(self.value * factor, self.se * abs(factor))


def _weights(strata: pd.Series, n_pixels: dict) -> tuple[pd.Series, pd.Series]:
    """W_h for every stratum that is sampled, and the sample sizes n_h."""
    n_h = strata.value_counts()
    missing = set(n_h.index) - set(n_pixels)
    if missing:
        raise KeyError(f"No stratum size for {sorted(missing)}")
    total = float(sum(n_pixels.values()))
    w_h = pd.Series({h: n_pixels[h] / total for h in n_h.index})
    return w_h, n_h


def proportion(y: np.ndarray, strata: pd.Series, n_pixels: dict) -> Estimate:
    """Population proportion of a per-point variable y (Stehman 2014 eq. 3; PRD eq. 6-7).

    For y = 1[reference class j] this is p_.j of Olofsson et al. (2014): sum_h W_h ybar_h,
    with variance sum_h W_h^2 s2_yh / n_h (equals eq. 7 for binary y).
    """
    df = pd.DataFrame({"y": np.asarray(y, dtype=float), "h": strata.to_numpy()})
    w_h, n_h = _weights(df["h"], n_pixels)
    unsampled = {h for h, n in n_pixels.items() if n > 0} - set(n_h.index)
    if unsampled:
        raise ValueError(f"Strata with mapped area but no sample: {sorted(unsampled)}")
    g = df.groupby("h")["y"]
    mean, var = g.mean(), g.var(ddof=1).fillna(0.0)
    value = float((w_h * mean).sum())
    se = float(np.sqrt((w_h**2 * var / n_h).sum()))
    return Estimate(value, se)


def ratio(y: np.ndarray, x: np.ndarray, strata: pd.Series, n_pixels: dict) -> Estimate:
    """Ratio of two population totals R = Y / X (Stehman 2014 eq. 26-28).

    UA of class k: y = 1[map k and ref k], x = 1[map k]. PA: x = 1[ref k].
    V(R) = (1 / X^2) sum_h N_h^2 (s2_yh + R^2 s2_xh - 2 R s_xyh) / n_h.
    """
    df = pd.DataFrame({"y": np.asarray(y, dtype=float), "x": np.asarray(x, dtype=float),
                       "h": strata.to_numpy()})
    _, n_h = _weights(df["h"], n_pixels)
    big_n = pd.Series({h: float(n_pixels[h]) for h in n_h.index})
    g = df.groupby("h")
    y_tot = float((big_n * g["y"].mean()).sum())
    x_tot = float((big_n * g["x"].mean()).sum())
    if x_tot == 0:
        return Estimate(float("nan"), float("nan"))
    r = y_tot / x_tot
    s2y = g["y"].var(ddof=1).fillna(0.0)
    s2x = g["x"].var(ddof=1).fillna(0.0)
    sxy = g.apply(lambda d: d["x"].cov(d["y"]) if len(d) > 1 else 0.0, include_groups=False)
    var = float((big_n**2 * (s2y + r**2 * s2x - 2 * r * sxy) / n_h).sum()) / x_tot**2
    return Estimate(r, float(np.sqrt(max(var, 0.0))))


def error_matrix(map_cls: np.ndarray, ref_cls: np.ndarray, strata: pd.Series, n_pixels: dict,
                 classes: list) -> pd.DataFrame:
    """Estimated area proportions p_ij, map class i (rows) x reference class j (columns).

    Equals PRD eq. (5), W_i n_ij / n_i., when the strata are the map classes.
    """
    m, r = np.asarray(map_cls), np.asarray(ref_cls)
    out = pd.DataFrame(index=classes, columns=classes, dtype=float)
    for i in classes:
        for j in classes:
            out.loc[i, j] = proportion((m == i) & (r == j), strata, n_pixels).value
    return out


def accuracy(map_cls: np.ndarray, ref_cls: np.ndarray, strata: pd.Series, n_pixels: dict,
             positive=1) -> dict[str, Estimate]:
    """OA, UA, PA of the positive class (PRD eq. 9) and F1 (eq. 4, point estimate only)."""
    m, r = np.asarray(map_cls), np.asarray(ref_cls)
    hit = (m == positive) & (r == positive)
    oa = proportion(m == r, strata, n_pixels)
    ua = ratio(hit, m == positive, strata, n_pixels)
    pa = ratio(hit, r == positive, strata, n_pixels)
    f1 = (2 * ua.value * pa.value / (ua.value + pa.value)
          if ua.value + pa.value > 0 else float("nan"))
    return {"OA": oa, "UA": ua, "PA": pa, "F1": Estimate(f1, float("nan"))}


def domain_accuracy(map_cls: np.ndarray, ref_cls: np.ndarray, domain: np.ndarray,
                    strata: pd.Series, n_pixels: dict, positive=1) -> dict[str, Estimate]:
    """Accuracy inside a spatial domain (e.g. the suburban fringe), as ratios of totals."""
    m, r, d = np.asarray(map_cls), np.asarray(ref_cls), np.asarray(domain, dtype=bool)
    hit = (m == positive) & (r == positive) & d
    return {
        "OA": ratio((m == r) & d, d, strata, n_pixels),
        "UA": ratio(hit, (m == positive) & d, strata, n_pixels),
        "PA": ratio(hit, (r == positive) & d, strata, n_pixels),
    }


def covariance(y1: np.ndarray, y2: np.ndarray, strata: pd.Series, n_pixels: dict) -> float:
    """Covariance of two stratified proportion estimators from the same sample.

    cov(p1, p2) = sum_h W_h^2 s_{y1 y2, h} / n_h (same form as the variance in proportion()).
    Used for the 2017 and 2023 built-up proportions, which share the sample points.
    """
    df = pd.DataFrame({"a": np.asarray(y1, dtype=float), "b": np.asarray(y2, dtype=float),
                       "h": strata.to_numpy()})
    w_h, n_h = _weights(df["h"], n_pixels)
    cov_h = df.groupby("h").apply(lambda d: d["a"].cov(d["b"]) if len(d) > 1 else 0.0,
                                  include_groups=False)
    return float((w_h**2 * cov_h / n_h).sum())
