"""Reusable map parts: scale bar, north arrow, notes, imagery treatment (PCD Step 11.2)."""

from __future__ import annotations

import matplotlib.patheffects as pe
import numpy as np
from matplotlib.axes import Axes
from matplotlib.colors import to_rgb
from matplotlib_scalebar.scalebar import ScaleBar
from pyproj import CRS

UTM_NOTES = {
    32642: "WGS 84 / UTM zone 42N (EPSG:32642)",
    32643: "WGS 84 / UTM zone 43N (EPSG:32643)",
}
ALBERS_NOTE = "Asia South Albers Equal Area Conic (ESRI:102028)"
STRETCH_PCT = (0.5, 99.8)
GAMMA = 0.72  # lifts dark cropland; applied after the per-band stretch
DUOTONE_LOW, DUOTONE_HIGH = "#A5AFC0", "#F7F8FA"
SATURATION = 1.25
INK, HALO = "#141B34", "#FFFFFF"
LUMA = np.array([0.299, 0.587, 0.114])


def add_scale_bar(ax: Axes, crs: CRS | str, location: str = "lower left",
                  on_image: bool = False) -> None:
    """Scale bar in km. Refuses unprojected (degree) CRSs (CLAUDE.md section 11).

    Args:
        ax: Map axes.
        crs: CRS of the axes.
        location: Matplotlib location string.
        on_image: Dark bar on a pale box, so it reads over any imagery.

    Raises:
        ValueError: If ``crs`` is geographic.
    """
    crs = CRS.from_user_input(crs)
    if crs.is_geographic:
        raise ValueError("No scale bar on an unprojected map")
    style = ({"color": INK, "box_color": HALO, "box_alpha": 0.72} if on_image
             else {"box_alpha": 0.8})
    ax.add_artist(ScaleBar(1, units="m", location=location, length_fraction=0.25,
                           width_fraction=0.008, font_properties={"size": 6.5}, **style))


def add_north_arrow(ax: Axes, x: float = 0.94, y: float = 0.95, color: str = INK) -> None:
    """Slim north arrow in axes-fraction coordinates, outlined so it reads on bright imagery."""
    arrow = ax.annotate("N", xy=(x, y), xytext=(x, y - 0.1), xycoords="axes fraction",
                        ha="center", va="center", fontsize=6.5, fontweight="bold", color=color,
                        arrowprops={"arrowstyle": "-|>", "color": color, "lw": 0.9, "shrinkA": 1,
                                    "shrinkB": 0})
    halo = [pe.withStroke(linewidth=1.5, foreground=HALO)]
    arrow.set_path_effects(halo)
    arrow.arrow_patch.set_path_effects(halo)


def add_notes(ax: Axes, crs_text: str, source_text: str) -> None:
    """CRS and data source line under the map."""
    ax.text(0.0, -0.04, f"{crs_text} | {source_text}", transform=ax.transAxes,
            fontsize=6, color="#555555", va="top")


def _stretch(a: np.ndarray, limits: tuple[float, float] | None = None) -> np.ndarray:
    """Linear stretch to 0-1 between percentiles (or fixed limits)."""
    lo, hi = limits if limits is not None else np.percentile(a, STRETCH_PCT)
    return np.clip((a - lo) / max(hi - lo, 1e-6), 0, 1)


def duotone(rgb: np.ndarray, low: str = DUOTONE_LOW, high: str = DUOTONE_HIGH) -> np.ndarray:
    """Soft two-colour version of an RGB image (H, W, 3): a quiet base for thematic layers."""
    grey = _stretch(rgb @ LUMA)[..., None]
    return np.array(to_rgb(low)) * (1 - grey) + np.array(to_rgb(high)) * grey


def channel_limits(*images: np.ndarray) -> list[tuple[float, float]]:
    """Per-band stretch limits, shared by all the given (H, W, 3) images."""
    stack = np.stack(images)
    return [tuple(np.percentile(stack[..., i], STRETCH_PCT)) for i in range(3)]


def vivid(rgb: np.ndarray, limits: list[tuple[float, float]] | None = None,
          saturation: float = SATURATION) -> np.ndarray:
    """True colour (H, W, 3) in 0-1, stretched per band and slightly more saturated.

    Args:
        rgb: Image array.
        limits: Per-band limits from ``channel_limits``. Pass the same limits for two dates of a
            site so that the treatment cannot create or hide change.
        saturation: Factor applied to the difference from grey.
    """
    limits = limits if limits is not None else channel_limits(rgb)
    a = np.stack([_stretch(rgb[..., i].astype(float), limits[i]) for i in range(3)], axis=-1)
    a = a ** GAMMA
    grey = (a @ LUMA)[..., None]
    return np.clip(grey + saturation * (a - grey), 0, 1)
