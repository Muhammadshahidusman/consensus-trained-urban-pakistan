"""Shared design system for all paper figures (PCD Step 11.1; PRD sections 6 and 8).

One palette for maps and charts. Every set of category colours was run through a colour-vision
check (OKLab delta-E under protan, deutan and tritan simulation, plus contrast against its
surface); docs/decisions.md records the result. Figures are light, for print: white page, with
map tiles filled by soft greyscale Sentinel-2 imagery under the thematic colours.
"""

from __future__ import annotations

import time
from pathlib import Path

import matplotlib as mpl
from matplotlib.figure import Figure

# Surfaces and text
PAGE = "#FFFFFF"
INK = "#141B34"
MUTED = "#5B6478"
RULE = "#D5D9E6"
GRID = "#E6E8F2"
BAND = "#F3F5FB"  # alternating bands on charts; key cards on maps
FRAME = "#AEB6C8"  # thin frame around map tiles

# Fixed colour per model / data source across every chart
PALETTE = {
    "own_model": "#3D5AFE", "dynamic_world": "#D81B7A", "ghsl": "#E05A00",
    "s2_rf": "#0B9385", "gbt": "#A83CC9", "mlp": INK, "worldcover": "#7A8299",
}
SOURCE_COLOURS = {"own": PALETTE["own_model"], "dw": PALETTE["dynamic_world"],
                  "ghsl": PALETTE["ghsl"], "wc": PALETTE["worldcover"], "s2": PALETTE["s2_rf"]}
SOURCE_MARKERS = {"own": "o", "dw": "s", "ghsl": "D", "wc": "^", "s2": "v"}
SOURCE_LABELS = {"own": "Own model (AlphaEarth)", "dw": "Dynamic World", "ghsl": "GHSL",
                 "wc": "WorldCover", "s2": "Sentinel-2 RF"}
GHSL_QUANTITY_LABEL = "GHSL (building surface)"


def source_marker(source: str) -> dict:
    """Marker style of a source. GHSL is hollow: it measures a different quantity."""
    colour = SOURCE_COLOURS[source]
    style = {"marker": SOURCE_MARKERS[source], "ls": "", "color": colour}
    if source == "ghsl":
        return {**style, "mfc": "white", "mec": colour, "mew": 1.3}
    return {**style, "mec": "white", "mew": 0.7}


# Built-up change classes on maps; class 0 (non-built in both years) stays transparent
CHANGE_COLOURS = {1: "#2F54C8", 2: "#E05A00", 3: "#C2187A"}
CHANGE_LABELS = {0: "Non-built, both years (imagery)", 1: "Stable built-up",
                 2: "New built-up 2017–2023", 3: "Reversal (built → non-built)"}
# Products calling a pixel built-up: ordered, so colour darkens as the count rises. On maps, 0 of
# 3 stays transparent; AGREEMENT_ZERO stands for it on charts.
AGREEMENT_COLOURS = {1: "#F9B233", 2: "#E8503A", 3: "#6A0F6B"}
AGREEMENT_ZERO = "#DDE2EC"
IMAGERY_SWATCH = "#CFD5DF"  # legend swatch for greyscale imagery
OUTSIDE_SWATCH = "#EFF1F5"  # legend swatch for the faded area outside the working area
EXTENT_LINE = INK  # study extent on thematic maps
EXTENT_LINE_TRUE_COLOUR = "#FFD43B"  # study extent on true-colour imagery
NODATA = "#d9d9d9"

CITY_LABELS = {"karachi": "Karachi", "lahore": "Lahore", "faisalabad": "Faisalabad",
               "peshawar": "Peshawar", "rawalpindi": "Rawalpindi–Islamabad"}
CITY_ORDER = ("karachi", "lahore", "faisalabad", "peshawar", "rawalpindi")
CM = 1 / 2.54
WIDTH_SINGLE, WIDTH_DOUBLE = 8.5 * CM, 17 * CM
DPI = 600
SAVE_RETRIES, SAVE_RETRY_WAIT_S = 5, 2


def apply_style() -> None:
    """Set the shared rcParams: Arial 8 pt, quiet axes, light grid, no top or right spines."""
    mpl.rcParams.update({
        "font.family": "Arial", "font.size": 8, "axes.labelsize": 8.5,
        "axes.titlesize": 8.5, "legend.fontsize": 7.5, "text.color": INK,
        "axes.labelcolor": INK, "axes.edgecolor": RULE, "axes.linewidth": 0.7,
        "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelcolor": INK,
        "ytick.labelcolor": INK, "xtick.major.size": 0, "ytick.major.size": 0,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
        "axes.grid.axis": "y", "axes.axisbelow": True, "legend.frameon": False,
        "savefig.dpi": DPI, "savefig.bbox": "tight", "savefig.pad_inches": 0.03,
        "pdf.fonttype": 42,
    })


def save(fig: Figure, out_dir: Path, name: str, tight: bool = True) -> list[Path]:
    """Save a figure as 600 dpi PNG and vector PDF.

    Args:
        fig: The figure.
        out_dir: Output folder.
        name: File stem.
        tight: Crop to the content. Map figures are laid out to the exact page size: pass False.

    Returns:
        The two written paths.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = [out_dir / f"{name}.png", out_dir / f"{name}.pdf"]
    for p in paths:
        tmp = p.with_name(f"_tmp_{p.name}")
        fig.savefig(tmp, dpi=DPI, facecolor=PAGE, bbox_inches="tight" if tight else None)
        for attempt in range(1, SAVE_RETRIES + 1):  # Windows can briefly lock a file being read
            try:
                tmp.replace(p)
                break
            except OSError:
                if attempt == SAVE_RETRIES:
                    raise
                time.sleep(SAVE_RETRY_WAIT_S)
    return paths
