"""Tests for src/08_accuracy_area.py on a hand-made labelled sample."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from conftest import load_script

mod = load_script("src/08_accuracy_area.py")


def test_read_reference_maps_answers(tmp_path) -> None:
    path = tmp_path / "ceo.csv"
    path.write_text(
        "PLOTID,center_lon,Built in 2017?,Built in 2023?\n"
        "1,73.0,Yes,Yes\n2,73.1,No,yes \n3,73.2,Unclear,No\n",
        encoding="utf-8")
    ref = mod.read_reference(path)
    assert ref["ref_2017"].tolist()[:2] == [1, 0]
    assert np.isnan(ref["ref_2017"].iloc[2])
    assert ref["ref_2023"].tolist() == [1, 1, 0]


def test_change_class() -> None:
    out = mod.change_class(pd.Series([0, 1, 0, 1]), pd.Series([0, 1, 1, 0]))
    np.testing.assert_array_equal(out, [0, 1, 2, 3])


def test_assess_city_area_matches_hand_value() -> None:
    # Strata: 1 stable built (N=100, 4 pts), 0 stable non-built (N=900, 5 pts).
    # 2017 reference built: stratum 1 [1,1,1,0], stratum 0 [0,0,0,0,1] -> p = 0.255
    # A_tot = 1000 px * 1e-4 km² = 0.1 km² -> area = 0.0255 km²
    h = [1, 1, 1, 1, 0, 0, 0, 0, 0]
    ref = [1, 1, 1, 0, 0, 0, 0, 0, 1]
    df = pd.DataFrame({
        "h": h, "ref_2017": ref, "ref_2023": ref,
        "own_2017": h, "own_2023": h, "dw_2017": h, "dw_2023": h,
        "ghsl_2017": h, "ghsl_2023": h, "change": h,
        "fringe": [True] * 9,
    })
    out = mod.assess_city(df, {1: 100, 0: 900})
    area = out["area"].set_index("year")
    assert area.loc[2017, "area_km2"] == pytest.approx(0.0255)
    acc = out["accuracy"].set_index(["map", "year"])
    assert acc.loc[("own", 2017), "OA"] == pytest.approx(79.5)
    assert acc.loc[("own", 2017), "UA"] == pytest.approx(75.0)
    m = out["matrices"]
    p = m[(m["map"] == "own") & (m["year"] == 2017)].set_index(["map_class", "ref_class"])
    assert p.loc[(1, 1), "p_ij"] == pytest.approx(0.075)


def test_unclear_points_are_left_out_of_that_year() -> None:
    df = pd.DataFrame({
        "h": [1, 1, 0, 0], "ref_2017": [1, np.nan, 0, 0], "ref_2023": [1, 1, 0, 0],
        "own_2017": [1, 1, 0, 0], "own_2023": [1, 1, 0, 0], "dw_2017": [1, 1, 0, 0],
        "dw_2023": [1, 1, 0, 0], "ghsl_2017": [1, 1, 0, 0], "ghsl_2023": [1, 1, 0, 0],
        "change": [1, 1, 0, 0], "fringe": [False] * 4,
    })
    area = mod.assess_city(df, {1: 10, 0: 90})["area"].set_index("year")
    assert area.loc[2017, "n"] == 3
    assert area.loc[2023, "n"] == 4
