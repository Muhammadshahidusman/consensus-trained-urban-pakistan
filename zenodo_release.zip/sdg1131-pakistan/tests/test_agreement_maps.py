"""Tests for the local agreement statistics in gee/03_agreement_maps.py (equation 1)."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from conftest import load_script

mod = load_script("gee/03_agreement_maps.py")


def test_n_built_is_popcount() -> None:
    pattern = np.arange(8, dtype=np.uint8)
    np.testing.assert_array_equal(mod.n_built(pattern), [0, 1, 1, 2, 1, 2, 2, 3])


def test_pattern_areas_hand_example() -> None:
    # 4 pixels in frame: none, WC only, WC+DW, all three; one pixel outside frame
    pattern = np.array([[0, 1, 3, 7, 7]], dtype=np.uint8)
    frame = np.array([[True, True, True, True, False]])
    out = mod.pattern_areas(pattern, frame, pixel_km2=0.5).set_index("pattern")
    assert out["km2"].sum() == pytest.approx(2.0)
    assert out.loc[7, "km2"] == pytest.approx(0.5)  # outside-frame pixel not counted
    assert out.loc[3, ["wc", "dw", "ghsl", "n_built"]].tolist() == [1, 1, 0, 2]
    assert out["pct"].sum() == pytest.approx(100.0)


def test_pairwise_hand_example() -> None:
    # WC built in px 1,2,3; DW built in px 2,3; GHSL built in px 3 only
    pattern = np.array([0, 1, 3, 7], dtype=np.uint8)
    frame = np.ones(4, dtype=bool)
    out = mod.pairwise(pattern, frame).set_index("pair")
    assert out.loc["wc-dw", "overall_agreement"] == pytest.approx(0.75)
    assert out.loc["wc-dw", "jaccard_built"] == pytest.approx(2 / 3)
    assert out.loc["dw-ghsl", "jaccard_built"] == pytest.approx(1 / 2)
    assert out.loc["wc-ghsl", "built_pct_first"] == pytest.approx(75.0)


def test_summary_table_uses_extent_frame_only() -> None:
    rows = []
    for frame, scale in (("extent", 1.0), ("aoi", 10.0)):
        for code in range(8):
            rows.append({"city": "x", "frame": frame, "pattern": code,
                         "n_built": int(mod.n_built(np.array([code], dtype=np.uint8))[0]),
                         "km2": scale})
    out = mod.summary_table(pd.DataFrame(rows)).iloc[0]
    assert out["extent_km2"] == pytest.approx(8.0)
    assert [out[f"A{k}_km2"] for k in range(4)] == [1.0, 3.0, 3.0, 1.0]
    assert out["A1_pct"] == pytest.approx(37.5)
