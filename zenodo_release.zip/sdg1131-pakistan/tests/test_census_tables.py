"""Tests for the census parsing helpers in src/00_census_tables.py and src/00_boundaries.py."""

from __future__ import annotations

import pandas as pd
import pytest
from conftest import load_script

census = load_script("src/00_census_tables.py")
bounds = load_script("src/00_boundaries.py")


def _units(dist_total: int, tehsil_totals: list[int]) -> pd.DataFrame:
    rows = [{"province": "P", "district": "D DISTRICT", "unit_name": "D DISTRICT",
             "unit_level": "district", "pop_total_2017": dist_total, "pop_total_2023": dist_total,
             "rural_pop_2017": dist_total, "urban_pop_2017": 0,
             "rural_pop_2023": dist_total, "urban_pop_2023": 0}]
    rows += [{"province": "P", "district": "D DISTRICT", "unit_name": f"T{i} TEHSIL",
              "unit_level": "tehsil", "pop_total_2017": t, "pop_total_2023": t,
              "rural_pop_2017": t, "urban_pop_2017": 0, "rural_pop_2023": t, "urban_pop_2023": 0}
             for i, t in enumerate(tehsil_totals)]
    return pd.DataFrame(rows)


def test_district_sums_agree() -> None:
    assert census.check_district_sums(_units(300, [100, 200])).empty


def test_district_sum_mismatch_reported() -> None:
    issues = census.check_district_sums(_units(300, [100, 150]))
    assert set(issues["year"]) == {"2017", "2023"}
    assert (issues["difference"] == -50).all()


def test_split_mismatch_in_study_district_raises() -> None:
    units = _units(300, [100, 200])
    units.loc[1, "urban_pop_2023"] = 5
    with pytest.raises(ValueError, match="study district"):
        census.check_splits(units, ("D DISTRICT",))
    census.check_splits(units, ("OTHER DISTRICT",))  # outside study area: warning only


def test_to_int_treats_blank_as_zero() -> None:
    assert census.to_int(float("nan")) == 0
    assert census.to_int(12.6) == 13


@pytest.mark.parametrize(("raw", "expected"), [
    ("SAMMUNDRI TEHSIL", "SAMMUNDRI"),
    ("Kallar Sayaddan", "KALLAR SAYADDAN"),
    ("HASSAN KHEL SUB-DIVISION", "HASSAN KHEL"),
])
def test_boundary_name_cleaning(raw: str, expected: str) -> None:
    assert bounds.clean_name(raw) == expected
