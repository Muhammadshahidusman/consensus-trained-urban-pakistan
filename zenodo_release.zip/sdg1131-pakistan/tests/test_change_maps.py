"""Tests for the change classes in src/06_change_maps.py (Step 6.3)."""

from __future__ import annotations

import numpy as np
from conftest import load_script

mod = load_script("src/06_change_maps.py")


def test_change_classes_hand_example() -> None:
    start = np.array([0, 1, 0, 1, 255, 0], dtype=np.uint8)
    end = np.array([0, 1, 1, 0, 1, 255], dtype=np.uint8)
    # non-built both, stable built, new built, reversal, nodata, nodata
    np.testing.assert_array_equal(mod.change_map(start, end), [0, 1, 2, 3, 255, 255])
