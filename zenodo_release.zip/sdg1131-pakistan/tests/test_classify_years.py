"""Tests for gee/06_classify_years.py helpers (no Earth Engine login needed)."""

from __future__ import annotations

import pytest
from conftest import load_script

mod = load_script("gee/06_classify_years.py")


def test_ghsl_weights_match_equation_15() -> None:
    # GHSL_2017 = GHSL_2015 + 2/5 (GHSL_2020 - GHSL_2015)
    assert mod.ghsl_weight(2017) == pytest.approx(2 / 5)
    # GHSL_2023 = GHSL_2020 + 3/5 (GHSL_2025 - GHSL_2020)
    assert mod.ghsl_weight(2023) == pytest.approx(3 / 5)
