# Run: python -m pytest -q   (needs earthengine-api installed; no EE login required)
import pytest
from conftest import load_script

mod = load_script("gee/01_consensus_labels.py")


def test_default_config_is_valid() -> None:
    mod.validate_config(mod.CITIES)


def test_duplicate_city_names_rejected() -> None:
    c = mod.City("lahore", 74.34, 31.52, 30, 32643)
    with pytest.raises(ValueError):
        mod.validate_config((c, c))


def test_non_positive_radius_rejected() -> None:
    with pytest.raises(ValueError):
        mod.validate_config((mod.City("x", 70.0, 30.0, 0, 32642),))


def test_bad_coordinates_rejected() -> None:
    with pytest.raises(ValueError):
        mod.validate_config((mod.City("x", 200.0, 30.0, 10, 32642),))


def test_threshold_override_validated() -> None:
    with pytest.raises(ValueError):
        mod.validate_config(mod.CITIES, ghsl_built_min=0.01)  # below tau_n
    mod.validate_config(mod.CITIES, ghsl_built_min=0.40)


def test_check_counts(tmp_path) -> None:
    path = tmp_path / "samples_x_2020.csv"
    path.write_text("stratum\n" + "1\n" * 3 + "0\n" * 2 + "2\n", encoding="utf-8")
    assert mod.check_counts(path) == {"nonbuilt_land": 2, "built": 3, "nonbuilt_water": 1}


def test_class_points_caps_water_at_ten_percent() -> None:
    alloc = mod.class_points(2500, 0.10)
    assert alloc == {0: 2250, 1: 2500, 2: 250}
    assert alloc[0] + alloc[2] == alloc[1]  # classes stay balanced
