"""Hand-worked checks of src/estimators.py against PRD equations (5) to (9).

Example: two strata that equal the map classes.
    Stratum 1 (map built):     N = 100 px, sample n = 4, reference built = [1, 1, 1, 0]
    Stratum 0 (map non-built): N = 900 px, sample n = 5, reference built = [0, 0, 0, 0, 1]
    W_1 = 0.1, W_0 = 0.9

By hand (Olofsson et al., 2014):
    p_11 = 0.1 * 3/4 = 0.075      p_10 = 0.1 * 1/4 = 0.025      (eq. 5)
    p_01 = 0.9 * 1/5 = 0.18       p_00 = 0.9 * 4/5 = 0.72
    p_.1 = 0.075 + 0.18 = 0.255                                  (eq. 6 / A_tot)
    S(p_.1)^2 = 0.1^2 * (0.75*0.25)/3 + 0.9^2 * (0.2*0.8)/4
              = 0.000625 + 0.0324 = 0.033025                     (eq. 7)
    OA = 0.075 + 0.72 = 0.795; UA_1 = 0.075/0.1 = 0.75; PA_1 = 0.075/0.255 (eq. 9)
    V(UA_1) = U(1-U)/(n_1 - 1) = 0.1875/3 = 0.0625 (UA variance, Olofsson 2014)
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from conftest import load_script

est = load_script("src/estimators.py")

STRATA = pd.Series([1, 1, 1, 1, 0, 0, 0, 0, 0])
REF = np.array([1, 1, 1, 0, 0, 0, 0, 0, 1])
MAP = STRATA.to_numpy()
N_PIX = {1: 100, 0: 900}


def test_proportion_matches_equations_6_and_7() -> None:
    p = est.proportion(REF == 1, STRATA, N_PIX)
    assert p.value == pytest.approx(0.255)
    assert p.se == pytest.approx(np.sqrt(0.033025))
    area = p.scaled(1000 * 100 / 1e6)  # 1000 px of 10 m -> km²
    assert area.value == pytest.approx(0.0255)
    lo, hi = p.ci95
    assert hi - lo == pytest.approx(2 * 1.96 * np.sqrt(0.033025))  # eq. 8


def test_error_matrix_matches_equation_5() -> None:
    m = est.error_matrix(MAP, REF, STRATA, N_PIX, classes=[1, 0])
    expected = [[0.075, 0.025], [0.18, 0.72]]
    np.testing.assert_allclose(m.to_numpy(), expected)
    assert m.to_numpy().sum() == pytest.approx(1.0)


def test_accuracy_matches_equation_9_and_4() -> None:
    a = est.accuracy(MAP, REF, STRATA, N_PIX)
    assert a["OA"].value == pytest.approx(0.795)
    assert a["UA"].value == pytest.approx(0.75)
    assert a["UA"].se == pytest.approx(np.sqrt(0.0625))  # Stehman = Olofsson here
    pa = 0.075 / 0.255
    assert a["PA"].value == pytest.approx(pa)
    assert a["F1"].value == pytest.approx(2 * 0.75 * pa / (0.75 + pa))


def test_stehman_for_map_that_differs_from_strata() -> None:
    # Another map: calls built the first two points of stratum 1 and the last of stratum 0.
    other = np.array([1, 1, 0, 0, 0, 0, 0, 0, 1])
    # By hand: totals of hit = 1[map 1 & ref 1]: stratum 1 mean 2/4, stratum 0 mean 1/5
    #   Y = 100 * 0.5 + 900 * 0.2 = 230; X(map 1) = 100 * 0.5 + 900 * 0.2 = 230 -> UA = 1
    #   X(ref 1) = 100 * 0.75 + 900 * 0.2 = 255 -> PA = 230 / 255
    a = est.accuracy(other, REF, STRATA, N_PIX)
    assert a["UA"].value == pytest.approx(1.0)
    assert a["PA"].value == pytest.approx(230 / 255)
    # OA: agreement per stratum = 3/4 and 5/5 -> 0.1 * 0.75 + 0.9 * 1.0
    assert a["OA"].value == pytest.approx(0.975)


def test_domain_covering_everything_equals_full_accuracy() -> None:
    full = est.accuracy(MAP, REF, STRATA, N_PIX)
    dom = est.domain_accuracy(MAP, REF, np.ones(9, dtype=bool), STRATA, N_PIX)
    for k in ("OA", "UA", "PA"):
        assert dom[k].value == pytest.approx(full[k].value)


def test_unsampled_stratum_with_area_raises() -> None:
    with pytest.raises(ValueError, match="no sample"):
        est.proportion(REF == 1, STRATA, {**N_PIX, 2: 50})


def test_covariance_hand_example_and_variance_identity() -> None:
    # Same variable twice: covariance equals the variance S(p_.1)^2 = 0.033025
    assert est.covariance(REF, REF, STRATA, N_PIX) == pytest.approx(0.033025)
    # y2 = 1 - y1: covariance = -variance
    assert est.covariance(REF, 1 - REF, STRATA, N_PIX) == pytest.approx(-0.033025)
