"""Checks of the labelling kit (plot geometry, blindness, sheet format read by Phase 8)."""

from __future__ import annotations

import pandas as pd
import pytest
from conftest import load_script
from pyproj import Geod

kit = load_script("src/07b_labelling_kit.py")
acc = load_script("src/08_accuracy_area.py")


def test_plot_square_is_10_m() -> None:
    ring = kit.plot_square(74.3, 31.5)
    assert ring[0] == ring[-1]
    geod = Geod(ellps="WGS84")
    lons, lats = zip(*ring, strict=True)
    area, _ = geod.polygon_area_perimeter(lons, lats)
    assert abs(area) == pytest.approx(100.0, rel=0.01)


def test_sheet_has_no_key_columns_and_is_read_by_phase_8(tmp_path) -> None:
    pts = pd.DataFrame({"plotid": [1, 2], "lon": [74.3, 74.4], "lat": [31.5, 31.6]})
    sheet = kit.answer_sheet(pts)
    assert not {"stratum", "city"} & set(sheet.columns)
    sheet.loc[0, ["Built in 2017?", "Built in 2023?"]] = ["No", "Yes"]
    sheet.loc[1, ["Built in 2017?", "Built in 2023?"]] = ["Yes", "Unclear"]
    path = tmp_path / "ceo_export.csv"
    sheet.to_csv(path, index=False, encoding="utf-8-sig")
    ref = acc.read_reference(path)
    assert ref["ref_2017"].tolist() == [0, 1]
    assert ref["ref_2023"].iloc[0] == 1
    assert pd.isna(ref["ref_2023"].iloc[1])
