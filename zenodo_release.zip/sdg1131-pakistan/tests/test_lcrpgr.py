"""Hand-worked checks of equations (10) to (13) and (16) in src/10_lcrpgr_montecarlo.py."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from conftest import load_script

mod = load_script("src/10_lcrpgr_montecarlo.py")


def test_equations_10_to_13_hand_example() -> None:
    # Built 100 -> 130 km², population 1.0 M -> 1.2 M over 6 years
    # LCR = ln(1.3)/6 = 0.043727; PGR = ln(1.2)/6 = 0.030387; LCRPGR = 1.43898
    assert float(mod.lcr(100, 130)) == pytest.approx(np.log(1.3) / 6)
    assert mod.pgr(1.0e6, 1.2e6) == pytest.approx(np.log(1.2) / 6)
    assert float(mod.lcr(100, 130)) / mod.pgr(1.0e6, 1.2e6) == pytest.approx(1.43898, rel=1e-4)
    # BUpc = 100 km² / 1 M people = 100 m² per person
    assert mod.bupc_m2(100, 1.0e6) == pytest.approx(100.0)


def test_interpretation_rule() -> None:
    assert mod.interpret(1.1, 1.5) == "sprawl"
    assert mod.interpret(0.5, 0.9) == "compact"
    assert mod.interpret(0.8, 1.2) == "inconclusive"


def test_draws_match_requested_moments() -> None:
    rng = np.random.default_rng(42)
    d = mod.draw_areas(100, 5, 130, 6, cov=20.0, mode="correlated", rng=rng, n=200_000)
    assert d.mean(axis=0) == pytest.approx([100, 130], rel=1e-3)
    assert np.cov(d.T)[0, 1] == pytest.approx(20.0, rel=0.05)
    ind = mod.draw_areas(100, 5, 130, 6, cov=20.0, mode="independent", rng=rng, n=200_000)
    assert abs(np.cov(ind.T)[0, 1]) < 0.5  # covariance ignored, as in equation (16)


def test_city_rows_point_inside_ci_and_mapped_rows() -> None:
    area = pd.DataFrame({
        "year": [2017, 2023], "area_km2": [100.0, 130.0], "se_km2": [3.0, 3.0],
        "cov_2017_2023_km2sq": [6.0, 6.0],
        "own_mapped_km2": [105.0, 128.0], "dw_mapped_km2": [150.0, 170.0],
        "ghsl_mapped_km2": [60.0, 66.0],
    })
    pop = pd.DataFrame({"year": [2017, 2023], "pop_extent": [1.0e6, 1.2e6]})
    rows = mod.city_rows("x", area, pop, "independent", np.random.default_rng(42))
    adj = rows[0]
    assert adj["estimate"] == "area-adjusted"
    assert adj["LCRPGR"] == pytest.approx(1.43898, rel=1e-4)
    assert adj["point_inside_ci"]
    assert adj["ci_low"] < adj["LCRPGR"] < adj["ci_high"]
    dw = next(r for r in rows if r["source"] == "dw")
    assert dw["LCRPGR"] == pytest.approx(np.log(170 / 150) / np.log(1.2))
    assert np.isnan(dw["ci_low"])
