"""Hand-worked checks of src/10b_lcrpgr_mapped.py (no-validation SDG 11.3.1)."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from conftest import load_script

mod = load_script("src/10b_lcrpgr_mapped.py")


def test_equations_10_to_12() -> None:
    # 100 -> 130 km², 1.0 -> 1.2 M people over 6 years: LCRPGR = ln 1.3 / ln 1.2 = 1.43902
    assert mod.lcr(100, 130) / mod.pgr(1.0e6, 1.2e6) == pytest.approx(np.log(1.3) / np.log(1.2))


def test_interpretation_over_settings() -> None:
    assert mod.interpret([1.2, 1.5, 1.1]) == "sprawl (all settings)"
    assert mod.interpret([0.5, 0.9]) == "compact (all settings)"
    assert mod.interpret([0.9, 1.3]) == "depends on setting"


def test_pairwise_agreement_hand_example() -> None:
    maps = {"a": np.array([1, 1, 0, 0], bool), "b": np.array([1, 0, 0, 0], bool)}
    r = mod.pairwise_agreement(maps)[0]
    assert r["overall_agreement_pct"] == pytest.approx(75.0)
    assert r["jaccard_built"] == pytest.approx(0.5)


def test_summarise_range_and_flip() -> None:
    rows = pd.DataFrame([
        {"city": "x", "source": "own", "setting": "baseline", "LCR": 0.04, "PGR": 0.03,
         "LCRPGR": 1.3, "BUpc_2017_m2": 50.0, "BUpc_2023_m2": 52.0},
        {"city": "x", "source": "own", "setting": "s1", "LCR": 0.02, "PGR": 0.03,
         "LCRPGR": 0.8, "BUpc_2017_m2": 50.0, "BUpc_2023_m2": 52.0},
    ])
    t7, t8 = mod.summarise(rows)
    assert t7.iloc[0]["range_low"] == pytest.approx(0.8)
    assert t7.iloc[0]["range_high"] == pytest.approx(1.3)
    assert t7.iloc[0]["interpretation"] == "depends on setting"
    assert bool(t8.iloc[0]["flips"])
    assert t8.iloc[0]["delta_lcrpgr"] == pytest.approx(-0.5)


def test_no_reversal_keeps_built_land_built() -> None:
    a, b = np.array([1, 1, 0, 0], bool), np.array([1, 0, 1, 0], bool)
    assert mod.no_reversal(a, b).tolist() == [True, True, True, False]


def test_temporal_majority_needs_two_of_three_years() -> None:
    stack = np.array([[1, 1, 0, 0], [1, 0, 1, 0], [0, 0, 1, 0]], bool)
    assert mod.temporal_majority(stack).tolist() == [True, False, True, False]


def test_gross_change_hand_example() -> None:
    # 3 pixels gained, 1 lost, of 0.0001 km2 each; loss is a third of gain
    a = np.array([1, 0, 0, 0, 1], bool)
    b = np.array([0, 1, 1, 1, 1], bool)
    r = mod.gross_change(a, b)
    assert r["gain_km2"] == pytest.approx(3e-4)
    assert r["loss_km2"] == pytest.approx(1e-4)
    assert r["net_km2"] == pytest.approx(2e-4)
    assert r["loss_pct_of_gain"] == pytest.approx(100 / 3)


def test_repeated_flips_count_ever_built_pixels_only() -> None:
    # pixel 0 flips three times, pixel 1 once, pixel 2 is never built
    stack = np.array([[1, 0, 0], [0, 1, 0], [1, 1, 0], [0, 1, 0]], bool)
    assert mod.repeated_flip_pct(stack) == pytest.approx(50.0)
