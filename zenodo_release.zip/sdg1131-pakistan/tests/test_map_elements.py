"""The scale-bar guard in src/map_elements.py (never a scale bar on a degree map)."""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pytest  # noqa: E402
from conftest import load_script  # noqa: E402

mod = load_script("src/map_elements.py")


def test_scale_bar_refused_on_geographic_crs() -> None:
    fig, ax = plt.subplots()
    with pytest.raises(ValueError):
        mod.add_scale_bar(ax, "EPSG:4326")
    mod.add_scale_bar(ax, "EPSG:32643")  # projected: allowed
    plt.close(fig)
