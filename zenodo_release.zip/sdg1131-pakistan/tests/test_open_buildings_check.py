"""Hand-worked checks of src/10c_open_buildings_check.py."""

from __future__ import annotations

import numpy as np
import pytest
from conftest import load_script

mod = load_script("src/10c_open_buildings_check.py")
labels = load_script("gee/15_dw_labels_on_buildings.py")


def test_split_by_call_hand_example() -> None:
    share = np.array([10.0, 20.0, 0.0, 90.0])
    call = np.array([True, True, False, False])
    scope = np.array([True, True, True, False])
    r = mod.split_by_call(share, call, scope)
    assert r["share_where_built_pct"] == pytest.approx(15.0)
    assert r["share_where_nonbuilt_pct"] == pytest.approx(0.0)
    assert r["built_pct_of_scope"] == pytest.approx(200 / 3)


def test_building_change_hand_example() -> None:
    share0 = np.array([0, 50, 100], np.uint8)
    share1 = np.array([100, 0, 100], np.uint8)
    scope = np.array([True, True, False])
    # (100 + 0 - 0 - 50) percent of one 100 m2 cell
    assert mod.building_change_km2(share0, share1, scope) == pytest.approx(0.5 * 1e-4)


def test_cell_means_drops_incomplete_cells() -> None:
    a = np.array([[1, 3, 5, 5], [1, 3, 5, 5]], float)
    valid = np.ones_like(a, bool)
    valid[0, 3] = False
    out = mod.cell_means(a, valid, cell_px=2)
    assert out[0, 0] == pytest.approx(2.0)
    assert np.isnan(out[0, 1])


def test_pearson_ignores_missing_cells() -> None:
    x = np.array([1.0, 2.0, 3.0, np.nan])
    y = np.array([2.0, 4.0, 6.0, 1.0])
    assert mod.pearson(x, y) == pytest.approx(1.0)


def test_label_rows_skip_empty_classes_and_scale_to_percent() -> None:
    feature = {"properties": {"city": "x", "dense_6": 3, "dense_7": 1, "dense_4": None,
                              "all_6": 10}}
    t = labels.rows([feature])
    dense = t[t["scope"] == "dense"].set_index("class")["share_pct"]
    assert dense["built"] == pytest.approx(75.0)
    assert dense["bare"] == pytest.approx(25.0)
    assert "crops" not in dense.index
