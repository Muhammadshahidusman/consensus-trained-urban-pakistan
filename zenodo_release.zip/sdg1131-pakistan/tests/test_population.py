"""Hand-worked checks of equation (14) in gee/09_population.py."""

from __future__ import annotations

import pandas as pd
import pytest
from conftest import load_script

mod = load_script("gee/09_population.py")


def test_dasymetric_hand_example() -> None:
    # Unit A: census 1,000,000; GHS-POP 800 in unit, 600 inside extent -> 750,000
    # Unit B: census 200,000;   GHS-POP 100 in unit, 10 inside extent  -> 20,000
    # Unit C: census 50,000;    no overlap with the extent             -> 0
    out = mod.dasymetric(pd.Series([1_000_000, 200_000, 50_000]),
                         pd.Series([800.0, 100.0, 40.0]), pd.Series([600.0, 10.0, 0.0]))
    assert out == pytest.approx(770_000)


def test_dasymetric_rejects_inside_above_unit() -> None:
    with pytest.raises(ValueError):
        mod.dasymetric(pd.Series([10]), pd.Series([1.0]), pd.Series([2.0]))


def test_interpolation_weights() -> None:
    assert mod.interpolation_weight(2017) == pytest.approx(0.4)
    assert mod.interpolation_weight(2023) == pytest.approx(0.6)
