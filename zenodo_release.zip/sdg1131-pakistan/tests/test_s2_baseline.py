"""Tests for gee/04_s2_baseline_features.py (no Earth Engine login needed)."""

from __future__ import annotations

from conftest import load_script

mod = load_script("gee/04_s2_baseline_features.py")


def test_city_epsg_from_consensus_script() -> None:
    assert mod.CITY_EPSG == {"karachi": 32642, "lahore": 32643, "faisalabad": 32643,
                             "peshawar": 32642, "rawalpindi": 32643}


def test_check_join_counts_missing(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr(mod, "SAMPLE_DIR", tmp_path)
    (tmp_path / "samples_x_2020.csv").write_text("point_id\na\nb\nc\n", encoding="utf-8")
    header = "point_id," + ",".join(mod.S2_BANDS + mod.INDICES) + ",n_obs\n"
    row = "a," + ",".join(["0.1"] * 9) + ",5\n"
    (tmp_path / "s2_x_2020.csv").write_text(header + row, encoding="utf-8")
    assert mod.check_join("x") == 2
