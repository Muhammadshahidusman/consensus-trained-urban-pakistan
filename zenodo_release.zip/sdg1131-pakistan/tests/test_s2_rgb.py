"""Site-selection rule in gee/12_s2_rgb.py."""

from __future__ import annotations

import numpy as np
from conftest import load_script

mod = load_script("gee/12_s2_rgb.py")


def test_best_window_picks_highest_new_built_share_inside_extent() -> None:
    change = np.zeros((8, 8), dtype=np.uint8)
    change[0:2, 0:2] = 2           # dense new built, but the window is outside the extent
    change[4:6, 4:6] = 2           # dense new built inside the extent
    inside = np.ones((8, 8), dtype=bool)
    inside[0:2, 0:2] = False
    r, c, share = mod.best_window(change, inside, win_px=2)
    assert (r, c) == (4, 4)
    assert share == 1.0
