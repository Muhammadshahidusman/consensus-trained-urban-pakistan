"""Checks of src/11_sensitivity.py helpers."""

from __future__ import annotations

import numpy as np
import pytest
from conftest import load_script

mod = load_script("src/11_sensitivity.py")


def test_lcrpgr_hand_example() -> None:
    # ln(130/100) / ln(1.2) = 0.262364 / 0.182322 = 1.43902
    assert mod.lcrpgr(100, 130, 1.0e6, 1.2e6) == pytest.approx(np.log(1.3) / np.log(1.2))


def test_flip_detection() -> None:
    assert mod.side_of_one(1.2) != mod.side_of_one(0.9)
    assert mod.side_of_one(1.2) == mod.side_of_one(1.01)
