"""Tests for the local morphology in gee/02_urban_extent.py, on small hand-made grids."""

from __future__ import annotations

import numpy as np
import pytest
from conftest import load_script

mod = load_script("gee/02_urban_extent.py")


def test_classify_thresholds() -> None:
    density = np.array([[0.0, 0.249, 0.25, 0.50, 0.501, np.nan]])
    # rural < 0.25 <= suburban <= 0.50 < urban; NaN -> nodata
    expected = [[0, 0, 1, 1, 2, mod.CLASS_NODATA]]
    np.testing.assert_array_equal(mod.classify(density), expected)


def test_disk_shape() -> None:
    d = mod.disk(1)
    assert d.shape == (3, 3)
    assert d.sum() == 5  # plus-shaped disk of radius 1


def _grid() -> np.ndarray:
    m = np.zeros((9, 12), dtype=bool)
    m[2:7, 1:5] = True      # main patch around the centre (4, 2)
    m[4, 3] = False         # interior hole
    m[3:5, 6:8] = True      # 1 empty column away from main -> within link distance 2
    m[3:5, 10:12] = True    # 5 columns away -> outside link distance
    return m


def test_core_extent_keeps_near_patch_and_fills_holes() -> None:
    ext = mod.core_extent(_grid(), centre_rc=(4, 2), link_px=2)
    assert ext[4, 3]                  # hole filled
    assert ext[3:5, 6:8].all()        # nearby patch kept
    assert not ext[3:5, 10:12].any()  # distant patch dropped


def test_core_extent_rejects_centre_outside_mask() -> None:
    with pytest.raises(ValueError, match="not an urban or suburban"):
        mod.core_extent(_grid(), centre_rc=(0, 0), link_px=2)


def test_touches_edge() -> None:
    valid = np.ones((5, 5), dtype=bool)
    inner = np.zeros((5, 5), dtype=bool)
    inner[2, 2] = True
    assert not mod.touches_edge(inner, valid)
    inner[0, 2] = True
    assert mod.touches_edge(inner, valid)
