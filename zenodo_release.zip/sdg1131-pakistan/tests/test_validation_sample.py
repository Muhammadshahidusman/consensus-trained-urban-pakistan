"""Tests for the stratified sample draw in src/07_validation_sample.py."""

from __future__ import annotations

import numpy as np
import pytest
from conftest import load_script

mod = load_script("src/07_validation_sample.py")


def _strata() -> np.ndarray:
    s = np.full((10, 10), 255, dtype=np.uint8)
    s[:4] = 0      # 40 px stable non-built
    s[4:7] = 1     # 30 px stable built
    s[7, :5] = 2   # 5 px new built
    return s       # no reversal pixels


def test_sample_respects_allocation_and_strata() -> None:
    strata = _strata()
    drawn = mod.sample_strata(strata, {0: 10, 1: 10, 2: 10, 3: 2}, np.random.default_rng(42))
    assert drawn[0].size == 10 and drawn[1].size == 10
    assert drawn[2].size == 5      # fewer pixels than allocated: take all
    assert drawn[3].size == 0
    for code, idx in drawn.items():
        assert (strata.ravel()[idx] == code).all()
        assert np.unique(idx).size == idx.size  # without replacement


def test_sample_is_reproducible() -> None:
    a = mod.sample_strata(_strata(), {0: 10}, np.random.default_rng(42))
    b = mod.sample_strata(_strata(), {0: 10}, np.random.default_rng(42))
    np.testing.assert_array_equal(a[0], b[0])


def test_design_weights_sum_to_one() -> None:
    strata = _strata()
    drawn = mod.sample_strata(strata, mod.ALLOCATION, np.random.default_rng(42))
    table = mod.design_table(strata, drawn, pixel_km2=1e-4, city="x")
    assert table["W_i"].sum() == pytest.approx(1.0)
    assert table.loc[table["stratum"] == "stable non-built", "mapped_area_km2"].item() == \
        pytest.approx(0.004)


def test_reserve_allocation() -> None:
    assert mod.with_reserve({0: 100, 3: 25}, 0.10) == {0: 110, 3: 28}
